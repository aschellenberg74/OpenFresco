% Sample designed to show how to read and write data of different types.
clear all

% Create a SCRAMNet GT partition using a variety of different data types
GtPartition(1).Address='0x5000';
GtPartition(1).Type='int32';
GtPartition(1).Size='2';
GtPartition(2).Type='uint16';
GtPartition(2).Size='4';
GtPartition(3).Type='double';
GtPartition(3).Size='2';
GtPartition(4).Type='uint8';
GtPartition(4).Size='[2,3]';
GtPartition(5).Type='single';
GtPartition(5).Size='1';
GtPartition = scgtpartitionstruct(GtPartition);

% Create a second partition that maps part of data from the first
% partition
GtPart2(1).Address='0x5000';
GtPart2(1).Type='int32';
GtPart2(1).Size='2';
GtPart2(2).Type='uint16';
GtPart2(2).Size='4';
GtPart2 = scgtpartitionstruct(GtPart2);

% Create a third partition that maps the rest of tha data from 
% the first partition
GtPart3(1).Address='0x5010';
GtPart3(1).Type='double';
GtPart3(1).Size='2';
GtPart3(2).Type='uint8';
GtPart3(2).Size='[2,3]';
GtPart3(3).Type='single';
GtPart3(3).Size='1';
GtPart3 = scgtpartitionstruct(GtPart3);

% Create a GT node Structure
GtNode=scgtnodestruct([]);
GtNode.Interface.NodeID='8';
GtNode.Partitions=GtPartition;
GtNode=scgtnodestruct(GtNode);

% create variables to use in selecting the simulation's Sample Time
% and duration
test1SampleTime=0.01;
test1StopTime=20;

% is connection with target working?
if ~strcmp(slrtpingtarget, 'success')
  error('Connection with target cannot be established');
end

% open the model
open_system('GtMultTypesModel');

% build xPC application and download it onto the target
rtwbuild('GtMultTypesModel');

% get reference to the target
tg1=xpc;

% set the target SampleTime and StopTime
tg1.SampleTime=test1SampleTime;
tg1.StopTime=test1StopTime;
