% Receive Data sample
clear all

% Create partition holding two double precision floating point values at
% offset 0x100 within the SCRAMNet GT memory space
GtPartition(1).Address='0x1000';
GtPartition(1).Type='double';
GtPartition(1).Size='2';
GtPartition = scgtpartitionstruct(GtPartition);

% Create a node structure to use in configuring the SCRAMNet GT board.
GtNode=scgtnodestruct([]);
% set node ID. This value should be different for each node.
GtNode.Interface.NodeID='9';
GtNode.Partitions=GtPartition;
GtNode.Interface.Interrupts.SelfInterrupts='on'
% enable the card to receive broadcast interrupts level 0 to 31.
GtNode.Interface.Interrupts.ChangeBroadcastInterruptMask='yes'
GtNode.Interface.Interrupts.BroadcastInterruptMask='0xffffffff'
GtNode=scgtnodestruct(GtNode);

% create variable to use in specifying the sample and stop time
% for the simulation
SampleTime=0.1;
StopTime=inf;

% is connection with target working?
if ~strcmp(slrtpingtarget, 'success')
  error('Connection with target cannot be established');
end

% open the model
open_system('GtRcvIntModel');

% build xPC application and download it onto the target
rtwbuild('GtRcvIntModel');

% set the simulation Sample and Stop Times
tg1=xpc;
tg1.SampleTime=SampleTime;
tg1.StopTime=StopTime;

