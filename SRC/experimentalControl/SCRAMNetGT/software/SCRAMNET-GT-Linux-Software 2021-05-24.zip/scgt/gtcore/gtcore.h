/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2020 Curtiss-Wright Controls Electronic System, Inc.         */
/*     dtn_support@curtisswright.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

/**
 * @file   gtcore.h
 * @brief  core portions available to only driver.
 */


#ifndef __GT_CORE_H__
/** Macro to prevent multiple inclusion  */
#define __GT_CORE_H__

/************************************************************************/
/**************************  I N C L U D E S  ***************************/
/************************************************************************/

#include "systypes.h"
#include "ksys.h"
#include "scgt.h"
#include "gtucore.h"
#include "gtcoreTypes.h"
#include "gtcoreIoctl.h"

/** gtcore.h file revision update 5/20/19  */
#define FILE_REV_GTCORE_H  "9"

/******************************************************************/
/********************* COMMON DEFINITIONS *************************/
/******************************************************************/

/* exchange states */

/** Exchange not done  */
#define GTCORE_EXCH_NOT_DONE  0
/** Done with exchange */
#define GTCORE_EXCH_DONE      1

/** Write operation */
#define GTCORE_WRITE 0
/** Read operation  */
#define GTCORE_READ 1

/** Interrupt Queue Size. (must be power of 2) */
#define GTCORE_INTR_Q_SIZE   1024

/* interrupt type bitmask definitions  */

/** ISR Handled */
#define GTCORE_ISR_HANDLED           0x1
/** DMA Interrupt  */
#define GTCORE_ISR_DMA               0x2
/** Queued interrupt */
#define GTCORE_ISR_QUEUED_INTR       0x4


/** a useful register read macro */
#define scgtWriteCRegMasked(dev, offset, val, mask)  \
               scgtWriteCReg((dev), (offset), ((scgtReadCReg(dev, offset) & ~(mask)) | ((val) & (mask))))


/******************************************************************/
/*************** TRANSACTION and CHAIN DEFINITIONS ****************/
/******************************************************************/

/* transaction queue entry */
/** Size of Transaction Queue Block  */
#define GTCORE_TQE_SIZE        (8*4) 
/** Transaction CSR */
#define GTCORE_TQE_TNS_CSR        0
/** Shared memory offset */
#define GTCORE_TQE_SMO            1
/** Chain PCI A32 start address */
#define GTCORE_TQE_CE_ADD32       2
/** Network interrupt control (send only)  */
#define GTCORE_TQE_NI_CTL         3
/** Network interrupt vector (send only) */
#define GTCORE_TQE_NI_VECT        4
/** Chain PCI A64 start address */
#define GTCORE_TQE_CE_ADD64       5
/** Reserved 0 */
#define GTCORE_TQE_RESERVED_0     6
/** Reserved 1 */
#define GTCORE_TQE_RESERVED_1     7

/* TQE CSR bit defs  */

/** Transaction length mask  */
#define GTCORE_TQE_LEN          0x007FFFFF
/** Word swap data */
#define GTCORE_TQE_IDW_SWAP_OR  0x01000000
/** Byte swap data  */
#define GTCORE_TQE_IDB_SWAP_OR  0x02000000
/** Skip Entry */
#define GTCORE_TQE_SKP_ENTRY    0x04000000
/** Time out */
#define GTCORE_TQE_TIMEOUT      0x10000000
/** Error  */
#define GTCORE_TQE_ERR          0x20000000
/** Fixed 1 */
#define GTCORE_TQE_FIXED_1      0x40000000

/* TQE network interrupt control (TQE_NI_CTL) bit definitions */

/** Enable network interrupt. 1 for interrupt */
#define GTCORE_TQE_NET_INT        0x1
/** Interrupt Type */
#define GTCORE_TQE_NET_INT_TYPE   0x2
/** Network interrupt number mask */
#define GTCORE_TQE_NET_INT_NUM    0xFF00

/* chain entry */
/** Size of one chain entry block */
#define GTCORE_CE_SIZE         (uint64)(8*4)
/** Buffer address 32-bit */
#define GTCORE_CE_BUF_ADD32     0
/** Reserved 0 */
#define GTCORE_CE_RESERVED_0    1
/** Control status register */
#define GTCORE_CE_TNS_CSR       2
/** Next buffer 32-bit address */
#define GTCORE_CE_NEXT_ADD32    3
/** Upper half of 674-bit buffer address */
#define GTCORE_CE_BUF_ADD64     4
/** Upper half of 64-bit next buffer address */
#define GTCORE_CE_NEXT_ADD64    5
/** Reserved 1 */
#define GTCORE_CE_RESERVED_1    6
/** reserved 2 */
#define GTCORE_CE_RESERVED_2    7

/* chain entry transaction CSR bit defs */

/** chain entry length */
#define GTCORE_CE_LEN        0x007FFFFF
/** last chain entry */
#define GTCORE_CE_LST        0x01000000


/******************************************************************
* PCI DEFINITIONS
*******************************************************************/

/*
* Device and Vendor ID's
*/

/** SCRAMNet Gt vendor ID */
#define GTCORE_VENDOR_ID     0x1387
/** SCRAMNet gt device ID */
#define GTCORE_DEVICE_ID     0x5310

/*
* BAR definitions
*/
 
/** Configuration registers  */
#define GTCORE_BAR_C_REGISTERS  0
/** Net management registers */
#define GTCORE_BAR_NM_REGISTERS 1
/** GT shared memory  */
#define GTCORE_BAR_MEMORY       2

/*
* PCI configuration registers
*/
 
/**
@defgroup PciRegs PCI configuration
SCRAMNet GT PCI configuration register offset definitions 
@{ 
*/
 
/** Offset to device and vendor Id registers */
#define GTCORE_PCI_IDR                0x0
/** Command and status registers */
#define GTCORE_PCI_CR_SR              0x4
/** Revision id and class code */
#define GTCORE_PCI_REV_CCR            0x8
/** Cache line size, lat timer, header type. BIST */
#define GTCORE_PCI_CLSR_LTR_HTR_BISTR 0xC
/** Offset to bar 0 memory address */
#define GTCORE_PCI_BAR0               0x10
/** Offset to bar 1 memory address */
#define GTCORE_PCI_BAR1               0x14
/** Offset to bar 2 memory address */
#define GTCORE_PCI_BAR2               0x18
/** Offset to bar 3 memory address */
#define GTCORE_PCI_BAR3               0x1C
/** Offset to bar 4 memory address */
#define GTCORE_PCI_BAR4               0x20
/** Offset to bar 5 memory address */
#define GTCORE_PCI_BAR5               0x24
/** CardBus CIS Pointer */
#define GTCORE_PCI_CIS                0x28
/** Subsystem vendor ID and subsystem ID */
#define GTCORE_PCI_SVID_SID           0x2C
/** Expansion ROM base address */
#define GTCORE_PCI_ERBAR              0x30
/** Interrupt line, Interrupt pin. Min Gnt, max lat */
#define GTCORE_PCI_ILR_IPR_IMGR_MLR   0x3C

/** GTCORE_PCI_CR_SR bit defs */
#define GTCORE_PCI_MASTER_ACCESS_ENABLE  0x00000004

/**
@}
*/

/****************************************************************/
/********************** REGISTER DEFS ***************************/
/****************************************************************/
/** Gt core register aperture size */
#define GTCORE_REGISTER_SIZE     0x100

/**
@defgroup RegDef BAR0 configuration register offset definitions
SCRAMNet GT configuration registers (BAR0) offset definitions
@{ 
*/

/* register offsets */

/** Board Information (BRD_INFO). BAR0 Offset 0x00 */
#define GTCORE_R_BRD_INFO       0x0
/** Driver Board CSR (DRV_BRD_CSR). BAR0 Offset 0x04 */
#define GTCORE_R_DRV_BRD_CSR    0x4
/** User Board CSR (USR_BRD_CSR). BAR0 Offset 0x08 */
#define GTCORE_R_USR_BRD_CSR    0x8
/** Interrupt Control/Status (INT_CSR). BAR0 Offset 0x0C */
#define GTCORE_R_INT_CSR        0xc 
/** Link Control (LINK_CTL). BAR0 Offset 0x10 */
#define GTCORE_R_LINK_CTL       0x10  
/** Link Status (LINK_STAT). BAR0 Offset 0x14 */
#define GTCORE_R_LINK_STAT      0x14
/** Receive Host broadcast interrupt (HBI) Mask (RX_HBI_MSK). BAR0 Offset 0x18 */
#define GTCORE_R_RX_HBI_MSK     0x18
/** Receive Host unicast interrupt (HUI) Mask (RX_HUI_MSK). BAR0 Offset 0x1C */
#define GTCORE_R_RX_HUI_MSK     0x1c
/** Miscellaneous Function (MISC_FNCTN). BAR0 Offset 0x20 */
#define GTCORE_R_MISC_FNCTN     0x20

/** Network Timer (NET_TMR). BAR0 Offset 0x40 */
#define GTCORE_R_NET_TMR        0x40
/** Host Timer (HST_TMR). BAR0 Offset 0x44 */
#define GTCORE_R_HST_TMR        0x44
/** Latency Timer (LAT_TMR). BAR0 Offset 0x48 */
#define GTCORE_R_LAT_TMR        0x48
/** Shared Memory Traffic Counter (SM_TRFC_CNTR). BAR0 Offset 0x4C */
#define GTCORE_R_SM_TRFC_CNTR   0x4c
/** Interrupt Traffic Counter (INT_TRFC_CNTR).  BAR0 Offset 0x50 */
#define GTCORE_R_INT_TRFC_CNTR  0x50
/** Hunt Shared Memory Traffic Counter (HNT_SM_TRFC_CNTR). BAR0 Offset 0x54 */
#define GTCORE_R_HNT_TRFC_CNTR  0x54
/** Network Host Interrupt Queue Interrupt Counter (NHIQ_INT_CNTR). BAR0 Offset 0x58 */
#define GTCORE_R_NHIQ_INT_CNTR  0x58
/** Host Interrupt Counter (HST_INT_CNTR). BAR0 Offset 0x5C */
#define GTCORE_R_HST_INT_CNTR   0x5c

/** Link Error Counter (LNK_ERR_CNTR). BAR0 Offset 0x80 */
#define GTCORE_R_LNK_ERR_CNTR   0x80
/** Link Down Counter (LNK_DOWN_CNTR). BAR0 Offset 0x84 */
#define GTCORE_R_LNK_DOWN_CNTR  0x84
/** Decoded error counter (not used) */
#define GTCORE_R_DEC_ERR_CNTR   0x88
/** Sync error counter (not used) */
#define GTCORE_R_SYNC_ERR_CNTR  0x8c
/** CSR error counter (not used) */
#define GTCORE_R_CRC_ERR_CNTR   0x90

/** EOF error counter (not used) */
#define GTCORE_R_EOF_ERR_CNTR   0x94
/** PTECL error counter (not used) */
#define GTCORE_R_PRTCL_ERR_CNTR 0x98
/** RXF error counter (not used) */
#define GTCORE_R_RXF_ERR_CNTR   0x9c

/** Watch dog timer value */
#define GTCORE_R_TC_WDT_VAL     0xbc

/** Transaction Queue A32 Address (TQ_ADD32_TC0) BAR0 Offset 0xC0 */
#define GTCORE_R_TQ_ADD32_TC0   0xc0
/** Transaction Queue A64 Address (TQ_ADD64_TC0) BAR0 Offset 0xC4 */
#define GTCORE_R_TQ_ADD64_TC0   0xc4
/** Transaction Queue Control (TQ_CTL_TC0) BAR0 Offset 0xC8 */
#define GTCORE_R_TQ_CTL_TC0     0xc8
/** Transaction Length (TNS_CSR_TC0) BAR0 Offset 0xCC */
#define GTCORE_R_TNS_LEN_TC0    0xcc
/** Transaction Queue A32 Address Channel 1 Addr32=(Receive Channel - Shared Memory to PCI)  BAR0 Offsets 0xD0 */
#define GTCORE_R_TQ_ADD32_TC1   0xd0
/** Transaction Queue A64 Address Channel 1 Addr64=(Receive Channel - Shared Memory to PCI) BAR0 Offsets 0xD4 */
#define GTCORE_R_TQ_ADD64_TC1   0xd4
/** Transaction Queue Control Channel 1 (Receive Channel - Shared Memory to PCI) BAR0  Offsets 0xD8 */
#define GTCORE_R_TQ_CTL_TC1     0xd8
/** Transaction Length Channel 1 (Receive Channel - Shared Memory to PCI) BAR0 Offsets 0xDF */
#define GTCORE_R_TNS_LEN_TC1    0xdc

/** 
End of bar 0 group
@}
*/ 

/****************************************************************/
/********************* Bit Definitions **************************/
/****************************************************************/

/** @defgroup BRD_INFO BAR0 Offset 0x00 | BRD_INFO bit definitions (bar 0 offset 0)
Board information (BRD_INFO) bit mask (Bar 0 offset 0)
@{*/ 

/** MEM_PMS bit mask. The representation of this field is dependent on the MEM_TYPE field. */
#define GTCORE_R_MEM_PMS        0x3

/**@brief MEM_TRMS mask.  Host Bus Requested Target Memory Size. 
* This data field indicates the size of the shared memory target
*  aperture that was requested by the board at power up.*/
#define GTCORE_R_MEM_RTMS       0x3c

/** Memory Type. This data field indicates the type of memory used by the product. May be removed. */
#define GTCORE_R_MEM_TYPE       0xc0
/** A64 Target Support */
#define GTCORE_R_A64_TSPT       0x100
/** A64 Initiator Support */
#define GTCORE_R_A64_ISPT       0x200
/** Bus support. */
#define GTCORE_R_BUS_SPT        0x1c00

/** @brief Physical Interface Type.  This data field indicates the physical interface present.
 00 indicates the board uses a 1.0625Gbps single wire interface with 8B / 10B encoding
 01 indicates the board uses a 2.5Gbps single wire interface with 8B / 10B encoding */
#define GTCORE_R_PHY_TYPE       0x6000
/** Extended Revision ID  Extended revision level of the board controller.*/
#define GTCORE_R_EXT_REV_ID     0x00ff0000
/** Revision ID | Revision level of the board controller| */
#define GTCORE_R_REV_ID         0xff000000
/**
end BRD_INFO
@}
*/

/**
@defgroup DRVBRDCSR BAR0 Offset 0x08 | Driver Board CSR bit mask (DRV_BRD_CSR)
Driver Board CSR bit mask (Bar 0 offset 0x04)
@{ 
*/
/** Static A.  This field reads back a value of A. */
#define GTCORE_R_STC_A          0xF
/** Target control byte swap. Byte swap on target accesses to control/status registers and network management registers. */
#define GTCORE_R_TCB_SWAP       0x10
/** Initiator Control Byte Swap.  Byte swap when fetching TQE and CE from PCI */
#define GTCORE_R_ICB_SWAP       0x20

/**
end DRVBRDCSR
@}
*/

/**
@defgroup UsrBrdCsr BAR0 Offset 0x08 | User Board CSR (USR_BRD_CSR)  
User Board CSR (USR_BRD_CSR) bar 0 offset 0x08
@{
*/
/** Data word swap */
#define GTCORE_R_DW_SWAP        0x1
/** Data byte swap */
#define GTCORE_R_DB_SWAP        0x2
/** 64-bit initiator disable  */
#define GTCORE_R_INIT_D64_DIS   0x10
/**
@}
*/

/**
@defgroup INT_CSR BAR0 offset 0x0c | Interrupt Control/Status (INT_CSR)
Interrupt Control/Status (INT_CSR)  BAR0 Offset 0x0C
@{
*/

/** Transaction Channel 0 Interrupt Active */
#define GTCORE_R_TC0_INT        0x1
/** Transaction Channel 1 Interrupt Active */
#define GTCORE_R_TC1_INT        0x2
/** Link Error Interrupt Active */
#define GTCORE_R_LNK_ERR_INT    0x4
/** Received Network Interrupt Active */
#define GTCORE_R_RX_NET_INT     0x8
/** Enable Transaction Channel 0 Interrupt */
#define GTCORE_R_TC0_INT_EN     0x10000
/** Enable Transaction Channel 1 Interrupt */
#define GTCORE_R_TC1_INT_EN     0x20000
/** Enable Link Error Interrupt */
#define GTCORE_R_LNK_ERR_INT_EN 0x40000
/** Enable Received Network Interrupt */
#define GTCORE_R_RX_NET_INT_EN  0x80000


/** Enable all interrupts */
#define GTCORE_R_ALL_INT_EN  (GTCORE_R_TC0_INT_EN     | \
                              GTCORE_R_TC1_INT_EN     | \
                              GTCORE_R_LNK_ERR_INT_EN | \
                              GTCORE_R_RX_NET_INT_EN)

/** @} */

/* LINK_CTL */

/**
@defgroup LinkCtl BAR0 Offset 0x10 | Link Control (LINK_CTL) 
Link Control(LINK_CTL)  BAR0 Offset 0x10
@{
*/
/** Link 0 Laser Enable */
#define GTCORE_R_LAS_0_EN       0x1
/** Link 1 Laser Enable */
#define GTCORE_R_LAS_1_EN       0x2
/** Link Select Control (RX) */
#define GTCORE_R_LNK_SEL        0x10
/** Node ID � These bits represent the node identification number.*/
#define GTCORE_R_NODE_ID        0xFF00
/** Host TX Enable */
#define GTCORE_R_TX_EN          0x10000
/** Host RX Enable */
#define GTCORE_R_RX_EN          0x20000
/** Network RT Enable */
#define GTCORE_R_RT_EN          0x40000
/** Electronic Wrap. This bit controls loop back operation of the user interface�s data stream. */
#define GTCORE_R_WRAP           0x80000
/** Write Me Last */
#define GTCORE_R_WML            0x100000
/** Interrupt Self */
#define GTCORE_R_INT_SELF       0x200000
/** HUNT ID � Set to the Node ID of the respective node whose traffic will be measured using the HNT_TRFC_CNTR */
#define GTCORE_R_HNT_ID         0xFF000000
/**
@}
*/

/* LINK_STAT */

/**
@defgroup LinkStat BAR0 Offset 0x14 | Link Status(LINK_STAT) 
Link Status(LINK_STAT) � BAR0 Offset 0x14
@}
*/
/** Link Down */
#define GTCORE_R_LNK_DOWN       0x1
/** Decoding Error  ( subject to redefinition, use not recommended ) */
#define GTCORE_R_DEC_ERR        0x2
/** Synchronization error ( subject to redefinition, use not recommended ) */
#define GTCORE_R_SYNC_ERR       0x4
/** Checksum Error ( subject to redefinition, use not recommended ) */
#define GTCORE_R_CRC_ERR        0x8
/** End of Frame Error ( subject to redefinition, use not recommended ) */
#define GTCORE_R_EOF_ERR        0x10
/** Protocol Error ( subject to redefinition, use not recommended ) */
#define GTCORE_R_PRTCL_ERR      0x20

/** RX FIFO Error ( subject to redefinition, use not recommended ) */
#define GTCORE_R_RXF_ERR        0x40
/** RX Strip Error ( subject to redefinition, use not recommended ) */
#define GTCORE_R_RX_STRP_ERR    0x80
/** Expired Message ( subject to redefinition, use not recommended ) */
#define GTCORE_R_EXP_MSG_ERR    0x1000
/** Link Up.  This bit reflects the current status of the link */
#define GTCORE_R_LNK_UP         0x20000
/** Link 0 Signal Detect */
#define GTCORE_R_LAS_0_SD       0x40000
/** Link 1 Signal Detect */
#define GTCORE_R_LAS_1_SD       0x80000
/** Redundant Link Capable */
#define GTCORE_R_RLC            0x800000
/** Network Age. 8-bit field indicating the age value of the last native message received */
#define GTCORE_R_AGE            0xFF000000
/**
@}
*/

/* MISC_FNCTN */
/** 
@defgroup MiscFunctn BAR0 Offset 0x20 | Miscellaneous Function (MISC_FNCTN)
Miscellaneous Function (MISC_FNCTN)
@{
*/
/** Disable Read Bypass ( subject to redefinition, use not recommended ) */
#define GTCORE_R_DIS_RD_BYP     0x200
/** Upstream Node ID */
#define GTCORE_R_UNID           0xFF000000
/**
@}
*/

/** TQ_CTL_TC0 */
/**
@defgroup TQCtlTc0 BAR0 Offset 0xC8 | Transaction Queue Control(TQ_CTL_TC0)
Transaction Queue Control(TQ_CTL_TC0)
@{
*/
/** Producer Index for transaction queue */
#define GTCORE_R_TQ_PRD_IDX     0x0000001F
/** Consumer Index for transaction queue */
#define GTCORE_R_TQ_CON_IDX     0x00001F00
/** Transaction Queue length. Place the number of transaction queue entries
    minus one here, where the actual number of entries is a power of 2. */
#define GTCORE_R_TQ_LEN         0x001F0000
/** Enable Transaction Queue */
#define GTCORE_R_TQ_EN          0x01000000
/** Reset Queue */
#define GTCORE_R_TQ_RST         0x02000000
/** Abort Queue */
#define GTCORE_R_TQ_ABRT        0x04000000
/** Queue paused */
#define GTCORE_R_TQ_PSD         0x20000000
/** Entries Available */
#define GTCORE_R_TQ_AVAIL       0x40000000

/** @brief Preserve. 
 When this register is written with this bit set, only the producer index 
 is written (discarding any changes to all other fields). */
#define GTCORE_R_TQ_PRSRV       0x80000000

/**
@}
*/

/* ****** Network Management Registers *****  */
/**
@defgroup NNR Network management registers (BAR1)
Network management registers locate in BAR1
@{
*/
/** @brief  Network Management bar size */
#define GTCORE_NM_REGISTER_SIZE    0x2000

/** @brief Network to Host Interrupt Queue Data (NHI_QDATA[0:255]).
 Use (GTCORE_NM_NHI_QID + Qentry#*8). BAR1 0ffser 0x800 to 0x1000 */
#define GTCORE_NM_NHI_QID     0x0800

/** @brief  Transmit HBI #(TX_HBI[0:31]).
 Use (GTCORE_NM_TX_HBI + HBI Number * 4). BAR1 offset 0x1000 to 0x1080 */
#define GTCORE_NM_TX_HBI      0x1000    

 /** @brief Transmit HUI #(TX_HUI [0:255]).
 use (GTCORE_NM_TX_HUI + (destination ID * 4)).BAR1 offset 0x1800 to 0x1c00 */
#define GTCORE_NM_TX_HUI      0x1800

/* NM_NHI_QID bit defs */

/** @brief Host Interrupt Type.
 indicates that the current read entry in the NHI_Q is a HBI(Host Unicast Interrupt) event.
 0 indicates that the current read entry in the NHI_Q is a HUI(Host Broadcast Interrupt) event.
 This field is only valid if the 'NHI Data Present' bit is set  */
#define GTCORE_NM_HI_TYPE   0x10000

/** @} */

/**********************************************************/
/********************* GLOBAL DEFS ************************/
/**********************************************************/

extern char gtcoreStatNames[];
extern uint32 gtcoreStatNameIndex[];

/**********************************************************/
/****************** CORE FUNCTION DEFS ********************/
/**********************************************************/

/* the following can be used before calling gtcoreInit() */
void gtcoreFixRegSwapping(scgtDevice *dev);
uint32 gtcoreGetPopMemSize(scgtDevice *dev);

/* use the remaining functions after calling gtcoreInit() */
uint32 gtcoreInit(scgtDevice *dev);
void gtcoreDestroy(scgtDevice *dev);
uint32 gtcoreGetState(scgtDevice *dev, uint32 stateID, uint32 *val);
uint32 gtcoreSetState(scgtDevice *dev, uint32 stateID, uint32 val);
uint32 gtcoreGetDeviceInfo(scgtDevice *dev, scgtDeviceInfo *deviceInfo);

#ifdef __cplusplus
void gtcorePutIntr(scgtDevice *dev, const scgtInterrupt *intr) noexcept;
gtcoreExch * gtcoreGetExchange(_In_ scgtDevice *dev, const uint8 direction) noexcept;
/** debugging for pre-compiled core */
uint32 gtcoreSizeOfSCGTDevice(void) noexcept;
#else
void gtcorePutIntr(scgtDevice *dev, const scgtInterrupt *intr);
gtcoreExch * gtcoreGetExchange( scgtDevice *dev, const uint8 direction);
uint32 gtcoreSizeOfSCGTDevice(void);
#endif
uint32 gtcoreGetIntr(scgtDevice *dev, scgtGetIntrBuf *gibuf);
uint32 gtcoreSendIntr(scgtDevice *dev, const scgtInterrupt *intr);

uint32 gtcoreGetStats(scgtDevice *dev, scgtStats *stats);


void gtcoreTransfer(scgtDevice *dev, gtcoreExch *exch, const uint8 direction);
void gtcoreCancelTransfer(scgtDevice *dev, gtcoreExch *exch, const uint8 direction);

uint32 gtcoreHandleInterrupt(scgtDevice *dev);
void gtcoreCompleteDMA(scgtDevice *dev);


#endif /* __GT_CORE_H__ */
