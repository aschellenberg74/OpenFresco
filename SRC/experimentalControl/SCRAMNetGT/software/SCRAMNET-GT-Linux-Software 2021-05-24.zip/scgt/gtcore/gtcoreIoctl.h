/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2020 Curtiss-Wright Controls Electronic System, Inc.         */
/*     dtn_support@curtisswright.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* See the GNU Lesser General Public License for more details.                */
/*                                                                            */
/******************************************************************************/
/**
@file gtcoreIoctl.h
@brief IOCTL data structure definitions
**/

#ifndef __GTIOCTL_H__
/** macro to prevent multiple inclusions */
#define __GTIOCTL_H__

#include "systypes.h"
#include "gtucore.h"

/** gtcodeioctl.h file revision updated 5/17/19 */
#define FILE_REV_GTCOREIOCTL_H  "5"

/**************************************************************************/
/**************************  D A T A  T Y P E S  **************************/
/**************************************************************************/

/*
 * The following data types are used by the API to pass information
 * to and from the driver.  They are not to be used by user applications.
 * The common data types seen by the user are defined in gtcore/gtucore.h
 * The reserved member of these structures is used by the Windows driver
 * to return status info to the driver.
 */

/*
 * STRUCTURE NOTE:
 * Each structure containing pointers must be accompanied by a alternate
 * version to be used by 64-bit drivers when interfacing a 32-bit app.
 * These special structure versions should have all pointer-type members
 * replaced with 32-bit integer-type members of the same name.
 */


/**
 * @brief SCGT state structure for GET_STATE and SET_STATE IOCTL calls
 */

typedef struct _scgtState
{
    uint32 reserved;       /**< reserved **/
    uint32 stateID;        /**< State ID number to read/write **/
    uint32 val;            /**< Value to write or value read **/
} scgtState;


/**
 * @brief scgtXfer structure for READ and WRITE IOCTL
 */
typedef struct _scgtXfer
{
    uint32 reserved;          /**< Reserved */
    uint32 flags;             /**< Flag to indicate transfer type */
    uint32 gtMemoryOffset;    /**< Offset in gtMemory to start transfer */
    uint32 bytesToTransfer;   /**< Number of byte requested to transfer */
    uint32 bytesTransferred;  /**< Number if bytes transfered */
    uint64 pDataBuffer;       /**< Address of data buffer */
    uint64 pInterrupt;        /**< Address of scgtInterrupt *pInterrupt */
} scgtXfer;


/**
 * @brief scgtRegister structure for READ_CR, WRITE_CR, READ_NMR and WRITE_NMR IOCTL calls
 **/
 typedef struct _scgtRegister
{
    uint32 reserved;    /**< Reserved */
    uint32 offset;      /**< Offset to read/write from */
    uint32 val;         /**< Value to write or value read */
} scgtRegister;


/**
 * @brief scgtMemMapInfo structure used by API to map/umap memory using mmap() and munmap()
 **/
typedef struct _scgtMemMapInfo
{
    uint32 reserved;     /**< Reserved */
    uint32 memSize;      /**< Amount of memory to map */
    uint64 memVirtAddr;  /**< Virtual address of memory */
    uint64 memPhysAddr;  /**< Physical address of memory */
} scgtMemMapInfo;


/**
 * @brief driver statistics structure
 **/
typedef struct _scgtStats
{
    uint64 stats;             /**< Address of uint32 *stats */
    uint64 names;             /**< Address of char *names; */
    uint32 firstStatIndex;    /**< Offset to first name  value to read */
    uint32 num;               /**< Number of values to read */
    uint32 reserved;          /**< Reserved */
} scgtStats;


/**
 * @brief get interrupt ioctl structure
 **/
typedef struct _scgtGetIntrBuf
{
    uint64 intrBuf;           /**< Address of scgtInterrupt *intrBuf */
    uint32 bufSize;           /**< Size of buffer */
    uint32 seqNum;            /**< Sequence number */
    uint32 timeout;           /**< Timeout value indicating how long to wait for interrupts */
    uint32 numInterruptsRet;  /**< Number of interrupts returned */
    uint32 reserved;          /**< Reserved */
} scgtGetIntrBuf;



#endif /* __GTIOCTL_H__ */
