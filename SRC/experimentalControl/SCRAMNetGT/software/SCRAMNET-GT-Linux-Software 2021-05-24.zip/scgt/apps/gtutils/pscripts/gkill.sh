#!/bin/sh
#GT gkill.sh    Rev. Fri Sep  3 11:12:04 EDT 2004 - test, private, Linux only, sl240 good
#This script uses gttp/xgttp to send data patterns from a file.
#It is intended to exercise remote reciver for data-dependent problems.

ARG=$#
UNIT="0"
APP="xgttp"
SEC="1"
PSET="15A0EB20 76FC7DD3 65A56821 663CCF86 48FC7EA5 1278D79E 6B78D39E 2AA53741"

if   [ "$1" == "" ]; then
    echo "Usage: $0 [-g][-u unit][-s seconds] [-f ip_file]"
    echo "       -g         - use GT rather then sl240"
    echo "       -u unit    - unit number (default 0)"
    echo "       -f ip_file - text file with patterns (default internal patterns)"
    echo "       -s seconds - time to run each pattern (default 1 s)"
    echo "You may want to start xgttp/gttp -s -1 on remote end first"
    echo "Example: $0 -s 1 -f patt1.txt"
    exit 0
fi

while [ $ARG -gt 0 ]; do
    case "$1" in
        "-g") APP="gttp"; shift 1;;
        "-u") UNIT=$2; shift 2;;
        "-s") SEC=$2; shift 2;;
        "-f") FILE=$2; PSET=`cat $FILE`
            echo seen -f $FILE with  patterns $PSET; shift 2;;
        *) ARG=0;;
    esac
    ((ARG--))
done

TC1=`echo $PSET |wc`
TC=`echo $TC1 | cut -d " " -f 2`
echo testing $TC patterns

COUNT=1
for patt in $PSET;
do
   
   echo 0x$patt = pattern $COUNT of $TC  ==============================
   ./$APP -u $UNIT -w -s $SEC -d 0x$patt
   ((COUNT++))
done
