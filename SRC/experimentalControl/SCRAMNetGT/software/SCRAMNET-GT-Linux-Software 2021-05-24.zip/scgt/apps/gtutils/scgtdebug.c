/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2020 Curtiss-Wright Controls Electronic System, Inc.         */
/*     dtn_support@curtisswright.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/
/// @file scgtdebug.c
/// @brief  Application source code for altering scgt debug print flags

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "scgtapi.h"

#define  GT_READ 0
#define  GT_WRITE 1

int main(int argc, char* argv[])
{
    uint32 value=0xFFFFFFFF;
    scgtHandle gtHndl;
    char ch;
    int mode = GT_READ;

    if (argc == 1)
    {
        printf("%s [-r | value ]\n", argv[0]);
        printf("\n");

        //printf("No argument found. set debug level to 0x%x\n", value);
    }

    if (argc > 1)
    {
        if (strncmp(argv[1], "-r", 2) == 0)
        {
            mode = GT_READ;
        }        
        else
        {
            mode = GT_WRITE;
            value = strtoul(argv[1], NULL, 16);
        }
    }

    
    if (scgtOpen(0, &gtHndl) != SCGT_SUCCESS)
    {
        printf("error opening file\n");
        return 1;
    }

    if (mode == GT_WRITE)
    {
        printf("Writing 0x%x to SCGT debug level\n", value);
        scgtSetDebug(&gtHndl, value);
    }
    else if (mode == GT_READ)
    {
        printf("Reading SCGT debug level\n");
        value = scgtGetDebug(&gtHndl);
        printf("SCGT debug level = 0x%x\n", value);
    }

    scgtClose(&gtHndl);
    printf("Press any key to exit\n");
    ch = getc(stdin);
}

