/******************************************************************************/
/*                                 SCRAMNet GT                                 */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2020 Curtiss-Wright Controls Electronic System, Inc.         */
/*     dtn_support@curtisswright.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/


/*
   This file is a workaround for Windows' deficient build environment.
   You cannot specify source files across multiple directories in the 'sources'
   file.
*/

#include "../ksys/ksys.c"

#include "../../gtcore/gtcore.c"
#include "../../gtcore/gtcorexfer.c"

