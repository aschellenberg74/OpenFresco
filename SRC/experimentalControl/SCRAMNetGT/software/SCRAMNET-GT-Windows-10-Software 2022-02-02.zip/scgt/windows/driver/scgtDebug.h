/******************************************************************************/
/*                                 SCRAMNet GT                                 */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2020 Curtiss-Wright Controls Electronic System, Inc.         */
/*     dtn_support@curtisswright.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/
/**
@file scgtDebug.h
@brief scgt debug flags and print macros
**/

/** Display ERROR messages (SCGT_DBG_ERROR) */
#define SCGT_DBG_ERROR        0x00000001
/** Display waring messages */
#define SCGT_DBG_WARNING      0x00000002
/** Display informational messages */
#define SCGT_DBG_INFO         0x00000004
/** Display version messages */
#define SCGT_DBG_VERSION      0x00000008
/** Display DMA related messages */
#define SCGT_DBG_DMA          0x00000010
/** Display primary IOCTL messages */
#define SCGT_DBG_IOCTL        0x00000020
/** Display secondary IOCTL messages */
#define SCGT_DBG_IOCTL2       0x00000040
/** Display memory mapping and umapping messages */
#define SCGT_DBG_MAP          0x00000080
/** Display 64 bit related messages */
#define SCGT_DBG_IS64         0x00000100
/** Display IOCTL write messages */
#define SCGT_DBG_WRITE        0x00000200
/** Display IOCTL Read messages */
#define SCGT_DBG_READ         0x00000400
/** Display get/put Interrupt messages */
#define SCGT_DBG_INTR         0x00000800
/** Display halt return resources messages */
#define SCGT_DBG_HALT         0x00001000
/** Display plug and play messages */
#define SCGT_DBG_PNP          0x00002000
/** Display scgtStartDevice initialization messages */
#define SCGT_DBG_INIT         0x00004000
/** Display SCGT Set/Get state messages  */
#define SCGT_DBG_STATE        0x00008000
/** Display Network Management /control read/write register messages */
#define SCGT_DBG_REG          0x00010000
/** Display scgtIoctlXfer() and scgtXferChunk() transfer messages */
#define SCGT_DBG_XFER         0x00020000
/** Display scgtBuildChainList() read/write data buffer sizes. */
#define SCGT_DBG_DATA         0x00040000
/** Display scgtDrvExchChain() exchange queue messages (SCGT_DBG_TRQUEUE) */
#define SCGT_DBG_EXCH         0x00080000
/** Display scgtDrvTrQueue() transaction queue messages */
#define SCGT_DBG_TRQUEUE      0x00100000
/** display scgtIoctlPOWER() Power messages */
#define SCGT_DBG_POWER        0x00200000
/** Display function flow in/out */
#define SCGT_DBG_FLOW         0x00400000
/** I/O scgtStallQueues() scgtUntallQueues() Queue state info */
#define SCGT_DBG_QUEUE        0x00800000
/** Show Increment and decrement calls and values. */
#define SCGT_DBG_INC_DEC      0x01000000
/** time Stamp debug messages */
#define SCGT_TIMESTAMP        0x80000000

#ifdef PLATFORM_WIN
/* debug print prototypes. Defined in scgt.cpp */
NTSTATUS ScgtDbgPrint( _In_ const ULONG flag, _In_ const LPSTR Format, ...);
NTSTATUS ScgtDbgPrintNoPrefix(_In_ const ULONG flag, _In_ LPSTR Format, ...);
#elif defined ( __GNUC__ )
extern long scgtDbglevel;
#define ScgtDbgPrint(flag, ...) if( flag & scgtDbgLevel)  fprintf(stderr,__VA_ARG__)
#else
#define ScgtDbgPrint(...) 
#endif
