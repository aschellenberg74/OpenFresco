/******************************************************************************/
/*                                 SCRAMNet GT                                 */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2020 Curtiss-Wright Controls Electronic System, Inc.         */
/*     dtn_support@curtisswright.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* This software file (the "File") is owned and distributed by Curtiss-Wright */
/* under the following alternative licensing terms.  Once you have made an    */
/* election to distribute the File under one of the following license         */
/* alternatives, please                                                       */
/*   (i) delete this introductory statement regarding license alternatives,   */
/*   (ii) delete the license alternative that you have not elected to use and */
/*   (iii) preserve the Curtiss-Wright copyright notice above.                */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* GPL license:                                                               */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* MIT license:                                                               */
/* The contents of this file are subject to the MIT Public License (the       */
/* "License"); you may not use this file except in compliance with the License*/ 
/*                                                                            */
/* Permission is hereby granted, free of charge, to any person obtaining a    */
/* copy of this software and associated documentation files (the "Software"), */
/* to deal in the Software without restriction, including without limitation  */
/* the rights to use, copy, modify, merge, publish, distribute, sublicense,   */
/* and/or sell copies of the Software, and to permit persons to whom the      */
/* Software is furnished to do so, subject to the following conditions:       */
/*                                                                            */
/* The above copyright notice and this permission notice shall be included    */
/* in all copies or substantial portions of the Software.                     */
/*                                                                            */
/* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR */
/* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,   */
/* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL    */
/* THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER */
/* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,            */
/* ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR      */
/* OTHER DEALINGS IN THE SOFTWARE.                                            */
/*                                                                            */
/******************************************************************************/


/******************************************************************************/
/*                                                                            */
/*    Module      : scgtdrv.h                                                 */
/*    Description : SCRAMNet GT driver external interface definition          */
/*    Platform    : Windows 2000                                              */
/*                                                                            */
/******************************************************************************/
/**
@file scgtdrv.h
@brief scgt driver file IOCTL and other definitions for driver and user programs.
**/

#ifndef __SCGT_DRV_H__
/** macro to prevent multiple inclusion */
#define __SCGT_DRV_H__ 

/** scgtdrv.h file version  updated 8/29/2019 */
#define FILE_REV_SCGTDRV_H   "3"  

/**************************************************************************/
/**************************  D E F I N E S ********************************/
/**************************************************************************/

/** Maximum of supported cards */
#define SCGT_MAX_DEVICES  16 

#ifdef UNICODE
/** Symbolic name used to access gt card */
#define SCGT_DEV_FILE_STR  L"\\\\.\\scgt" 
#else
/** Symbolic name used to access gt card */
#define SCGT_DEV_FILE_STR  "\\\\.\\scgt"
#endif

/** Scatter gather list length */
#define SCGT_SGPTR_ARRAY_LEN 1 
/** Max chain size  256K  */
#define SCGT_MAX_CHUNK_SIZE  0x40000
 /**< Number of Links in DMA chain list */
#define SCGT_DMA_CHAIN_LEN  (SCGT_MAX_CHUNK_SIZE/PAGE_SIZE+2)
//#define SCGT_DMA_CHAIN_LEN  1 
/**< Flag for ifdef code */
#define SCGT_EXCH_CHAIN_MAP_PER_EXCH

/** Number of DMA buffers per direction */
#define SCGT_DMA_NUM_BUFFERS  2

/******************************************************************/
/************************* IOCTL Defs *****************************/
/******************************************************************/
/** @addtogroup IOCTLCode
@{ **/
/** Ioctl control base number */
#define SCGT_IOCTL_BASE       0xb00
/** Macro for defining SCGT control values */
#define SCGT_IOCTL_CODE(num)  CTL_CODE(FILE_DEVICE_UNKNOWN, SCGT_IOCTL_BASE + num, METHOD_BUFFERED, FILE_READ_ACCESS)
/** Map memory Ioctl */
#define SCGT_IOCTL_MAP_MEM        SCGT_IOCTL_CODE(6)
/** Unmap memory Ioctl */
#define SCGT_IOCTL_UNMAP_MEM        SCGT_IOCTL_CODE(7)  
/** Write to GT Ioctl */
#define SCGT_IOCTL_WRITE            SCGT_IOCTL_CODE(8) 
/** Read from GT Ioctl */
#define SCGT_IOCTL_READ             SCGT_IOCTL_CODE(9) 
/** Read control register Ioctl */
#define SCGT_IOCTL_READ_CR          SCGT_IOCTL_CODE(10) 
/** Write to control register Ioctl */
#define SCGT_IOCTL_WRITE_CR         SCGT_IOCTL_CODE(11) 
/** Memory map info Ioctl */
#define SCGT_IOCTL_MEM_MAP_INFO     SCGT_IOCTL_CODE(12) 
/** Get device info Ioctl */
#define SCGT_IOCTL_GET_DEVICE_INFO  SCGT_IOCTL_CODE(13)
/** Get gt state Ioctl */
#define SCGT_IOCTL_GET_STATE        SCGT_IOCTL_CODE(14)
/** Set gt state Ioctl */
#define SCGT_IOCTL_SET_STATE        SCGT_IOCTL_CODE(15)
/** Read network management Ioctl */
#define SCGT_IOCTL_READ_NMR         SCGT_IOCTL_CODE(16)
/** Write network management Ioctl */
#define SCGT_IOCTL_WRITE_NMR        SCGT_IOCTL_CODE(17)
/** Get GT stats */
#define SCGT_IOCTL_GET_STATS        SCGT_IOCTL_CODE(18)
/** Get gt interrupt stats */
#define SCGT_IOCTL_GET_INTR         SCGT_IOCTL_CODE(19)

/* debugging */
/** Put interrupt debug Ioctl */
#define SCGT_IOCTL_PUT_INTR         SCGT_IOCTL_CODE(20)
/** Set debug print mask Ioctl*/
#define SCGT_IOCTL_DBG_FLAG         SCGT_IOCTL_CODE(21)
/** Get debug print mask Ioctl */
#define SCGT_IOCTL_GET_DBG_FLAG     SCGT_IOCTL_CODE(22)
/** @} */
#endif /* __SCGT_DRV_H__ */


#define scgtTrQueue(a,b,c,d)     scgtDrvTrQueue(a,b,c,d)
#define scgtExchChain(a,b,c,d,e) scgtDrvExchChain(a,b,c,d,e)

