/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2020 Curtiss-Wright Controls Electronic System, Inc.         */
/*     dtn_support@curtisswright.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

/**
 * @file gtcoreTypes.h
 * @brief GT core type definitions
 */

#ifndef __GTCORE_TYPES_H__
#define __GTCORE_TYPES_H__ /**< macro to prevent multiple inclusions */

#include "ksys.h"
#include "gtucore.h"
#include "scgtdrv.h"

/** Core file types revision updated 5/18/19 */
#define FILE_REV_GTCORETYPES_H  "5"

/** Number of exchanges per direction */
#define GTCORE_EXCH_CNT  4  

/********************************************************************/
/************************* STATISTICS *******************************/
/********************************************************************/

enum
{
    SCGT_STATS_NS_ENTRY,
    SCGT_STATS_NAMES_STR_LEN,
    SCGT_STATS_ISR,
    SCGT_STATS_DPC,
    SCGT_STATS_DPC_DMA,
    SCGT_STATS_INTRS,
    SCGT_STATS_TC0_INTRS,
    SCGT_STATS_TC1_INTRS,
    SCGT_STATS_W_ENTRY_SEM_1,
    SCGT_STATS_W_ENTRY_SEM_2,
    SCGT_STATS_R_ENTRY_SEM_1,
    SCGT_STATS_R_ENTRY_SEM_2,
    SCGT_STATS_W_EXCH_SEM_0,
    SCGT_STATS_W_EXCH_SEM_1,
    SCGT_STATS_W_EXCH_SEM_2,
    SCGT_STATS_W_EXCH_SEM_3,
    SCGT_STATS_R_EXCH_SEM_0,
    SCGT_STATS_R_EXCH_SEM_1,
    SCGT_STATS_R_EXCH_SEM_2,
    SCGT_STATS_R_EXCH_SEM_3,
    SCGT_STATS_NET_INTRS,
    SCGT_STATS_LINK_ERRORS,
    SCGT_STATS_GET_INTR_TIMER,
    SCGT_STATS_GET_INTR_WAIT_CNT,
    SCGT_STATS_NET_INT_CNT_ROLL,
    SCGT_STATS_NET_INT_CNT_FIX,
    SCGT_STATS_NET_INT_CNT_0,
    SCGT_STATS_NET_INT_CNT_1,
    SCGT_STATS_NET_INT_CNT_FIX_FAILED,
    SCGT_STATS_SW_NET_INT_CNT_VAL,
    SCGT_STATS_HW_NET_INT_CNT_VAL,
    SCGT_STATS_NUM_STATS
};

/********************************************************************/
/************************* DEVICE CORE ******************************/
/********************************************************************/

#define SCGT_DEVICE_CORE  \
        /*************************************************************/ \
        /* the following members should be initialized by the driver */ \
        uint8 unitNum;  /**<Unit number */                              \
        char boardLocationStr[128];   /**< board location string */    \
        void *mapData;   /**< passed to ksysMapVirtToBus */               \
        uint32 memSize;  /**< mapped memSize */                           \
        /*************************************************************/ \
        /* the following members are initialized by gtcoreInit()     */ \
        uint32 popMemSize;  /**< populated memSize */                   \
        gtcoreExchMgrData rexch;  /**< Receive Exchange */              \
        gtcoreExchMgrData wexch;  /**< Write  Exchange */               \
        gtcoreExch *completedExchQ[GTCORE_EXCH_CNT * 2];  /**<exchange queue*/   \
        uint32 completedHeadIndex;    /**< completed queue head index*/ \
        uint32 completedTailIndex;   /**< completed queue tail index */   \
        uint32 stats[SCGT_STATS_NUM_STATS];    /**< statistics */         \
        gtcoreIntrQData intrQData;         /**< interrupt queue data */   \
        uint32 hwNHIQIntCntrVal;  /**< GTCORE_R_NHIQ_INT_CNTR value*/ \

 
/*
 * core data types (kernel level)
 */
/** @brief  gt core exchange info */
 typedef struct _gtcoreExch
{
    /*
     * SGPTR_ARRAY_LEN, DMA_CHAIN_LEN and CACHE_LINE_SIZE are defined
     * in scgtdrv.h since they are system specific
     */
    volatile uint32         gtMemoryOffset;    /**< Offset into shared memory offset */
    volatile uint32         bytesToTransfer;   /**< Total bytes to be transferred */
    volatile uint32         bytesTransferred;  /**< Running total of bytes transferred */
    volatile scgtInterrupt *intr;              /**< Network interrupt */
    volatile uint32         flags;             /**< Control flags */

    volatile uint32*   sgList[SCGT_SGPTR_ARRAY_LEN]; /**< Scatter gather list */
    ksysSemB           compSem;        /**< Signals exchange completion */
    volatile uint32    state;          /**< State of exchange (GTCORE_EXCH_UNUSED etc.) */ 
    volatile uint32    status;         /**< Completion status of the exchange  */
    volatile uint32    *tqe;           /**< Pointer to the transaction queue entry */
    volatile uint64    sgListPhysAddr[SCGT_SGPTR_ARRAY_LEN]; /**< physical address of sgList */
    volatile uint32    exchQIndex;     /**< Index in the exchange array for this exchange */
    volatile uint32*   sgSpace;        /**< Unaligned pointer to memory holding sgList */
    void*              sgDmaHandle;    /**< Passed to ksysDma2Malloc and friends */
    uint8              direction;      /**< Direction read/write */
    uint32             notUsed[8];     /**< Space reserved to accommodate unusual cases */
} gtcoreExch;


/** @brief gt core exchange manager data 
 scgt core interrupt exchange queue management data */
typedef struct _gtcoreExchMgrData
{
    volatile uint32   headIndex;    /**< Current head index of exchange queue */
    volatile uint32   tailIndex;    /**< Current tail index of exchange queue */
    uint32*           trQueue;      /**< Aligned transaction queue address */
    uint32*           trSpace;      /**< Transaction queue address space */
    uint64            trPhysical;   /**< Memory aligned PCI bus address of transaction queue*/
    void*             trDmaHandle;  /**< Passed to ksysDma1Malloc and friends */
    uint32            notUsed[8];   /**< Space reserved to accommodate unusual cases */
    gtcoreExch        exchQ[GTCORE_EXCH_CNT]; /**< exchange queue **/
} gtcoreExchMgrData;

/** @brief scgt interrupt queue data 
 scgt interrupt queue data */
typedef volatile struct _gtcoreIntrQData
{
    scgtInterrupt *intrQ;   /**< Interrupt data */
    uint32 head;            /**< Interrupt queue head pointer */
    uint32 seqNum;          /**< Sequence number */
} gtcoreIntrQData;

#endif   /* __GTCORE_TYPES_H__ */
