/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2020 Curtiss-Wright Controls Electronic System, Inc.         */
/*     dtn_support@curtisswright.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* See the GNU Lesser General Public License for more details.                */
/*                                                                            */
/******************************************************************************/

/**
 * @file gtucore.h
 * @brief    core portions available to user level API
 */

#ifndef __GT_UCORE_H__
/** Macro to prevent multiple inclusions */
#define __GT_UCORE_H__

#include "systypes.h"

/** gtcucore.hpp file version updated  05/21/2019 */
#define FILE_REV_GTUCORE_H  "7"
/* revision 7 updated added doxygen style comments */

/******************************************************************/
/************************ ERROR CODES *****************************/
/******************************************************************/

/**
@defgroup ERRCodes SCRAMNet GT Error codes
SCRAMNet GT Error codes definitions
@{
*/

/** Command completed successfully */
#define SCGT_SUCCESS                   0
/** System error occurred */
#define SCGT_SYSTEM_ERROR              1
/** Bad parameter value */
#define SCGT_BAD_PARAMETER             2
/** Driver error */
#define SCGT_DRIVER_ERROR              3
/** Command timed out */
#define SCGT_TIMEOUT                   4
/** Command unsupported */
#define SCGT_CALL_UNSUPPORTED          5
/** Insufficient resources */
#define SCGT_INSUFFICIENT_RESOURCES    6
/** Link error */
#define SCGT_LINK_ERROR                7
/** Missed interrupts */
#define SCGT_MISSED_INTERRUPTS         8
/** Driver missed interrupts */
#define SCGT_DRIVER_MISSED_INTERRUPTS  9
/** DMA not supported */
#define SCGT_DMA_UNSUPPORTED          10
/** Hardware Error */
#define SCGT_HARDWARE_ERROR           11

/** end ERRCodes
@} 
*/

/******************************************************************/
/*********************** STATE IDs ********************************/
/******************************************************************/

/** @defgroup stateIds  SCRAMNet GT state id values.
SCRAMNet GT state ids definitions.
@{ 
*/

/** Node ID */
#define SCGT_NODE_ID                0
/** Active link */
#define SCGT_ACTIVE_LINK            1
/** Number of link errors */
#define SCGT_NUM_LINK_ERRS          2
/** Electronic wrap mode */
#define SCGT_EWRAP                  3
/** Write me last */
#define SCGT_WRITE_ME_LAST          4
/** Unicast interrupt mask */
#define SCGT_UNICAST_INT_MASK       5
/** Broadcast interrupt mask */
#define SCGT_BROADCAST_INT_MASK     6
/** Interrupt self enable */
#define SCGT_INT_SELF_ENABLE        7
/** Ring size */
#define SCGT_RING_SIZE              8
/** Upstream node Id */
#define SCGT_UPSTREAM_NODE_ID       9
/** Network timer value */
#define SCGT_NET_TIMER_VAL         10
/** Latency timer value */
#define SCGT_LATENCY_TIMER_VAL     11
/** Shared memory traffic counter */
#define SCGT_SM_TRAFFIC_CNT        12
/** Spy shared memory traffic counter*/
#define SCGT_SPY_SM_TRAFFIC_CNT    13
/** Spy node id */
#define SCGT_SPY_NODE_ID           14
/** Transmit enable */
#define SCGT_TRANSMIT_ENABLE       15
/** Receive enable */
#define SCGT_RECEIVE_ENABLE        16
/** Retransmit enable */
#define SCGT_RETRANSMIT_ENABLE     17
/** Laser 0 enable */
#define SCGT_LASER_0_ENABLE        18
/** Laser 1 enable */
#define SCGT_LASER_1_ENABLE        19
/** Link up */
#define SCGT_LINK_UP               20
/** Signal detected laser 0 */
#define SCGT_LASER_0_SIGNAL_DET    21
/** Signal detected laser 1 */
#define SCGT_LASER_1_SIGNAL_DET    22
/** D64 enable */
#define SCGT_D64_ENABLE            23
/** Byte swap enable */
#define SCGT_BYTE_SWAP_ENABLE      24
/** Word swap enable */
#define SCGT_WORD_SWAP_ENABLE      25
/** Link error interrupt enable */
#define SCGT_LINK_ERR_INT_ENABLE   26
/** Read bypass enable */
#define SCGT_READ_BYPASS_ENABLE    27

/**
end stateIds 
@} 
*/

/*****************************************************************/
/********************* INTERRUPT TYPES ***************************/
/*****************************************************************/

/**
@defgroup IntType Interrupt types bit mask
SCRAMNet GT interrupt types bit mask definitions
@{ 
*/

/** Unicast interrupt */
#define SCGT_UNICAST_INTR     0
/** Broadcast interrupt */
#define SCGT_BROADCAST_INTR   1
/** Error interrupts */
#define SCGT_ERROR_INTR       2
/** No interrupt */
#define SCGT_NO_INTR          3
/**
@} 
*/ 

/*****************************************************************/
/********************* READ/WRITE FLAGS **************************/
/*****************************************************************/
/**
@defgroup ReadWriteFlags Read write control bit mask flags
SCRAMNet GT Read or write bit mask flag definitions
@{ 
*/

/** Use programed I/O (PIO) for transfer */
#define SCGT_RW_PIO               0x1
/** Byte swap DMA data */
#define SCGT_RW_DMA_BYTE_SWAP     0x2
/** Word Swap DMA data */
#define SCGT_RW_DMA_WORD_SWAP     0x4
/** DMA to physical address */
#define SCGT_RW_DMA_PHYS_ADDR     0x8
/** Use 8 bit PIO */
#define SCGR_RW_PIO_8_BIT         0x10
/** Use 16-bit PIO */
#define SCGR_RW_PIO_16_BIT        0x20

/**
@} 
*/ 

/**********************************************************/
/****************** CORE DATA TYPES ***********************/
/**********************************************************/

/*
 * device info structure
 */

/** @brief scgt Device information */
typedef struct _scgtDeviceInfo
{
    uint32 reserved;              /**< Reserved */
    char driverRevisionStr[128];  /**< String containing driver revision info */
    char boardLocationStr[128];   /**< String describing board location */
    uint32 unitNum;               /**< Unit number */
    uint32 popMemSize;            /**< Populated memory size in bytes */
    uint32 mappedMemSize;         /**< Mapped memory size in bytes */
    uint32 numLinks;              /**< Number of supported links */
    uint32 revisionID;            /**< Firmware revision ID */
} scgtDeviceInfo;


/*
 * interrupt structure
 */
/** @brief scgt interrupt information */
 typedef struct _scgtInterrupt
{
    uint32 type;          /**< SCGT_UNICAST_INTR, SCGT_BROADCAST_INTR, or 
                             SCGT_ERROR_INTR */
    uint32 sourceNodeID;  /**< Source node ID */
    uint32 id;            /**< 0 to 31 designating the interrupt number for 
                             broadcast interrupts, destination node ID for 
                             sending unicast interrupts. */ 
    uint32 val;           /**< User defined data sent with broadcast or unicast 
                             interrupt or error code if error interrupt */
    uint32 seqNum;        /**< Sequence number */
} scgtInterrupt;



#endif /* __GT_UCORE_H__ */
