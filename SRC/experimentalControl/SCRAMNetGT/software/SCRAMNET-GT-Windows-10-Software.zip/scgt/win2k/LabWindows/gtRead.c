#include <cvirte.h>		
#include <userint.h>
#include "gtRead.h"
#include "scgtapi.h"

static int panelHandle;
static scgtHandle	gtHandle;

int main (int argc, char *argv[])
{
	uint32 		status;
	uint32     	unitNum;
    
	
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "gtRead.uir", PANEL)) < 0)
		return -1;
	
	unitNum = 0;
	status = scgtOpen(unitNum, &gtHandle);
	if(status != SCGT_SUCCESS)
	{
		DiscardPanel (panelHandle);
		return 0;
	}
	scgtMapMem(&gtHandle);
	
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK QuitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			scgtUnmapMem(&gtHandle);			
			scgtClose(&gtHandle);
			QuitUserInterface (0);
			break;
	}
	return 0;
}

int CVICALLBACK gtread_offset (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	uint32 value;
	uint32 offset;
	uint32 bytesToRead;
	uint32 bytesRead;
	uint32 flags;
	uint32 status;
	static char valueStr[80];
	
	
	switch (event)
	{
		case EVENT_COMMIT:
			break;
		case EVENT_VAL_CHANGED:
            GetCtrlVal (panelHandle, PANEL_MEM_OFFSET, &offset);
			if(offset & 0x3)
			{
				offset = (offset & ~0x3);
				SetCtrlVal(panelHandle,PANEL_MEM_OFFSET,offset);
			}
				
			bytesToRead = 4;
			bytesRead = 0;
			flags = SCGT_RW_PIO;
			status = scgtRead(&gtHandle,offset,&value,bytesToRead,flags,&bytesRead);
			if(status != 0)
				sprintf(valueStr,"Error status=0x%x",status);
			else
				sprintf(valueStr,"mem[0x%x]=0x%08x \n",offset,value);
			SetCtrlVal(panelHandle,PANEL_VALUE_READ,valueStr);
			break;
	}
	
	
	return 0;
}
