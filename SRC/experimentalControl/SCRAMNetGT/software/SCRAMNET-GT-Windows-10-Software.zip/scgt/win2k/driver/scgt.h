/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2002-2005 Curtiss-Wright Controls.                           */
/*               support@systran.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/*                                                                            */
/*    Module      : scgt.h                                                    */
/*    Description : supporting structures and defines for scgt.c              */
/*    Platform    : Win2K                                                     */
/*                                                                            */
/******************************************************************************/

/**
 * @file scgt.h
 * @brief supporting structures and defines for scgt.c
*/

#ifndef __SCGT_H__
#define __SCGT_H__

#include "systypes.h"
#include "gtcoreTypes.h"


#define FILE_REV_SCGT_H    "5"   /* 8/29/11 */

#define SCGT_DMA_FULL  0   /**< Valid Data in DMA buffer */
#define SCGT_DMA_EMPTY 1   /**< DMA buffer empty */

/** Data buffer to hold Data used in DMA trnasfers */
typedef struct _scgtDmaBuffer
{
   uint32 Status;              /**< status of DMA buffer full or empty */
   uint32 Cnt;                 /**< count number of times buffer used for Dma transfers */
   uint32 * pData;                   /**< alinged virtialPointer to allocated DMA dat buffer */
   PHYSICAL_ADDRESS physAddr;          /**< PkysicalAddress of aligned data Buffer */ 
}scgtDmaBuffer;


/** DMA tools for controle acces to DMA buffers */
typedef struct _scgtDMATools
{
    ksysSemS entrySem_1;
    ksysSemS entrySem_2;
    uint32 pending;    
} scgtDMATools;

/** Device structure */
typedef struct _scgtDevice
{
    SCGT_DEVICE_CORE

    void *cRegPtr;
    void *nmRegPtr;
    PHYSICAL_ADDRESS gtMemPhysAddr;
    
    scgtDMATools writeTools;
    scgtDMATools readTools;
        
    UNICODE_STRING unicodeSymLinkName;
    DEVICE_OBJECT  *lowerDeviceInStack;
    DEVICE_OBJECT  *physDeviceObject;
    DMA_ADAPTER    *dmaAdapter;         /**< same value as mapData */
    uint32 interruptLevel;
    uint32 interruptVector;
    KAFFINITY interruptAffinity;
    PKINTERRUPT interruptObject;

    ksysSemB threadSem;
    uint32 threadTimeToExit;
    
    KTIMER getIntrTimer;
    KDPC getIntrTimerDPC;

    ksysSemS getIntrSem;    
    volatile uint32 getIntrWaitCount;
    ksysSpinLock getIntrWaitCountSpinLock;  /**< protects wait count */
    ksysSpinLock getIntrTimerSpinLock;      /**< protects timer use count
                                               and timer started */
                                              
    //ksysSpinLock dpcSpinLock;      /* protects access DPC operations */

                                              
    volatile uint32 getIntrTmrUseCnt;      /**< # of threads using the timer */
    volatile uint8 getIntrTimerStarted;    /**< flag indicating if get einteerupt timer started */

    scgtDmaBuffer DmaRead[SCGT_DMA_NUM_BUFFERS];  /**< DMA read buffers */
    scgtDmaBuffer DmaWrite[SCGT_DMA_NUM_BUFFERS]; /**< DMA Write buffers */
    uint32 MaxDMABlockSize;                       /**< maximum size allowed to transfer in one DMA transfer */
    BOOLEAN Is64BitOS;                            /**< is 64-bit operationg system */
} scgtDevice;

#endif /* __SCGT_H__ */
