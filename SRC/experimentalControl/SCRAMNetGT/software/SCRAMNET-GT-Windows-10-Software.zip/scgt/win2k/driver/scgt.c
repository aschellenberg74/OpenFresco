/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2002-2005 Curtiss-Wright Controls.                           */
/*               support@systran.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/*                                                                            */
/*    Module      : scgt.c                                                    */
/*    Description : SCRAMNet GT driver entry points                           */
/*    Platform    : Win2k                                                     */
/*                                                                            */
/******************************************************************************/
/** @file scgt.c  
  * @brief SCRAMNet GT driver entry points*/

/************************************************************************/
/**************************  I N C L U D E S  ***************************/
/************************************************************************/
#include <wdm.h>
#include <stdio.h>
#include "scgt.h"

#include "gtcore.h"
#include "gtcoreIoctl.h"
#include "ksys.h"

#include "scgtdrv.h"

//#define NTSTRSAFE_LIB
#include <ntstrsafe.h>
#include "scgtDebug.h"

/************************************************************************/
/***************************  D E F I N E S  ****************************/
/************************************************************************/

#define SCGT_DRIVER_VERSION     "1.7w2k"
char *FILE_REV_SCGT_C = "9";   /* 06/06/17 */

#define SCGT_DEVICE_BASE_NAME   "\\Device\\scgt"
#define SCGT_SYMLINK_BASE_NAME   "\\??\\scgt"

//#define SCGT_TIMEOUT_TIME    200  /* 2 seconds */
#define SCGT_TIMEOUT_TIME    400  /* 4 seconds */


/* timer in 100ns per tick.. convert to 1/1000 second ticks */
#define SCGT_GET_INTR_TIMER_REL_TIME (-100 * 10000)
#define SCGT_GET_INTR_TIMER_MILLISEC 100

#ifndef KSYS_CACHE_LINE_SIZE
#define GTCORE_CACHE_LINE_SIZE  256
#else
#define GTCORE_CACHE_LINE_SIZE  KSYS_CACHE_LINE_SIZE    /* cache line size must be >= 16 */
#endif

/** Number of byte needed for one DMA chain list. 
    Number of chain entries per list * size of one entry */
#define GTCORE_CHAIN_BYTES   (SCGT_DMA_CHAIN_LEN * GTCORE_CE_SIZE)

/*
 * define SCGT_EXCH_MAP_PER_CHAIN in scgtdrv.h in order to have
 * gtcoreExchChain() allocate and map 1 chain per exchange.  If this is
 * not defined, there will be an allocation and map per exchange direction 
 * which is shared across chains.  1 allocation and map per direction can
 * be beneficial on some systems by limiting the number of maps required 
 * (some machines have a limited number of maps).  The memory must be 
 * physically contiguous for this to work.
 */
 
#ifndef SCGT_EXCH_CHAIN_MAP_PER_EXCH
#define SCGT_EXCH_CHAIN_ONE_MAP
#endif

#ifdef SCGT_EXCH_CHAIN_ONE_MAP
#define CHAIN_LIST_SIZE  GTCORE_CHAIN_BYTES * GTCORE_EXCH_CNT + GTCORE_CACHE_LINE_SIZE * 2
#else
#define CHAIN_LIST_SIZE  (GTCORE_CHAIN_BYTES + GTCORE_CACHE_LINE_SIZE * 2 ) * GTCORE_EXCH_CNT
#endif


/******************************************************************/
/********************* FUNCTION PROTOTYPES ************************/
/******************************************************************/

#if defined NEW_DDK
/** @cond DDK_PROTOTYPES */
IO_COMPLETION_ROUTINE scgtCompletion;
KSERVICE_ROUTINE scgtISR;
IO_COMPLETION_ROUTINE scgtDeferedIrpCompletion;
DRIVER_UNLOAD scgtExitDriver;
DRIVER_ADD_DEVICE scgtAddDevice;
__drv_dispatchType(IRP_MJ_DEVICE_CONTROL)
DRIVER_DISPATCH scgtIoctl;
__drv_dispatchType(IRP_MJ_CREATE)
DRIVER_DISPATCH scgtOpen;
__drv_dispatchType(IRP_MJ_CLOSE)
DRIVER_DISPATCH scgtClose;
__drv_dispatchType(IRP_MJ_PNP)
DRIVER_DISPATCH scgtIoctlPNP;
__drv_dispatchType(IRP_MJ_POWER)
DRIVER_DISPATCH scgtIoctlPOWER;
DRIVER_INITIALIZE DriverEntry;
IO_DPC_ROUTINE scgtDPC;

__drv_dispatchType(IRP_MJ_READ)
DRIVER_DISPATCH scgtDispatchRead;

__drv_dispatchType(IRP_MJ_WRITE)
DRIVER_DISPATCH scgtDispatchWrite;

__drv_dispatchType(IRP_MJ_CLEANUP)
DRIVER_DISPATCH scgtDispatchCleanup;
 __drv_dispatchType(IRP_MJ_FLUSH_BUFFERS)
DRIVER_DISPATCH scgtDispatchFlushBuffers;

KSTART_ROUTINE scgtInterruptThread;
KDEFERRED_ROUTINE scgtGetIntrTimerCallback;
/** @endcond */
#else

NTSTATUS scgtCompletion(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp, IN PVOID Context);
BOOLEAN scgtISR(IN PKINTERRUPT Interrupt, IN OUT PVOID Context);
NTSTATUS scgtDeferedIrpCompletion(IN PDEVICE_OBJECT pDO, IN PIRP Irp, IN PKEVENT Event);
VOID scgtExitDriver(IN PDRIVER_OBJECT driverObject);
NTSTATUS scgtAddDevice(IN PDRIVER_OBJECT dvrObj, IN PDEVICE_OBJECT physDevObj);
NTSTATUS scgtIoctl(IN PDEVICE_OBJECT deviceObject, IN PIRP irp);
NTSTATUS scgtOpen(IN PDEVICE_OBJECT deviceObject, IN PIRP irp);
NTSTATUS scgtClose(IN PDEVICE_OBJECT deviceObject, IN PIRP irp);
NTSTATUS scgtIoctlPNP(IN PDEVICE_OBJECT deviceObject, IN PIRP irp);
NTSTATUS DriverEntry(IN PDRIVER_OBJECT driverObject, IN PUNICODE_STRING registryPath);
void scgtDPC(IN PKDPC dpc, IN PDEVICE_OBJECT deviceObject, IN PIRP irp, IN PVOID context);
void scgtInterruptThread( PVOID StartContext);
void scgtGetIntrTimerCallback(IN PKDPC dpc, IN PVOID context, IN PVOID sysArg1, IN PVOID sysArg2);
NTSTATUS scgtDispatchRead( PDEVICE_OBJECT  DeviceObject, PIRP  Irp );
NTSTATUS scgtDispatchWrite( PDEVICE_OBJECT  DeviceObject, PIRP  Irp );
NTSTATUS scgtDispatchFlushBuffers(PDEVICE_OBJECT  DeviceObject, PIRP  Irp );

#endif

static void scgtInitDriverRev();
static void scgtBuildDevNameString(char *baseStr, uint32 unit, UNICODE_STRING *outStr);
static NTSTATUS scgtInitDMA(scgtDevice *dev);
static NTSTATUS scgtIoctl2(DEVICE_OBJECT *deviceObject, IRP *irp, IO_STACK_LOCATION *irpStackLoc);
static int scgtIoctlGetStats(scgtDevice *dev, scgtStats *stats);
static NTSTATUS scgtIoctlMapMem(scgtDevice *dev, scgtMemMapInfo *mapInfo);
static NTSTATUS scgtIoctlUnmapMem(scgtDevice *dev, scgtMemMapInfo *mapInfo);
static NTSTATUS scgtIoctlGetDeviceInfo(scgtDevice *dev, scgtDeviceInfo *devInfo);
NTSTATUS scgtIoctlPOWER(IN PDEVICE_OBJECT deviceObject, IN PIRP irp);
static NTSTATUS scgtStartDevice(PDEVICE_OBJECT deviceObject, PCM_FULL_RESOURCE_DESCRIPTOR fullResourceDescriptor);
static void scgtStopDevice(PDEVICE_OBJECT deviceObject);
void scgtRemoveDevice(PDEVICE_OBJECT deviceObject);
static ULONG scgtBusNum(IN PDEVICE_OBJECT physDevObj);
static ULONG scgtSlotNum(IN PDEVICE_OBJECT pDO);
static void scgtCopyToUser(void *userPtrDest, void *src, uint32 numBytes);
static void scgtCopyFromUser(void *dst, void *userPtrSrc, uint32 numBytes);

static void scgtInitGetIntrTimer(scgtDevice *dev);
static void scgtDestroyGetIntrTimer(scgtDevice *dev);
static void scgtGetIntrTimerStart(scgtDevice *dev);

static int scgtGiveIntrSem(scgtDevice *dev);
static int scgtGiveIntrSemDPC(scgtDevice *dev);

static int scgtIoctlGetIntr(scgtDevice *dev, scgtGetIntrBuf *gibuf);

static int scgtInitDMATools(scgtDevice *dev);
static void scgtDestroyDMATools(scgtDevice *dev);

static uint32 scgtIoctlXfer(scgtDevice *dev,
                            PIRP irp,
                            scgtXfer *xfer,
                            scgtInterrupt *intr,
                            uint8 direction);

static uint32 scgtXferChunk(scgtDevice *dev,
                            PIRP irp,
                            uint32 gtMemoryOffset, 
                            uint8  *pBuf, 
                            uint32 chunkSize,
                            uint8 lastTransfer,
                            uint32 flags,
                            scgtInterrupt *intr,
                            uint8  direction,
                            scgtDMATools *tools,
                            uint32 *bytesTransferred,
                            ksysSemS **semToGive);

static int scgtBuildChainList(scgtDevice *dev, PMDL mdl, gtcoreExch *exch, 
                              uint32 direction, uint32 chainLenBytes);

NTSTATUS scgtStartThread(scgtDevice *dev);
void scgtStopThread(scgtDevice *dev);

extern void * gtcoreAlignAddr(void *ptr, uint32 alignSize);

/************************************************************************/
/***************************  G L O B A L S  ****************************/
/************************************************************************/

uint32 numDevices = 0;        /** Number of GT Cards found*/
int getIntrTimerExit = 0;     /** Get interrupt timer exit */

char driverRevStr[128];       /** driver revsion string */

extern char *FILE_REV_SCGT_C, *FILE_REV_GTCORE_C, *FILE_REV_GTCOREXFER_C,
            *FILE_REV_KSYS_C;


/** GUID (generated with guidgen) **/
/* {EFEFE9A1-A66A-11d7-A8F4-005004166373} */

static const GUID scgtGUID =
{ 0xefefe9a1, 0xa66a, 0x11d7, { 0xa8, 0xf4, 0x0, 0x50, 0x4, 0x16, 0x63, 0x73 } };

/************************************************************************/
/******************************** CODE **********************************/
/************************************************************************/

char * scgtErrorCodeToString( uint32 error)
{
	static char str[20];
	switch(error)
	{
	   case SCGT_SUCCESS:
	   	   RtlStringCbPrintfA (str,20, "SCGT_SUCCESS");
		   break;
	   case SCGT_SYSTEM_ERROR:
		   RtlStringCbPrintfA (str,20, "SCGT_SYSTEM_ERROR");
		   break;
	   case SCGT_BAD_PARAMETER:
		   RtlStringCbPrintfA (str,20, "SCGT_BAD_PARAMETER");
		   break;
	   case SCGT_DRIVER_ERROR:
		   RtlStringCbPrintfA (str,20, "SCGT_DRIVER_ERROR");
		   break;
	   case SCGT_TIMEOUT:
		   RtlStringCbPrintfA (str,20, "SCGT_TIMEOUT");
		   break;
	   case SCGT_CALL_UNSUPPORTED:
		   RtlStringCbPrintfA (str,20, "SCGT_CALL_UNSUPPORTED");
		   break;
	   case SCGT_INSUFFICIENT_RESOURCES:
		   RtlStringCbPrintfA (str,20, "SCGT_INSUFFICIENT_RESOURCES");
		   break;
	   case SCGT_LINK_ERROR:
		   RtlStringCbPrintfA (str,20, "SCGT_LINK_ERROR");
		   break;
	   case SCGT_MISSED_INTERRUPTS:
		   RtlStringCbPrintfA (str,20, "SCGT_MISSED_INTERRUPTS");
		   break;
	   case SCGT_DRIVER_MISSED_INTERRUPTS:
		   RtlStringCbPrintfA (str,20, "SCGT_DRIVER_MISSED_INTERRUPTS");
		   break;
	   case SCGT_DMA_UNSUPPORTED:
		   RtlStringCbPrintfA (str,20, "SCGT_DMA_UNSUPPORTED");
		   break;
	   case SCGT_HARDWARE_ERROR:
		   RtlStringCbPrintfA (str,20, "SCGT_HARDWARE_ERROR");
		   break;
	   default:
	  	  RtlStringCbPrintfA (str,20,"Unkown 0x%x\n",error);
		  break;
   }
   return str;
}
 
/**************************************************************************//**
 * @fn  NTSTATUS DriverEntry(IN PDRIVER_OBJECT driverObject,
 *                           IN PUNICODE_STRING registryPath)
 *
 * @brief Main driver entry point
 *
 * @param  driverObject   The driver object. 
 * @param  registryPath   Full pathname of the registry file. 
 *
 * @return STATUS_SUCCESS
 *****************************************************************************/
NTSTATUS DriverEntry(IN PDRIVER_OBJECT driverObject, IN PUNICODE_STRING registryPath)
{
    NTSTATUS ret = STATUS_SUCCESS;
	ScgtDrvDebugLevel =  SCGT_DBG_ERROR | SCGT_DBG_WARNING |  SCGT_DBG_VERSION | SCGT_DBG_IS64 ;

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: DriverEntry() - {\n"));

    UNREFERENCED_PARAMETER(registryPath);

    /* Setup driver entry points */
    driverObject->DriverUnload                         = scgtExitDriver;
    driverObject->DriverExtension->AddDevice           = scgtAddDevice;
    driverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = scgtIoctl;
    driverObject->MajorFunction[IRP_MJ_CREATE]         = scgtOpen;
    driverObject->MajorFunction[IRP_MJ_CLOSE]          = scgtClose;
    driverObject->MajorFunction[IRP_MJ_PNP]            = scgtIoctlPNP;
    driverObject->MajorFunction[IRP_MJ_POWER]          = scgtIoctlPOWER;

    driverObject->MajorFunction[IRP_MJ_READ]           = scgtDispatchRead;
    driverObject->MajorFunction[IRP_MJ_WRITE]          = scgtDispatchWrite;
    driverObject->MajorFunction[IRP_MJ_FLUSH_BUFFERS]  = scgtDispatchFlushBuffers;
	

    scgtInitDriverRev();
    ScgtDbgPrint(SCGT_DBG_VERSION, ("SCGT driver version %s. Compiled %s\n",driverRevStr,__DATE__));

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: DriverEntry() - }\n"));

    return ret;
}

NTSTATUS scgtDispatchRead( PDEVICE_OBJECT  DeviceObject, PIRP  Irp )
{
    UNREFERENCED_PARAMETER(DeviceObject);

    //required but not used
   ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDispatchRead() - {\n"));
   IoCompleteRequest(Irp, IO_NO_INCREMENT);
   ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDispatchRead() - }\n"));
   return STATUS_SUCCESS;
}

NTSTATUS scgtDispatchWrite( PDEVICE_OBJECT  DeviceObject, PIRP  Irp )
{
    UNREFERENCED_PARAMETER(DeviceObject);

    //required but not used
   ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDispatchWrite() - {\n"));
   IoCompleteRequest(Irp, IO_NO_INCREMENT);
   ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDispatchWrite() - }\n"));
   return STATUS_SUCCESS;
}

 NTSTATUS scgtDispatchCleanup(PDEVICE_OBJECT  DeviceObject, PIRP  Irp )
{
    KIRQL kIrql;

    UNREFERENCED_PARAMETER(DeviceObject);

	ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDispatchCleanup() - {\n"));
	IoAcquireCancelSpinLock(&kIrql);
    IoSetCancelRoutine(Irp,NULL);
	IoReleaseCancelSpinLock(kIrql);
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
	ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDispatchCleanup() - }\n"));
    return STATUS_SUCCESS;
}

 NTSTATUS scgtDispatchFlushBuffers(PDEVICE_OBJECT  DeviceObject, PIRP  Irp )
 {
    UNREFERENCED_PARAMETER(DeviceObject);

    //required but not used
    ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDispatchFlushBuffers() - {\n"));
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDispatchFlushBuffers() - }\n"));
    return STATUS_SUCCESS;
 }


/***************************************************************************//**
 * @fn  VOID scgtExitDriver(IN PDRIVER_OBJECT driverObject)
 *
 * @brief  Scgt driver exit function. 
 *
 * @param  driverObject   The driver object. 
 *****************************************************************************/
 VOID scgtExitDriver(IN PDRIVER_OBJECT driverObject)
{
    UNREFERENCED_PARAMETER(driverObject);

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtExitDriver() - {\n"));
    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtExitDriver() - }\n"));
}

/**************************************************************************//**
 * @fn  static void scgtInitDriverRev()
 *
 * @brief   Initialize driver revision string.  This is returned to user via
 *     GetDeviceInfo ioctl.
 *****************************************************************************/
static void scgtInitDriverRev()
{
    char coreFiles[60];
    char driverFiles[20];
    char sysFiles[20];

    RtlStringCbPrintfA (driverFiles,20, "%s%s%s",
            FILE_REV_SCGT_C, FILE_REV_SCGT_H, FILE_REV_SCGTDRV_H);
            
    RtlStringCbPrintfA (sysFiles,20, "%s%s%s",
            FILE_REV_KSYS_C, FILE_REV_KSYS_H, FILE_REV_SYSTYPES_H);

    RtlStringCbPrintfA (coreFiles,60, "%s%s%s%s%s%s",
            FILE_REV_GTCORE_C, FILE_REV_GTCOREXFER_C,  FILE_REV_GTCORE_H,
            FILE_REV_GTCOREIOCTL_H, FILE_REV_GTCORETYPES_H, FILE_REV_GTUCORE_H);

    RtlStringCbPrintfA (driverRevStr,128, "%s-%s:%s:%s", SCGT_DRIVER_VERSION, driverFiles, 
            sysFiles, coreFiles);
}

#if 0

/**************************************************************************//**
 * @fn  char *gtcoreStrCpy(char *dest, const char *src, int n)
 *
 * @brief  Gtcore string copy. 
 *
 *
 * @param [in,out]  dest  If non-null, destination for the. 
 * @param  src            Source for the. 
 * @param  n              The. 
 *
 * @return null if it fails, else. 
 *****************************************************************************/
char *gtcoreStrCpy(char *dest, const char *src, int n)
{
    for( ; (n > 0) && ((*dest = *src)); dest++, src++, n--);
    return dest; /* return position from which a strcat would start */
}

/**************************************************************************//**
 * @fn  static void scgtInitDriverRev()
 *
 * @brief  Scgt initialise driver revison sting data. 
 *
 *****************************************************************************/
static void scgtInitDriverRev()
{
    uint32 i = 0;
    char *dest = driverRevStr;
    dest = gtcoreStrCpy(dest, SCGT_DRIVER_VERSION "-", 10);
    /* copy driver file revisions */
    dest = gtcoreStrCpy(dest, FILE_REV_SCGT_C, 5);
    dest = gtcoreStrCpy(dest, FILE_REV_SCGT_H FILE_REV_SCGTDRV_H ":", 10);
    /* copy system portability file revisions */
    dest = gtcoreStrCpy(dest, FILE_REV_KSYS_C, 5);
    dest = gtcoreStrCpy(dest, FILE_REV_KSYS_H FILE_REV_SYSTYPES_H ":", 10);
    /* copy core file revisions */
    dest = gtcoreStrCpy(dest, FILE_REV_GTCORE_C, 5);
    dest = gtcoreStrCpy(dest, FILE_REV_GTCOREXFER_C, 5);
    dest = gtcoreStrCpy(dest, FILE_REV_GTCORE_H FILE_REV_GTCOREIOCTL_H
                              FILE_REV_GTCORETYPES_H FILE_REV_GTUCORE_H, 20);
}

#endif

/**************************************************************************//**
 * @fn  NTSTATUS scgtAddDevice(IN PDRIVER_OBJECT dvrObj, 
 *                             IN PDEVICE_OBJECT physDevObj)
 *
 * @brief  add device entry point.  Called for every GT card found. 
 *
 * @param  dvrObj      The dvr object. 
 * @param  physDevObj  The phys dev object. 
 *
 * @return NTSTATUS
 *****************************************************************************/
NTSTATUS scgtAddDevice(IN PDRIVER_OBJECT dvrObj, IN PDEVICE_OBJECT physDevObj)
{
    NTSTATUS ret;
    PDEVICE_OBJECT devObj;
    scgtDevice *dev;
    UNICODE_STRING devName;
    UNICODE_STRING usableSymLinkName;
    
    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtAddDevice() - {\n"));

    scgtBuildDevNameString(SCGT_DEVICE_BASE_NAME, numDevices, &devName);

    /* create device object */
    ret = IoCreateDevice(dvrObj, 
                         sizeof(scgtDevice), 
                         &devName, 
                         FILE_DEVICE_UNKNOWN,
                         0, 
                         FALSE, 
                         &devObj);

    if (!NT_SUCCESS(ret))
        return ret;
        
    dev = (scgtDevice *) devObj->DeviceExtension;
    
    /* initialize scgtDevice structure */
    RtlZeroMemory(dev, sizeof(scgtDevice));
    dev->unitNum = (uint8) numDevices;

    /* push onto device stack */
    dev->lowerDeviceInStack = IoAttachDeviceToDeviceStack(devObj, physDevObj);
    if(dev->lowerDeviceInStack == NULL)
    {
       ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: IoAttachDeviceStack returned NULL\n") );
       ret = STATUS_UNSUCCESSFUL;
       IoDeleteDevice(devObj);
       return ret;
    }
    dev->physDeviceObject = physDevObj;
   
    /* register our new device */
    ret = IoRegisterDeviceInterface(physDevObj, &scgtGUID,
                                    NULL, &dev->unicodeSymLinkName);

    if (!NT_SUCCESS(ret))
    {
        IoDeleteDevice(devObj);
        return ret;
    }    

    /* create a usable symlink for our device */
    scgtBuildDevNameString(SCGT_SYMLINK_BASE_NAME, numDevices++, &usableSymLinkName);
    ret = IoCreateSymbolicLink(&usableSymLinkName, &devName);
    
    if (!NT_SUCCESS(ret))
    {
        IoDeleteDevice(devObj);
        return ret;
    }
               
    /* initialize DPC */
    IoInitializeDpcRequest(devObj, scgtDPC);
    
    /* initialize board location string */
    RtlStringCbPrintfA(dev->boardLocationStr,128, "bus %i slot %i", 
            scgtBusNum(physDevObj), scgtSlotNum(devObj));

    devObj->Flags |= DO_DIRECT_IO;
    devObj->Flags &= ~DO_DEVICE_INITIALIZING;

    ScgtDbgPrint(SCGT_DBG_INFO, ("SCGT: scgtAddDevice() - returning %i }\n", ret));
    
    return ret;
}

/**************************************************************************//**
 * @fn  static void scgtBuildDevNameString(char *baseStr, uint32 unit, 
 *                                         UNICODE_STRING *outStr)
 *
 * @brief  build SCGT device name string. 
 *
 * @param [in,out]  baseStr  If non-null, the base string. 
 * @param  unit              The unit number. 
 * @param [in,out]  outStr   If non-null, the out string. 
 *****************************************************************************/
static void scgtBuildDevNameString(char *baseStr, uint32 unit, UNICODE_STRING *outStr)
{
    char buff[30];
    ANSI_STRING ansiString;
    
    RtlStringCbPrintfA (buff,30, "%s%u", baseStr, unit);
    
    ansiString.Buffer = buff;
    ansiString.Length = (unsigned short) strlen(buff);
    ansiString.MaximumLength = 29;
    if( RtlAnsiStringToUnicodeString(outStr, &ansiString, 1) != STATUS_SUCCESS)
    {
       ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: RtlAnsiStringToUnicodeString call failed\n"));
    }
}

/**************************************************************************//**
 * @fn  static NTSTATUS scgtInitDMA(scgtDevice *dev)
 *
 * @brief  Scgt initialise dma. 
 *
 * 
 * @param [in,out]  dev   If non-null, the dev. 
******************************************************************************/
static NTSTATUS scgtInitDMA(scgtDevice *dev)
{
//   NTSTATUS ret;
   INTERFACE_TYPE busType;
//   uint32 tempVal;
   ULONG tempVal;
   DEVICE_DESCRIPTION desc;
   uint32 i;
//   PHYSICAL_ADDRESS logicalAddress;

   uint32 dmaBufferSpace;
   uint32 TransactionQueueSize;
   uint32 numBlocks;

   IoGetDeviceProperty(dev->physDeviceObject, DevicePropertyLegacyBusType,
                       sizeof(busType), &busType, &tempVal);

   /** Max number of bytes in one DMA transfer*/
   dev->MaxDMABlockSize  =  SCGT_MAX_CHUNK_SIZE;

   /** number of bytes need to map all DMA data blocks for both directions */
   if( dev->Is64BitOS)
   {
      numBlocks = SCGT_DMA_NUM_BUFFERS * 2;
   }
   else
   {
      numBlocks = 1;
   }
   dmaBufferSpace = dev->MaxDMABlockSize * numBlocks;

   /** number of bytes needed by the Transaction Queue */
   TransactionQueueSize = (GTCORE_EXCH_CNT * GTCORE_TQE_SIZE) + (GTCORE_CACHE_LINE_SIZE * 2);

   /* Set up our device descriptor */
   RtlZeroMemory(&desc, sizeof(desc));
   desc.Version = DEVICE_DESCRIPTION_VERSION;
   desc.Master = TRUE;
   desc.ScatterGather = TRUE; 
   desc.DemandMode = FALSE; 
   desc.AutoInitialize = FALSE; 
   desc.InterfaceType = busType;
   //desc.MaximumLength = 0x10000;
   desc.MaximumLength = dmaBufferSpace + TransactionQueueSize + CHAIN_LIST_SIZE;
   desc.Dma32BitAddresses = TRUE;
   tempVal = ( desc.MaximumLength /PAGE_SIZE) + 1;  /** number of mapping registers we are looking for */

   do
   {
      /* Get Io DMA adapter */
      dev->dmaAdapter = IoGetDmaAdapter(dev->physDeviceObject,&desc, &tempVal);
      if(dev->dmaAdapter != NULL)
      {
         if ( tempVal >= desc.MaximumLength/PAGE_SIZE )
            break;
      }
      /* try smaller chunk size*/
      dev->MaxDMABlockSize  = dev->MaxDMABlockSize - 64;
      dmaBufferSpace = dev->MaxDMABlockSize * numBlocks;
      desc.MaximumLength = dmaBufferSpace + TransactionQueueSize + CHAIN_LIST_SIZE; 
      tempVal = ( desc.MaximumLength /PAGE_SIZE) + 1;  /** number of mapping registers we are looking for */
      ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: IoGetDmaAdapter failed. desc.MaximumLenght = %d \n",desc.MaximumLength) );
   } while ( (dev->MaxDMABlockSize >= PAGE_SIZE * numBlocks ) );

   if(dev->dmaAdapter == NULL)
   {
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtInitDMA(): FAILED!!!\n" ));
        return STATUS_INSUFFICIENT_RESOURCES;   
   }
   if( tempVal < desc.MaximumLength / PAGE_SIZE)
   {
      ScgtDbgPrint(SCGT_DBG_WARNING,("SCGT: Unable to allocate %d map registers. Got %d map registes\n",desc.MaximumLength/PAGE_SIZE,tempVal));
      return STATUS_INSUFFICIENT_RESOURCES;
   }
   else
   {
      ScgtDbgPrint(SCGT_DBG_DMA,("SCGT: Got DMA Adapter Num Map Registers = %d \n", tempVal) );
      ScgtDbgPrint(SCGT_DBG_DMA,("SCGT: dev->MaxDMABlockSize=0x%x bytes \n", dev->MaxDMABlockSize ) );
   }

   if(dev->Is64BitOS)
   {
      for(i=0;i<SCGT_DMA_NUM_BUFFERS;i++)
      {
         dev->DmaRead[i].pData = (uint32*) dev->dmaAdapter->DmaOperations->AllocateCommonBuffer( 
                                                dev->dmaAdapter,dev->MaxDMABlockSize, &dev->DmaRead[i].physAddr, FALSE );
         if(dev->DmaRead[i].pData == NULL)
         {
               ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtInitDMA() allocated DMA buffer %d FAILED!!!\n",i) );
               return STATUS_INSUFFICIENT_RESOURCES;
         }
         dev->DmaRead[i].Status = SCGT_DMA_EMPTY;
         dev->DmaRead[i].Cnt=0;
         ScgtDbgPrint(SCGT_DBG_DMA,("SCGT:  dev->DmaRead[%d].physAddr = 0x%08x%08x\n", i,
                      dev->DmaRead[i].physAddr.HighPart,dev->DmaRead[i].physAddr.LowPart));
         dev->DmaWrite[i].pData = (uint32*) dev->dmaAdapter->DmaOperations->AllocateCommonBuffer( 
                                            dev->dmaAdapter,dev->MaxDMABlockSize, &dev->DmaWrite[i].physAddr, FALSE );
         if(dev->DmaWrite[i].pData == NULL)
         {
            ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtInitDMA() allocated DMA buffer %d FAILED!!!\n",i) );
            return STATUS_INSUFFICIENT_RESOURCES;
         }
         dev->DmaWrite[i].Status = SCGT_DMA_EMPTY;
         dev->DmaWrite[i].Cnt=0;
         ScgtDbgPrint(SCGT_DBG_DMA,("SCGT: dev->DmaWrite[%d].physAddr = 0x%08x%08x\n", i,
                   dev->DmaWrite[i].physAddr.HighPart,dev->DmaWrite[i].physAddr.LowPart));
      }
   }

   return STATUS_SUCCESS;
}

/**************************************************************************//**
 * @fn  void scgtRemoveDevice(PDEVICE_OBJECT deviceObject)
 *
 * @brief  Scgt remove device. 
 *
 * @param  deviceObject   The device object. 
******************************************************************************/
void scgtRemoveDevice(PDEVICE_OBJECT deviceObject)
{
    scgtDevice *dev;
//    UNICODE_STRING devName;
    UNICODE_STRING usableSymLinkName;

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtRemoveDevice() -  {\n"));
    
    scgtStopDevice(deviceObject);

    dev = (scgtDevice *) deviceObject->DeviceExtension;
     
    /* delete symlink for our device */
    scgtBuildDevNameString(SCGT_SYMLINK_BASE_NAME, dev->unitNum, &usableSymLinkName);
    IoDeleteSymbolicLink(&usableSymLinkName);

    IoDetachDevice(dev->lowerDeviceInStack);
    IoDeleteDevice(deviceObject);

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtRemoveDevice() -  }\n"));   
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtOpen(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
 *
 * @brief  Scgt open. 
 *
 * @param  deviceObject   The device object. 
 * @param  irp            The irp. 
 *
 * @return . 
*******************************************************************************/
NTSTATUS scgtOpen(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
{
//    NTSTATUS ret = STATUS_SUCCESS;
    PIO_STACK_LOCATION irpStackLoc;

    UNREFERENCED_PARAMETER(deviceObject);

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtOpen() - {\n"));

    irp->IoStatus.Status = STATUS_SUCCESS;
    irp->IoStatus.Information = 0;
    
    irpStackLoc = IoGetCurrentIrpStackLocation(irp);
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    
    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtOpen() - }\n"));
    
    return STATUS_SUCCESS;
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtClose(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
 *
 * @brief  Scgt close. 
 *
 * @param  deviceObject   The device object. 
 * @param  irp            The irp. 
 *
 * @return STATUS_SUCCESS
 *****************************************************************************/
NTSTATUS scgtClose(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
{
    UNREFERENCED_PARAMETER(deviceObject);
    UNREFERENCED_PARAMETER(irp);

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtClose() - {\n"));
    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtClose() - }\n"));
    
    return STATUS_SUCCESS;
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtIoctl(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
 *
 * @brief  handle write, read, and getIntr requests.. pass others
 *     to scgtIoctl2().
 *
 * @param  deviceObject   The device object. 
 * @param  irp            The irp. 
 *
 * @return NTSTATUS
 *****************************************************************************/
NTSTATUS scgtIoctl(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
{
    NTSTATUS ret = STATUS_SUCCESS;
    PIO_STACK_LOCATION irpStackLoc;
    scgtDevice *dev;
    scgtXfer *xfer; 
    scgtInterrupt intr;
    scgtGetIntrBuf *getIntrBuf;
        
    ScgtDbgPrint(SCGT_DBG_IOCTL,("SCGT: scgtIoctl() - {\n"));
    
    dev = deviceObject->DeviceExtension;
    irp->IoStatus.Information = 0;
    irpStackLoc = IoGetCurrentIrpStackLocation(irp);
    
    switch (irpStackLoc->MajorFunction)
    {    
        case IRP_MJ_DEVICE_CONTROL:
            switch (irpStackLoc->Parameters.DeviceIoControl.IoControlCode)
            {
                case SCGT_IOCTL_WRITE:
                    ScgtDbgPrint( SCGT_DBG_WRITE,("SCGT: SCGT_IOCTL_WRITE\n") );
                    xfer = irp->AssociatedIrp.SystemBuffer; 

                    if (xfer->pInterrupt)
                    {
                        scgtCopyFromUser(&intr, (void *) xfer->pInterrupt, sizeof(scgtInterrupt));
                        xfer->reserved = scgtIoctlXfer(dev, irp, xfer, &intr, GTCORE_WRITE);
                    }
                    else
                    {
                        xfer->reserved = scgtIoctlXfer(dev, irp, xfer, NULL, GTCORE_WRITE);
                    }
                    irp->IoStatus.Information = sizeof(scgtXfer);
                    break;
                
                case SCGT_IOCTL_READ:
                    ScgtDbgPrint(SCGT_DBG_READ,("SCGT: SCGT_IOCTL_READ\n"));
                    xfer = irp->AssociatedIrp.SystemBuffer; 
                    xfer->reserved = scgtIoctlXfer(dev, irp, xfer, NULL, GTCORE_READ);
                    irp->IoStatus.Information = sizeof(scgtXfer);
                    break;
                
                case SCGT_IOCTL_GET_INTR:
                    ScgtDbgPrint(SCGT_DBG_INTR,("SCGT: SCGT_IOCTL_GET_INTR\n"));
                    getIntrBuf = irp->AssociatedIrp.SystemBuffer;
                    getIntrBuf->reserved = scgtIoctlGetIntr(dev, getIntrBuf);
                    irp->IoStatus.Information = sizeof(scgtGetIntrBuf);
                    break;
                                
                default:
                    ret = scgtIoctl2(deviceObject, irp, irpStackLoc);
                    break;
            }
            break;
        
        case IRP_MJ_CREATE:
        case IRP_MJ_CLOSE:
            ScgtDbgPrint(SCGT_DBG_IOCTL,("SCGT: scgtIoctl(): IRP_MJ_CREATE or IRP_MJ_CLOSE\n"));
            irp->IoStatus.Information = 0;
            ret = STATUS_SUCCESS;
            break;
        default:
            irp->IoStatus.Information = 0;
            ret = STATUS_NOT_IMPLEMENTED;                            
    }
    
    irp->IoStatus.Status = ret;
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    
    //ScgtDbgPrint(SCGT_DBG_IOCTL,("SCGT: irp: status 0x%x information 0x%I64x\n", 
//                              irp->IoStatus.Status, (long long) irp->IoStatus.Information) );
    
    ScgtDbgPrint(SCGT_DBG_IOCTL,("SCGT: scgtIoctl() - }\n"));
    
    return STATUS_SUCCESS;
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtIoctl2(DEVICE_OBJECT *deviceObject, IRP *irp, 
 * IO_STACK_LOCATION *irpStackLoc)
 *
 * @brief  Scgt ioctl 2. 
 *
 * @param [in,out]  deviceObject   If non-null, the device object. 
 * @param [in,out]  irp            If non-null, the irp. 
 * @param [in,out]  irpStackLoc    If non-null, the irp stack location. 
 *
 * @return . 
 *****************************************************************************/

NTSTATUS scgtIoctl2(DEVICE_OBJECT *deviceObject, IRP *irp, IO_STACK_LOCATION *irpStackLoc)
{
    NTSTATUS ret = STATUS_SUCCESS;
    scgtDevice *dev;
        
    union
    {
        scgtRegister *reg;
        scgtDeviceInfo *deviceInfo;
        scgtState *state;
        scgtStats *stats;
        scgtMemMapInfo *memMapInfo;
        scgtInterrupt *intr;
    } u;
    
    
    ScgtDbgPrint(SCGT_DBG_IOCTL2,("SCGT: scgtIoctl2() - {\n"));
    
    dev = deviceObject->DeviceExtension;
    
    u.reg = irp->AssociatedIrp.SystemBuffer;  /* this sets all of them up */
    
    switch (irpStackLoc->Parameters.DeviceIoControl.IoControlCode)
    {

        case SCGT_IOCTL_GET_STATE:
            ScgtDbgPrint(SCGT_DBG_STATE,("SCGT: SCGT_IOCTL_GET_STATE\n"));
            u.state->reserved = gtcoreGetState(dev, u.state->stateID, &u.state->val);
            irp->IoStatus.Information = sizeof(scgtState);
            break;
            
        case SCGT_IOCTL_SET_STATE:
            ScgtDbgPrint(SCGT_DBG_STATE,("SCGT: SCGT_IOCTL_SET_STATE\n"));
            u.state->reserved = gtcoreSetState(dev, u.state->stateID, u.state->val);
            irp->IoStatus.Information = sizeof(scgtState);
            break;
        
        case SCGT_IOCTL_READ_CR:
            ScgtDbgPrint(SCGT_DBG_REG,("SCGT: SCGT_IOCTL_READ_CR\n"));
            irp->IoStatus.Information = sizeof(scgtRegister);
            if (u.reg->offset < GTCORE_REGISTER_SIZE)
            {
                u.reg->val = scgtReadCReg(dev, u.reg->offset);
                u.reg->reserved = SCGT_SUCCESS;
            }
            else
            {
                u.reg->reserved = SCGT_BAD_PARAMETER;
            }
            break;
            
        case SCGT_IOCTL_WRITE_CR:
            ScgtDbgPrint(SCGT_DBG_REG,("SCGT: SCGT_IOCTL_WRITE_CR\n"));
            irp->IoStatus.Information = sizeof(scgtRegister);
            if (u.reg->offset < GTCORE_REGISTER_SIZE)
            {
                scgtWriteCReg(dev, u.reg->offset, u.reg->val);
                u.reg->reserved = SCGT_SUCCESS;
            }
            else
            {
                u.reg->reserved = SCGT_BAD_PARAMETER;
            }
            break;

        case SCGT_IOCTL_READ_NMR:
            ScgtDbgPrint(SCGT_DBG_REG,("SCGT: SCGT_IOCTL_READ_NMR\n"));
            irp->IoStatus.Information = sizeof(scgtRegister);
            if (u.reg->offset < GTCORE_NM_REGISTER_SIZE)
            {
                u.reg->val = scgtReadNMReg(dev, u.reg->offset);
                u.reg->reserved = SCGT_SUCCESS;
            }
            else
            {
                u.reg->reserved = SCGT_BAD_PARAMETER;
            }
            break;
            
        case SCGT_IOCTL_WRITE_NMR:
            ScgtDbgPrint(SCGT_DBG_REG,("SCGT: SCGT_IOCTL_WRITE_NMR\n"));
            irp->IoStatus.Information = sizeof(scgtRegister);
            if (u.reg->offset < GTCORE_NM_REGISTER_SIZE)
            {
                scgtWriteNMReg(dev, u.reg->offset, u.reg->val);
                u.reg->reserved = SCGT_SUCCESS;
            }
            else
            {
                u.reg->reserved = SCGT_BAD_PARAMETER;
            }
            break;
        
        case SCGT_IOCTL_GET_DEVICE_INFO:
            ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: SCGT_IOCTL_GET_DEVICE_INFO\n"));
            ret = scgtIoctlGetDeviceInfo(dev, u.deviceInfo);
            irp->IoStatus.Information = sizeof(scgtDeviceInfo);
            break;
            
        case SCGT_IOCTL_GET_STATS:
            ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: SCGT_IOCTL_GET_STATS\n"));            
            ret = scgtIoctlGetStats(dev, u.stats);
            irp->IoStatus.Information = sizeof(scgtStats);
            break;
            
        case SCGT_IOCTL_MAP_MEM:
            ScgtDbgPrint(SCGT_DBG_MAP,("SCGT: SCGT_IOCTL_MAP_MEM\n"));
            ret = scgtIoctlMapMem(dev, u.memMapInfo);
            irp->IoStatus.Information = sizeof(scgtMemMapInfo);
            break;
            
        case SCGT_IOCTL_UNMAP_MEM:
            ScgtDbgPrint(SCGT_DBG_MAP,("SCGT: SCGT_IOCTL_MAP_MEM\n"));
            ret = scgtIoctlUnmapMem(dev, u.memMapInfo);
            irp->IoStatus.Information = sizeof(scgtMemMapInfo);
            break;

        case SCGT_IOCTL_PUT_INTR:       /* used for debugging interrupt queue */
            ScgtDbgPrint(SCGT_DBG_INTR,("SCGT: SCGT_IOCTL_GET_INTR\n"));
            gtcorePutIntr(dev, u.intr);
            irp->IoStatus.Information = 0;
            ret = SCGT_SUCCESS;
            break;

        case SCGT_IOCTL_DBG_FLAG:       /* used for controling which debug message are shown */
            ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: SCGT_IOCTL_DBG_FLAG\n"));
            ScgtDrvDebugLevel = u.state->val;
            u.state->reserved = ScgtDrvDebugLevel;
            ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: ScgtDrvDebugLevel=0x%x \n",ScgtDrvDebugLevel));
            irp->IoStatus.Information = sizeof(scgtState);
            ret = SCGT_SUCCESS;
            break;
            
        default:
            ScgtDbgPrint(SCGT_DBG_WARNING,("SCGT: Ioctl2() default\n"));
            irp->IoStatus.Information = 0;
            ret = STATUS_NOT_IMPLEMENTED;
    }
    
    ScgtDbgPrint(SCGT_DBG_IOCTL2,("SCGT: scgtIoctl2() - }\n"));
    
    return ret;
}

/**************************************************************************//**
 * @fn  static int scgtIoctlGetStats(scgtDevice *dev, scgtStats *stats)
 *
 * @brief driver statistics.
 *
 * @param [in,out]  dev   If non-null, the dev. 
 * @param [in,out]  stats If non-null, the stats. 
 *
 * @return SCGT_SUCCESS
 *****************************************************************************/
static int scgtIoctlGetStats(scgtDevice *dev, scgtStats *stats)
{
    /* update any stats that need to be updated */
    dev->stats[SCGT_STATS_GET_INTR_WAIT_CNT] = dev->getIntrWaitCount;

    dev->stats[SCGT_STATS_W_ENTRY_SEM_1] = KeReadStateSemaphore(&dev->writeTools.entrySem_1);
    dev->stats[SCGT_STATS_W_ENTRY_SEM_2] = KeReadStateSemaphore(&dev->writeTools.entrySem_2);
    dev->stats[SCGT_STATS_R_ENTRY_SEM_1] = KeReadStateSemaphore(&dev->readTools.entrySem_1);
    dev->stats[SCGT_STATS_R_ENTRY_SEM_2] = KeReadStateSemaphore(&dev->readTools.entrySem_2);
    
    dev->stats[SCGT_STATS_W_EXCH_SEM_0] = dev->wexch.exchQ[0].compSem.waiting;
    dev->stats[SCGT_STATS_W_EXCH_SEM_1] = dev->wexch.exchQ[1].compSem.waiting;
    dev->stats[SCGT_STATS_W_EXCH_SEM_2] = dev->wexch.exchQ[2].compSem.waiting;
    dev->stats[SCGT_STATS_W_EXCH_SEM_3] = dev->wexch.exchQ[3].compSem.waiting;
    
    dev->stats[SCGT_STATS_R_EXCH_SEM_0] = dev->rexch.exchQ[0].compSem.waiting;
    dev->stats[SCGT_STATS_R_EXCH_SEM_1] = dev->rexch.exchQ[1].compSem.waiting;
    dev->stats[SCGT_STATS_R_EXCH_SEM_2] = dev->rexch.exchQ[2].compSem.waiting;
    dev->stats[SCGT_STATS_R_EXCH_SEM_3] = dev->rexch.exchQ[3].compSem.waiting;
    
    /* get core stats */
    gtcoreGetStats(dev, stats);
    
    return stats->reserved = SCGT_SUCCESS;
}

/**************************************************************************//**
 * @fn static NTSTATUS scgtIoctlMapMem(scgtDevice *dev, scgtMemMapInfo *mapInfo)
 *
 * @brief    Map GT memory to user space.
 *
 * @param  dev      Pointer to dev info
 * @param  mapInfo  pointer to structure describing the memory map
 *
 * @return .NTSTATUS
 *****************************************************************************/
static NTSTATUS scgtIoctlMapMem(scgtDevice *dev, scgtMemMapInfo *mapInfo)
{
    NTSTATUS           ntStatus;
    UNICODE_STRING     physicalMemoryUnicodeString;
    OBJECT_ATTRIBUTES  objectAttributes;
    HANDLE             physicalMemoryHandle  = NULL;
    PVOID              physicalMemorySection = NULL;
    PHYSICAL_ADDRESS   physicalAddress;
    PVOID              virtualAddress;
    SIZE_T             length;

    ScgtDbgPrint(SCGT_DBG_MAP,("SCGT: scgtIoctlMapMem() - {\n"));
    
    physicalAddress = dev->gtMemPhysAddr;
    length = dev->memSize;

    /*
       Get a pointer to physical memory...
    
       - Create the name
       - Initialize the data to find the object
       - Open a handle to the oject and check the status
       - Get a pointer to the object
       - Free the handle
    */
    RtlInitUnicodeString(&physicalMemoryUnicodeString,
                         L"\\Device\\PhysicalMemory");

    
    InitializeObjectAttributes(&objectAttributes,
                               &physicalMemoryUnicodeString,
                               OBJ_CASE_INSENSITIVE,
                               NULL,
                               NULL);

    ntStatus = ZwOpenSection (&physicalMemoryHandle,
                              SECTION_ALL_ACCESS,
                              &objectAttributes);

    if (!NT_SUCCESS(ntStatus)) 
    {
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: ZwOpenSection() failed\n"));
        mapInfo->reserved = SCGT_DRIVER_ERROR;
        mapInfo->memVirtAddr = 0;
        goto done;
    }
    
    ntStatus = ObReferenceObjectByHandle(physicalMemoryHandle,
                                         SECTION_ALL_ACCESS,
                                         NULL,
                                         KernelMode,
                                         &physicalMemorySection,
                                         NULL);

    if (!NT_SUCCESS(ntStatus)) 
    {
        ScgtDbgPrint(SCGT_DBG_ERROR, ("SCGT: ObReferenceObjectByHandle() failed\n"));
        mapInfo->reserved = SCGT_DRIVER_ERROR;
        mapInfo->memVirtAddr = 0;
        goto close_handle;
    }

    virtualAddress = NULL;  /* let ZwMapViewOfSection pick an address */
    ScgtDbgPrint(SCGT_DBG_MAP,("SCGT: physicalAddress=%08x%08x\n",physicalAddress.HighPart,physicalAddress.LowPart));
    ScgtDbgPrint(SCGT_DBG_MAP,("SCGT: length:%I64d\n",(long long) length));
    /* Map the section */
    ntStatus = ZwMapViewOfSection(physicalMemoryHandle,   //_in     HANDLE SectionHandle
                                  NtCurrentProcess(),     //_in     HANDLE ProcessHandle
                                  &virtualAddress,         // _inout PVOID baseAddress
                                  0L,                     // _in    ULONG_PTR ZeroBits
                                  length,                 // _in    SIZE_T CommitSize
                                  &physicalAddress,       // _inout PLARGE_INTEGER sectionOffset
                                  &length,                // inout  PSIZE_T ViewSize
                                  ViewShare,              // _in    SECTION_INHERIT InheritDisposition
                                  0,                      // _in   ULONG Allocation Type
                                  PAGE_READWRITE | PAGE_NOCACHE); //_IN ULONG Win32Protect

    if (!NT_SUCCESS(ntStatus)) 
    {
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: ZwMapViewOfSection failed\n"));
        if(ntStatus == STATUS_CONFLICTING_ADDRESSES )
        {
           ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: The specified address range conflicts with an address range already reserved, /n" ));
           ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: or the specified cache attribute type conflicts with the address range's existing \n"));
           ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: cache attribute" ));
        }
        else if (ntStatus  == STATUS_INVALID_PAGE_PROTECTION)
        {
           ScgtDbgPrint(SCGT_DBG_ERROR,( "SCGT: The value specified for the Protect parameter is invalid.\n"));
        }
        else if (ntStatus == STATUS_SECTION_PROTECTION )
        {
           ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: The value specified for the AllocationType parameter is incompatible with the \n \
                    protection type specified when the section was created.\n"));
        }
        else
           ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: Unknown status code 0x%x \n" ,ntStatus));
 
        mapInfo->reserved = SCGT_DRIVER_ERROR;
        mapInfo->memVirtAddr = 0;
        goto close_handle;
    }

    mapInfo->memVirtAddr = (uint64) virtualAddress;
    mapInfo->memSize = (uint32) length;
    mapInfo->reserved = SCGT_SUCCESS;
    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: mem ptr 0x%I64x\n", mapInfo->memVirtAddr));
    
close_handle:
    ZwClose(physicalMemoryHandle);
done:

    ScgtDbgPrint( SCGT_DBG_MAP, ("SCGT: scgtIoctlMapMem() - }\n") );

    return ntStatus;
}

/**************************************************************************//**
 * @fn static NTSTATUS scgtIoctlUnmapMem(scgtDevice * dev, scgtMemMapInfo * mapInfo)
 *
 * @brief   Unmap GT memory.
 *
 * @param  dev      Pointer to dev info
 * @param  mapInfo  pointer to structure describing the memory map
 *
 * @return .NTSTATUS
 ******************************************************************************/
static NTSTATUS scgtIoctlUnmapMem(scgtDevice * dev, scgtMemMapInfo * mapInfo)
{
    NTSTATUS ntStatus;

    UNREFERENCED_PARAMETER(dev);

    ntStatus = ZwUnmapViewOfSection(NtCurrentProcess(),
                                    (PVOID) mapInfo->memVirtAddr);

    if (!NT_SUCCESS(ntStatus)) 
        mapInfo->reserved = SCGT_BAD_PARAMETER;
    else
        mapInfo->reserved = SCGT_SUCCESS;

    return ntStatus;
}

/**************************************************************************//**
 * @fn  static void scgtInitGetIntrTimer(scgtDevice *dev)
 *
 * @brief  initialize GetInterrupt timer and semaphore
 *     this must be called before scgtIoctlGetIntr() is called.
 *
 * @param [in,out]  dev   If non-null, the dev. 
 ****************************************************************************/
static void scgtInitGetIntrTimer(scgtDevice *dev)
{
    UNREFERENCED_PARAMETER(dev);

    ksysSemSCreate(&dev->getIntrSem);
    
    ksysSpinLockCreate(&dev->getIntrWaitCountSpinLock);
    ksysSpinLockCreate(&dev->getIntrTimerSpinLock);
    
    dev->getIntrWaitCount = 0;
    dev->getIntrTimerStarted = 0;
    dev->getIntrTmrUseCnt = 0;
    
    KeInitializeTimer(&dev->getIntrTimer);
    KeInitializeDpc(&dev->getIntrTimerDPC, scgtGetIntrTimerCallback, (void *)dev);
}
/**************************************************************************//**
 * @fn  static void scgtDestroyGetIntrTimer(scgtDevice *dev)
 *
 * @brief desctroy get interrupt timer
 *
 * @param [in,out]  dev   If non-null, the dev. 
 *****************************************************************************/
static void scgtDestroyGetIntrTimer(scgtDevice *dev)
{
    UNREFERENCED_PARAMETER(dev);

    getIntrTimerExit = 1;
    //! cancel timer here..
    
    ksysSemSDestroy(&dev->getIntrSem);
    ksysSpinLockDestroy(&dev->getIntrWaitCountSpinLock);
    ksysSpinLockDestroy(&dev->getIntrTimerSpinLock);
}

 
/**************************************************************************//**
 * @fn  static void scgtGetIntrTimerStart(scgtDevice *dev)
 *
 * @brief  start the timer interrupt
 *
 * @param [in,out]  dev   If non-null, the dev. 
 *****************************************************************************/
static void scgtGetIntrTimerStart(scgtDevice *dev)
{
    LARGE_INTEGER timeOffset;  /* 100 ns intervals */
    ksysSpinLockFlags spinLockFlags;

    ksysSpinLockLock(&dev->getIntrTimerSpinLock, &spinLockFlags);
        
    if (!dev->getIntrTimerStarted)
    {
        dev->getIntrTimerStarted = 1;
        ksysSpinLockUnlock(&dev->getIntrTimerSpinLock, &spinLockFlags);
        timeOffset.HighPart = -1;
//        timeOffset.LowPart = SCGT_GET_INTR_TIMER_REL_TIME;
        timeOffset.LowPart = (ULONG)SCGT_GET_INTR_TIMER_REL_TIME;
        KeSetTimer(&dev->getIntrTimer,
                   timeOffset,
                   &dev->getIntrTimerDPC);
    }
    else
    {
        ksysSpinLockUnlock(&dev->getIntrTimerSpinLock, &spinLockFlags);
    }
}

/**************************************************************************//**
 * @fn void scgtGetIntrTimerCallback( IN PKDPC dpc,  IN PVOID context, 
 *                                    IN PVOID sysArg1,  IN PVOID sysArg2)
 *
 * @brief  callback (DPC) function for timer interrupt used in
 *     GetInterrupt() timeouting
 *
 * @param  dpc      The dpc. 
 * @param  context  The context. 
 * @param  sysArg1  The first system argument. 
 * @param  sysArg2  The second system argument. 
 *****************************************************************************/
void scgtGetIntrTimerCallback(IN PKDPC dpc, IN PVOID context, 
                              IN PVOID sysArg1, IN PVOID sysArg2)
{
    UNREFERENCED_PARAMETER(dpc);
    UNREFERENCED_PARAMETER(sysArg1);
    UNREFERENCED_PARAMETER(sysArg2);

    scgtDevice *dev = (scgtDevice *) context;
//    int count;
    LARGE_INTEGER timeOffset;  /* 100 ns intervals */
    ksysSpinLockFlags spinLockFlags;

    if(dev == NULL)
    {
       ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtGetIntrTimerCallback called with null context pointer\n"));
       return;
    }
    scgtGiveIntrSemDPC(dev);
    
    ksysSpinLockLock(&dev->getIntrTimerSpinLock, &spinLockFlags);
    if (dev->getIntrTmrUseCnt && (!getIntrTimerExit))
    {
        ksysSpinLockUnlock(&dev->getIntrTimerSpinLock, &spinLockFlags);
        timeOffset.HighPart = -1;
//        timeOffset.LowPart = SCGT_GET_INTR_TIMER_REL_TIME;
        timeOffset.LowPart = (ULONG)SCGT_GET_INTR_TIMER_REL_TIME;
        KeSetTimer(&dev->getIntrTimer, timeOffset,
                   &dev->getIntrTimerDPC);
    }
    else
    {
        dev->getIntrTimerStarted = 0;  
        ksysSpinLockUnlock(&dev->getIntrTimerSpinLock, &spinLockFlags);
    }
       
    dev->stats[SCGT_STATS_GET_INTR_TIMER]++;
}

/**************************************************************************//**
 * @fn  static int scgtGiveIntrSem(scgtDevice *dev)
 * 
 * @brief   Release getIntrSem semaphore for threads waiting.
 *
 * @param [in,out]  dev   If non-null, the dev. 
 *
 * @return . 
 *****************************************************************************/
static int scgtGiveIntrSem(scgtDevice *dev)
{
    int count;
    ksysSpinLockFlags spinLockFlags;

    ksysSpinLockLock(&dev->getIntrWaitCountSpinLock, &spinLockFlags);  
    count = dev->getIntrWaitCount;
    dev->getIntrWaitCount = 0;
    ksysSpinLockUnlock(&dev->getIntrWaitCountSpinLock, &spinLockFlags);    
    
    if (count > 0) /* somebody waiting */
    {
        for (; count > 0; count--)
            ksysSemSGive(&dev->getIntrSem);
    }

    return count;
}

/**************************************************************************//**
 * @fn  static int scgtGiveIntrSemDPC(scgtDevice *dev)
 *
 * @brief  same as scgtGiveIntrSem() but safe to call only
 *     from DPC.  The spin lock routines used are faster
 *     when already at DPC level.
 *
 * @param [in,out]  dev   If non-null, the dev. 
 *
 * @return . 
 *****************************************************************************/
static int scgtGiveIntrSemDPC(scgtDevice *dev)
{
    int count;

    KeAcquireSpinLockAtDpcLevel(&dev->getIntrWaitCountSpinLock);    
    count = dev->getIntrWaitCount;
    dev->getIntrWaitCount = 0;
    KeReleaseSpinLockFromDpcLevel(&dev->getIntrWaitCountSpinLock);    
    
    if (count > 0) /* somebody waiting */
    {
        for (; count > 0; count--)
            ksysSemSGive(&dev->getIntrSem);
    }

    return count;
}

/**************************************************************************//**
 * @fn  static int scgtIoctlGetIntr(scgtDevice *dev, scgtGetIntrBuf *gibuf)
 *
 * @brief  Scgt ioctl get intr. 
 *
 * @param [in,out]  dev   If non-null, the dev. 
 * @param [in,out]  gibuf If non-null, the gibuf. 
 *
 * @return . 
 *****************************************************************************/
static int scgtIoctlGetIntr(scgtDevice *dev, scgtGetIntrBuf *gibuf)
{
    uint32 ret;
    uint32 waitTime = 0;    /* how long I've waited */
    ksysSpinLockFlags spinLockFlags;

    ksysSpinLockLock(&dev->getIntrTimerSpinLock, &spinLockFlags);    
    dev->getIntrTmrUseCnt++;
    ksysSpinLockUnlock(&dev->getIntrTimerSpinLock, &spinLockFlags);
    
    scgtGetIntrTimerStart(dev);  
        
    while (1)
    {
        if ((ret = gtcoreGetIntr(dev, gibuf)) != SCGT_TIMEOUT)
        {
            break;  /* we got something */
        }
        
        /* if we got here.. we have to wait */
        
        if (waitTime >= gibuf->timeout || getIntrTimerExit)
        {
            gibuf->numInterruptsRet = 0;
            break;
        }
        
        ksysSpinLockLock(&dev->getIntrWaitCountSpinLock, &spinLockFlags);    
        dev->getIntrWaitCount++;
        ksysSpinLockUnlock(&dev->getIntrWaitCountSpinLock, &spinLockFlags);

        ksysSemSTake(&dev->getIntrSem);
        
        waitTime += SCGT_GET_INTR_TIMER_MILLISEC;
    }

    ksysSpinLockLock(&dev->getIntrTimerSpinLock, &spinLockFlags);
    dev->getIntrTmrUseCnt--;
    ksysSpinLockUnlock(&dev->getIntrTimerSpinLock, &spinLockFlags);
    
    return ret;
}

/**************************************************************************//**
 * @fn  static NTSTATUS scgtIoctlGetDeviceInfo(scgtDevice *dev, scgtDeviceInfo *devInfo)
 *
 * @brief  Scgt ioctl get device information. 
 * 
 * @param [in,out]  dev      If non-null, the dev. 
 * @param [in,out]  devInfo  If non-null, information describing the dev. 
 *
 * @return STATUS_SUCCESS 
 *****************************************************************************/
static NTSTATUS scgtIoctlGetDeviceInfo(scgtDevice *dev, scgtDeviceInfo *devInfo)
{    
    devInfo->reserved = gtcoreGetDeviceInfo(dev, devInfo);
    
    RtlStringCbCopyNA(devInfo->driverRevisionStr, 128, driverRevStr, 128);
    RtlStringCbCopyNA(devInfo->boardLocationStr, 128, dev->boardLocationStr, 128);

    return STATUS_SUCCESS;
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtIoctlPNP(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
 *
 * @brief  Scgt ioctl pnp. 
 *
 * @param  deviceObject   The device object. 
 * @param  irp            The irp. 
 *
 * @return . 
 *****************************************************************************/
NTSTATUS scgtIoctlPNP(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
{
    NTSTATUS ret = STATUS_SUCCESS;
    PIO_STACK_LOCATION irpStackLoc;
    KEVENT eventWaitLowerDrivers;
            
    scgtDevice *dev = (scgtDevice *) deviceObject->DeviceExtension;
    
    ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP() - {\n"));
    
    irpStackLoc = IoGetCurrentIrpStackLocation(irp);
    
    //!irp->IoStatus.Status = STATUS_SUCCESS;
    //!irp->IoStatus.Information = 0;
    
    switch (irpStackLoc->MinorFunction)
    {
        case IRP_MN_START_DEVICE:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_START_DEVICE\n"));
            KeInitializeEvent(&eventWaitLowerDrivers, NotificationEvent, FALSE);
            
            IoCopyCurrentIrpStackLocationToNext(irp);

            IoSetCompletionRoutine(irp,
                                   scgtCompletion,
                                   &eventWaitLowerDrivers,
                                   TRUE,
                                   TRUE,
                                   TRUE);

            if ((ret = IoCallDriver(dev->lowerDeviceInStack, irp)) == STATUS_PENDING) 
            {
                KeWaitForSingleObject(&eventWaitLowerDrivers,
                                      Executive,
                                      KernelMode,
                                      FALSE,
                                      NULL);

                ret = irp->IoStatus.Status;
            }
            
            if (NT_SUCCESS(ret))
                ret = scgtStartDevice(deviceObject, &irpStackLoc->Parameters.StartDevice.AllocatedResourcesTranslated->List[0]);
            else
                ret = STATUS_UNSUCCESSFUL;
            
            irp->IoStatus.Status = ret;
            irp->IoStatus.Information = 0;
            IoCompleteRequest(irp, IO_NO_INCREMENT);            
            break;
            
        case IRP_MN_QUERY_STOP_DEVICE:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_QUERY_STOP_DEVICE\n"));
            IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            break;
            
        case IRP_MN_STOP_DEVICE:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_STOP_DEVICE\n"));
            scgtStopDevice(deviceObject);
            IoSkipCurrentIrpStackLocation(irp);
            irp->IoStatus.Status = STATUS_SUCCESS;
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            break;
            
        case IRP_MN_CANCEL_STOP_DEVICE:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_CANCEL_STOP_DEVICE\n"));
            IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            break;
            
        case IRP_MN_QUERY_REMOVE_DEVICE:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_QUERY_REMOVE_DEVICE\n"));
            IoSkipCurrentIrpStackLocation(irp);
            IoMarkIrpPending(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            if(!NT_SUCCESS(ret))
            {
               ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: IRP_MN_QUERY_REMOVE_DEVICE IoCallDriver call failed\n"));
            }
            //ret = STATUS_PENDING;
            break;
            
        case IRP_MN_REMOVE_DEVICE:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_REMOVE_DEVICE\n"));
            
            scgtRemoveDevice(deviceObject);
            
            IoSkipCurrentIrpStackLocation(irp);
            IoMarkIrpPending(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            if(!NT_SUCCESS(ret))
            {
               ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: IRP_MN_REMOVE_DEVICE IoCallDriver call failed\n"));
            }
            //ret = STATUS_PENDING;
            break;
            
        case IRP_MN_CANCEL_REMOVE_DEVICE:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_CANCEL_REMOVE_DEVICE\n"));
            IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            break;
            
        case IRP_MN_SURPRISE_REMOVAL:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_SURPRISE_REMOVAL\n"));
            break;

        case IRP_MN_QUERY_DEVICE_RELATIONS:
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_QUERY_DEVICE_RELATIONS\n"));
            IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            break;

        case IRP_MN_QUERY_INTERFACE:
			ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_QUERY_INTERFACE \n"));
			IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
			break;

		case IRP_MN_QUERY_CAPABILITIES:
			ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_QUERY_CAPABILITIES\n"));
			IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
			break;

		case IRP_MN_QUERY_PNP_DEVICE_STATE:
			ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_QUERY_PNP_DEVICE_STATE\n"));
			IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
			break;
        
		case IRP_MN_DEVICE_USAGE_NOTIFICATION:
			ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_DEVICE_USAGE_NOTIFICATION\n"));
			IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
			break;

		case IRP_MN_QUERY_DEVICE_TEXT:
			ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_QUERY_DEVICE_TEXT\n"));
			IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
			break;

		case IRP_MN_QUERY_ID:
			ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_QUERY_ID\n"));
			IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
			break;

		case IRP_MN_FILTER_RESOURCE_REQUIREMENTS:
			ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN_FILTER_RESOURCE_REQUIREMENTS\n"));
            IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            /* some of these include: IRP_MN_QUERY_PNP_DEVICE_STATE */
            break;

        default:
            /* not supported here.. just pass it down the device stack */
            ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP(): IRP_MN default = %x\n", irpStackLoc->MinorFunction));
            IoSkipCurrentIrpStackLocation(irp);
            ret = IoCallDriver(dev->lowerDeviceInStack, irp);
            
            /* some of these include: IRP_MN_QUERY_PNP_DEVICE_STATE */
            break;
    };
    
    
    ScgtDbgPrint(SCGT_DBG_PNP,("SCGT: scgtIoctlPNP() - }\n"));
    
    return ret; 
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtCompletion(IN PDEVICE_OBJECT deviceObject, IN PIRP irp, IN PVOID context)
 *
 * @brief  used for IRP_MN_START_DEVICE processing.
 *
 * @param  deviceObject   The device object. 
 * @param  irp            The irp. 
 * @param  context        The context. 
 *
* @return . 
  ****************************************************************************/
NTSTATUS scgtCompletion(IN PDEVICE_OBJECT deviceObject, IN PIRP irp, IN PVOID context)
{
    PKEVENT event = (PKEVENT) context;
    PIO_STACK_LOCATION  irpStackLoc;

    UNREFERENCED_PARAMETER(deviceObject);

    irpStackLoc = IoGetCurrentIrpStackLocation(irp);
    switch (irpStackLoc->MajorFunction) 
	{
        case IRP_MJ_PNP:
           if(event == NULL)
           {
              ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtCompletion called with null event context\n"));
              return STATUS_UNSUCCESSFUL;
           }

            KeSetEvent(event, 0, FALSE);    
            /*
             *  Take the IRP back so that we can continue using it during
             *  the IRP_MN_START_DEVICE dispatch routine.
             *  We will have to call IoCompleteRequest
             */
            return STATUS_MORE_PROCESSING_REQUIRED;
            break;
    }
    
    return STATUS_SUCCESS;
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtDeferedIrpCompletion(IN PDEVICE_OBJECT pDO, IN PIRP Irp, IN PKEVENT Event)
 *
 * @brief  Scgt defered irp completion. 
 *
 * @param  pDO   The do. 
 * @param  Irp   The irp. 
 * @param  Event The event. 
 * 
 * @return . 
 *****************************************************************************/
NTSTATUS scgtDeferedIrpCompletion(IN PDEVICE_OBJECT pDO, IN PIRP Irp, IN PKEVENT Event)
{
    UNREFERENCED_PARAMETER(pDO);
    UNREFERENCED_PARAMETER(Irp);

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtDeferedIrpCompletion() - {\n"));
    if(Event == NULL)
    {
       ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtDeferedIrpCompletion called with null event pointer\n"));
       return STATUS_UNSUCCESSFUL;
    }

    KeSetEvent((PKEVENT) Event, 0, FALSE);

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtDeferedIrpCompletion() - }\n"));

    return STATUS_MORE_PROCESSING_REQUIRED;
}

/**************************************************************************//**
 * @fn  static NTSTATUS scgtStartDevice(PDEVICE_OBJECT deviceObject,
 *      PCM_FULL_RESOURCE_DESCRIPTOR fullResourceDescriptor)
 *
 * @brief  Scgt start device. 
 *
 * @param  deviceObject            The device object. 
 * @param  fullResourceDescriptor  The full resource descriptor. 
 *
 * @return . 
 *****************************************************************************/
static NTSTATUS scgtStartDevice(PDEVICE_OBJECT deviceObject, PCM_FULL_RESOURCE_DESCRIPTOR fullResourceDescriptor)
{
    NTSTATUS ret = STATUS_SUCCESS;
    uint32 i;
    int barCount = 0;
    PCM_PARTIAL_RESOURCE_DESCRIPTOR	partialDescriptor;
    PCM_PARTIAL_RESOURCE_LIST partialList;
    KINTERRUPT_MODE interruptMode;
    scgtDevice *dev = (scgtDevice *) deviceObject->DeviceExtension;
    
    ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: scgtStartDevice() - {\n"));
    
    partialDescriptor = fullResourceDescriptor->PartialResourceList.PartialDescriptors;
    partialList = &fullResourceDescriptor->PartialResourceList;

    for (i = 0; i < partialList->Count; i++)
    {   
        switch (partialDescriptor->Type)
        {
            case CmResourceTypeInterrupt:
                dev->interruptVector = partialDescriptor->u.Interrupt.Vector;
                dev->interruptAffinity = partialDescriptor->u.Interrupt.Affinity;
                dev->interruptLevel = partialDescriptor->u.Interrupt.Level;
                
                ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: Interrupt level: 0x%x, Vector: 0x%x, Affinity: 0x%I64x\n",
                         dev->interruptLevel, dev->interruptVector, (UINT64) dev->interruptAffinity));
                
                // CM_RESOURCE_INTERRUPT_LEVEL_SENSITIVE  = 0 
                // so flag & CM_RESOURCE_INTERRUPT_LEVEL_SENSITIVE always true
                // if (partialDescriptor->Flags & CM_RESOURCE_INTERRUPT_LEVEL_SENSITIVE)
                if (partialDescriptor->Flags == CM_RESOURCE_INTERRUPT_LEVEL_SENSITIVE)
                {
                    ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: Interrupt Mode: LevelSensitive\n"));
                    interruptMode = LevelSensitive;
                }
                else if (partialDescriptor->Flags & CM_RESOURCE_INTERRUPT_LATCHED)
                {
                    ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: Interrupt Mode: Latched\n"));
                    interruptMode = Latched;
                }
                else
                {
                    ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: !! Unknown Interrupt Mode !!\n"));
                    interruptMode = LevelSensitive; 
                }

                /* attach ISR */
                ret = IoConnectInterrupt(&dev->interruptObject, 
                                         scgtISR, 
                                         deviceObject, 
                                         NULL,
                                         dev->interruptVector,
                                         (KIRQL) dev->interruptLevel,
                                         (KIRQL) dev->interruptLevel,
                                         interruptMode, 
                                         TRUE,
                                         dev->interruptAffinity,
                                         0);                
                if (NT_SUCCESS(ret))
                {
                    ScgtDbgPrint( SCGT_DBG_INIT, ("SCGT: Interrupt Attached\n"));
                }
                else
                {
                    ScgtDbgPrint( SCGT_DBG_ERROR,("SCGT: Interrupt Attach Failed!\n"));
                }
                break;
            
            case CmResourceTypeDma:
                ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: DMA Channel: %x\n", partialDescriptor->u.Dma.Channel)); 
                break;
            
            case CmResourceTypeMemory:
                switch (barCount)
                {
                    case GTCORE_BAR_C_REGISTERS:
                        dev->cRegPtr = MmMapIoSpace(partialDescriptor->u.Port.Start, 
                                                    partialDescriptor->u.Port.Length,
                                                    FALSE);
                        ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: BAR 1 0x%x 0x%x\n", partialDescriptor->u.Port.Start.LowPart,
                                                    partialDescriptor->u.Port.Length));
                        break;
                    
                    case GTCORE_BAR_NM_REGISTERS:
                        dev->nmRegPtr = MmMapIoSpace(partialDescriptor->u.Port.Start, 
                                                     partialDescriptor->u.Port.Length,
                                                     FALSE);                                               
                        ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: BAR 2 0x%x 0x%x\n", partialDescriptor->u.Port.Start.LowPart,
                                                    partialDescriptor->u.Port.Length));
                        break;
                        
                    case GTCORE_BAR_MEMORY:
                        dev->gtMemPhysAddr = partialDescriptor->u.Port.Start;
                        dev->memSize = partialDescriptor->u.Port.Length;
                        ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: BAR 0 0x%x 0x%x\n", dev->gtMemPhysAddr.LowPart, dev->memSize));
                        break;
                }
                
                barCount++;
                break;
        }
        partialDescriptor++;    
    }
    
    if ((dev->cRegPtr == NULL) || (dev->nmRegPtr == NULL))
    {
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: Mapping Failed!\n"));
        ret = STATUS_UNSUCCESSFUL;
    }
    
    ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: reg: 0x%x, 0x%x, 0x%x\n", scgtReadCReg(dev, 0), scgtReadCReg(dev, 4), scgtReadCReg(dev, 8)));

    if( *Mm64BitPhysicalAddress == TRUE) 
       dev->Is64BitOS = TRUE;
    else
       dev->Is64BitOS = FALSE;
    
    ScgtDbgPrint(SCGT_DBG_IS64,("SCGT: OS is %s bit\n",dev->Is64BitOS?"64":"32"));

    scgtInitDMATools(dev);
    if( scgtInitDMA(dev) != STATUS_SUCCESS)
    {
       ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT scgtInitDma failed\n"));
       ret = STATUS_UNSUCCESSFUL;
    }
    dev->mapData = dev->dmaAdapter;
    scgtInitGetIntrTimer(dev);

    scgtStartThread(dev);
    
    ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: calling gtcoreInit()\n"));
    gtcoreInit(dev);

    ScgtDbgPrint(SCGT_DBG_INIT,("SCGT: scgtStartDevice() - }\n"));


    return ret;
}

/**************************************************************************//**
 * @fn  static ULONG scgtBusNum(IN PDEVICE_OBJECT physDevObj)
 *
 * @brief returns bus number of device
 *
 * @param  physDevObj  The phys dev object. 
 *
 * @return . 
 *****************************************************************************/
static ULONG scgtBusNum(IN PDEVICE_OBJECT physDevObj)
{
    ULONG busNum;
    ULONG reslen;

    IoGetDeviceProperty(physDevObj,
                        DevicePropertyBusNumber,
                        sizeof (ULONG),
                        &busNum,
                        &reslen);

    return busNum;
}

/**************************************************************************//**
 * @fn  static ULONG scgtSlotNum(IN PDEVICE_OBJECT pDO)
 *
 * @brief   returns slot number of device (-1 on error)
 *
 * @param  pDO   The do. 
 *
 * @return . 
 *****************************************************************************/
static ULONG scgtSlotNum(IN PDEVICE_OBJECT pDO)
{
    ULONG slotNum;
    PIO_STACK_LOCATION newStackLocation;
    PIRP myirp;
    scgtDevice *dev;
    KEVENT IoCtlEvent;
    DEVICE_CAPABILITIES *dcap;

    dcap = ExAllocatePoolWithTag(PagedPool, sizeof(DEVICE_CAPABILITIES),'TGCS');
    if(dcap == NULL) 
//       return -1;
       return (ULONG)-1;
    dcap->Size = sizeof(DEVICE_CAPABILITIES);
    dcap->Version = 1;
//    dcap->Address = -1;
//    dcap->UINumber = -1;
    dcap->Address = (ULONG)-1;
    dcap->UINumber = (ULONG)-1;

    dev = pDO->DeviceExtension;

    if ((myirp = IoAllocateIrp(pDO->StackSize, FALSE)) == NULL)
    {
        ExFreePoolWithTag(dcap,'TGCS'); 
//        return -1;
        return (ULONG)-1;
    }
        
    KeInitializeEvent(&IoCtlEvent, NotificationEvent, FALSE);
    IoSetCompletionRoutine(myirp, scgtDeferedIrpCompletion, &IoCtlEvent, TRUE, TRUE, TRUE);
	
    if ((newStackLocation = IoGetNextIrpStackLocation(myirp)) == NULL)
    {
        ExFreePoolWithTag(dcap,'TGCS'); 
//        return -1;
        return (ULONG)-1;
    }
        
    newStackLocation->MajorFunction = IRP_MJ_PNP;
    newStackLocation->MinorFunction = IRP_MN_QUERY_CAPABILITIES;
    newStackLocation->Parameters.DeviceCapabilities.Capabilities = dcap;

    if (IoCallDriver(dev->lowerDeviceInStack, myirp) == STATUS_PENDING)
        KeWaitForSingleObject(&IoCtlEvent, Executive, KernelMode, FALSE, NULL);

    slotNum = dcap->UINumber;

    IoFreeIrp(myirp);				
    ExFreePoolWithTag(dcap,'TGCS');

    return slotNum;
}

/**************************************************************************//**
 * @fn  static void scgtStopDevice(PDEVICE_OBJECT deviceObject)
 *
 * @brief  Scgt stop device. 
 *
 * @param  deviceObject   The device object. 
 *****************************************************************************/
static void scgtStopDevice(PDEVICE_OBJECT deviceObject)
{
   scgtDevice *dev = (scgtDevice *) deviceObject->DeviceExtension;

   ScgtDbgPrint(SCGT_DBG_HALT,("SCGT: scgtStopDevice() - {\n"));

   /* disconnect interrupt */
   if (dev->interruptObject != NULL)
   {
      IoDisconnectInterrupt(dev->interruptObject);
      dev->interruptObject = NULL;
   }

   scgtStopThread(dev);

   /* free allocated resources */
   gtcoreDestroy(dev);
   scgtDestroyGetIntrTimer(dev);

   scgtDestroyDMATools(dev);

   
   /* unmap registers */
   if (dev->cRegPtr) 
   {
      ScgtDbgPrint(SCGT_DBG_HALT,("SCGT: Unmapping Config Registers.\n"));
      MmUnmapIoSpace(dev->cRegPtr, GTCORE_REGISTER_SIZE);
      dev->cRegPtr = NULL;
   }
   if (dev->nmRegPtr) 
   {
      ScgtDbgPrint(SCGT_DBG_HALT,("SCGT: Unmapping Network Management Registers\n"));
      MmUnmapIoSpace(dev->nmRegPtr, GTCORE_NM_REGISTER_SIZE);
      dev->nmRegPtr = NULL;
   }

   /* destroy DMA adapter */
   if (dev->dmaAdapter)
   {
      ScgtDbgPrint(SCGT_DBG_HALT,("SCGT: Release DMA adapter.\n"));
      (*dev->dmaAdapter->DmaOperations->PutDmaAdapter)(dev->dmaAdapter);
      dev->dmaAdapter = NULL;
   }

   ScgtDbgPrint(SCGT_DBG_HALT,("SCGT: scgtStopDevice() - }\n"));
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtIoctlPOWER(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
 *
 * @brief  Scgt ioctl power. 
* 
 * @param  deviceObject   The device object. 
 * @param  irp            The irp. 
 *
 * @return . 
 *****************************************************************************/
NTSTATUS scgtIoctlPOWER(IN PDEVICE_OBJECT deviceObject, IN PIRP irp)
{
    scgtDevice *dev = (scgtDevice *) deviceObject->DeviceExtension;

    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtIoctlPOWER() - {\n"));

    PoStartNextPowerIrp(irp);
    IoSkipCurrentIrpStackLocation(irp);
    
    ScgtDbgPrint(SCGT_DBG_INFO,("SCGT: scgtIoctlPOWER() - }\n"));
    
    return PoCallDriver(dev->lowerDeviceInStack, irp);
}

/**************************************************************************//**
 * @fn  static void scgtCopyToUser(void *userPtrDest, void *src, uint32 numBytes)
 *
 * @brief  Scgt copy to user. 
 *
 * @param [in,out]  userPtrDest If non-null, the user pointer destination. 
 * @param [in,out]  src         If non-null, source for the. 
 * @param  numBytes             Number of bytes. 
 *****************************************************************************/
static void scgtCopyToUser(void *userPtrDest, void *src, uint32 numBytes)
{
    MDL *mdl;
    uint8 *dest;
        
    if ((mdl = IoAllocateMdl(userPtrDest, numBytes, FALSE, FALSE, NULL)) == NULL)
    {
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtCopyToUser(): mdl allocation failed\n"));
        return;
    }
    
    try
    {
        MmProbeAndLockPages(mdl, UserMode, IoModifyAccess);
    }
    except (EXCEPTION_EXECUTE_HANDLER)
    {
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtCopyToUser(): probe and lock failed \n"));
        IoFreeMdl(mdl);
        return;
    }
    
    if ((dest = MmGetSystemAddressForMdlSafe(mdl, NormalPagePriority)) != NULL)
    {
        /* do the copy */
        memcpy(dest, src, numBytes);
    }

    MmUnlockPages(mdl);
    IoFreeMdl(mdl);
}

/**************************************************************************//**
 * @fn  static void scgtCopyFromUser(void *dst, void *userPtrSrc, uint32 numBytes)
 *
 * @brief  Scgt copy from user. 
 *
 * @param [in,out]  dst         If non-null, destination for the. 
 * @param [in,out]  userPtrSrc  If non-null, the user pointer source. 
 *  @param  numBytes             Number of bytes. 
 *****************************************************************************/
static void scgtCopyFromUser(void *dst, void *userPtrSrc, uint32 numBytes)
{
    MDL *mdl;
    uint8 *src;
    
    if ((mdl = IoAllocateMdl(userPtrSrc, numBytes, FALSE, FALSE, NULL)) == NULL)
    {
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtCopyFromUser(): mdl allocation failed\n"));
        return;
    }
    
    try
    {
        MmProbeAndLockPages(mdl, UserMode, IoReadAccess);
    }
    except (EXCEPTION_EXECUTE_HANDLER)
    {
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtCopyFromUser(): probe and lock failed \n"));
        IoFreeMdl(mdl);
        return;
    }
    
    if ((src = MmGetSystemAddressForMdlSafe(mdl, NormalPagePriority)) != NULL)
    {
        /* do the copy */
        memcpy(dst, src, numBytes);
    }

    MmUnlockPages(mdl);
    IoFreeMdl(mdl);
}

/***********************************************************************/
/**************************** DMA CODE *********************************/
/***********************************************************************/

/**************************************************************************//**
 * @fn  static int scgtInitDMATools(scgtDevice *dev)
 *
 * @brief  Allocate and initialize DMA tools for device.
 *
 * @param [in,out]  dev   If non-null, the dev. 
 *
 * @return  returns 0 on success, non-zero on failure.
 *****************************************************************************/
static int scgtInitDMATools(scgtDevice *dev)
{
    ksysSemSCreate(&dev->writeTools.entrySem_1);
    ksysSemSCreate(&dev->writeTools.entrySem_2);
    ksysSemSCreate(&dev->readTools.entrySem_1);
    ksysSemSCreate(&dev->readTools.entrySem_2);
    
    ksysSemSGive(&dev->writeTools.entrySem_1);    /* semaphores start as taken */
    ksysSemSGive(&dev->writeTools.entrySem_2);
    ksysSemSGive(&dev->readTools.entrySem_1);
    ksysSemSGive(&dev->readTools.entrySem_2);
    
    dev->writeTools.pending = 0;
    dev->readTools.pending = 0;

    dev->MaxDMABlockSize= SCGT_MAX_CHUNK_SIZE;
    return 0;
}

/**************************************************************************//**
 * @fn  static void scgtDestroyDMATools(scgtDevice *dev)
 *
 * @brief  Deallocate DMA tools for device.
 *
 * @param [in,out]  dev   If non-null, the dev.
 *****************************************************************************/
static void scgtDestroyDMATools(scgtDevice *dev)
{
    UNREFERENCED_PARAMETER(dev);

    ksysSemSDestroy(&dev->writeTools.entrySem_1);
    ksysSemSDestroy(&dev->writeTools.entrySem_2);
    ksysSemSDestroy(&dev->readTools.entrySem_1);
    ksysSemSDestroy(&dev->readTools.entrySem_2);
}

/**************************************************************************/ 
/**
 * @fn static uint32 scgtIoctlXfer( scgtDevice *dev,
 *                           PIRP irp,
 *                           scgtXfer *xfer,
 *                           scgtInterrupt *intr,
 *                           uint8 direction)
 *
 * @brief   process write or read transfer
 *
 * @param [in,out]  dev   If non-null, the dev. 
 * @param  irp            The irp. 
 * @param [in,out]  xfer  If non-null, the xfer. 
 * @param [in,out]  intr  If non-null, the intr. 
 * @param  direction      The direction. 
 *
 * @return .SCGT_SUCCESS or error code.
 *****************************************************************************/
static uint32 scgtIoctlXfer(scgtDevice *dev,
                            PIRP irp,
                            scgtXfer *xfer,
                            scgtInterrupt *intr,
                            uint8 direction)
{
    uint32 gtMemoryOffset;
    uint32 bytesToTransfer;
    uint32 bytesTransferred;
    uint32 chunkSize;
    uint32 flags;
    uint8  lastTransfer;
    uint32 ret = SCGT_SUCCESS;
    uint8  *pBuf;
    scgtDMATools *dmaTools;
    ksysSemS *semToGive;
    
    ScgtDbgPrint(SCGT_DBG_XFER,("SCGT: scgtIoctlXfer - {\n"));
    
    pBuf = (uint8 *) xfer->pDataBuffer;
    bytesToTransfer = xfer->bytesToTransfer;
    gtMemoryOffset = xfer->gtMemoryOffset;
    
    if (bytesToTransfer == 0 || pBuf == NULL)
        return gtcoreSendIntr(dev, intr);
    
    flags = xfer->flags;
    dmaTools = (direction == GTCORE_WRITE)? &dev->writeTools : &dev->readTools;

    ksysSemSTake(&dmaTools->entrySem_1);
    semToGive = &dmaTools->entrySem_1;

    while (bytesToTransfer > 0 && ret == SCGT_SUCCESS)
    {
        /* calculate chunk size */
        chunkSize = (bytesToTransfer >= dev->MaxDMABlockSize)? dev->MaxDMABlockSize : bytesToTransfer;
        lastTransfer = (chunkSize == bytesToTransfer)? 1 : 0;
    
        ret = scgtXferChunk(dev, irp, gtMemoryOffset, pBuf, chunkSize, lastTransfer,
                            flags, intr, direction, dmaTools, &bytesTransferred,
                            &semToGive);

        bytesToTransfer -= bytesTransferred;
        pBuf += bytesTransferred;
        gtMemoryOffset += bytesTransferred;
    }
    
    ksysSemSGive(semToGive);

    xfer->bytesTransferred = xfer->bytesToTransfer - bytesToTransfer;
    
	ScgtDbgPrint( SCGT_DBG_XFER,("SCGT: scgtIoctlXfer ret:%s- }\n",scgtErrorCodeToString(ret)) );
    
    return ret;
}


/**************************************************************************//**
 * @fn  static uint32 scgtXferChunk(scgtDevice *dev,
 *                          PIRP irp,
 *                          uint32 gtMemoryOffset, 
 *                          uint8  *pBuf, 
 *                          uint32 chunkSize,
 *                          uint8 lastTransfer,
 *                          uint32 flags,
 *                          scgtInterrupt *intr,
 *                          uint8  direction,
 *                          scgtDMATools *tools,
 *                          uint32 *bytesTransferred,
 *                          ksysSemS **semToGive)
 *
 * @brief  reads or writes a chunk of up to size dev->MaxDMABlockSize of the 
 *     specified buffer.  bytesTransferred is filled with the number of bytes
 *     transferred.
 *
 * @param  dev                        If non-null, the dev. 
 * @param  irp                        The irp. 
 * @param  gtMemoryOffset             The gt memory offset. 
 * @param  pBuf                       If non-null, the buffer. 
 * @param  chunkSize                  Size of the chunk. 
 * @param  lastTransfer               The last transfer. 
 * @param  flags                      The flags. 
 * @param [in,out]  intr              If non-null, the intr. 
 * @param  direction                  The direction. 
 * @param [in,out]  tools             If non-null, the tools. 
 * @param [in,out]  bytesTransferred  If non-null, the bytes transferred. 
 * @param [in,out]  semToGive         If non-null, the sem to give. 
 *
 * @return . 
 ***************************************************************************/
static uint32 scgtXferChunk(scgtDevice *dev,
                            PIRP irp,
                            uint32 gtMemoryOffset, 
                            uint8  *pBuf, 
                            uint32 chunkSize,
                            uint8 lastTransfer,
                            uint32 flags,
                            scgtInterrupt *intr,
                            uint8  direction,
                            scgtDMATools *tools,
                            uint32 *bytesTransferred,
                            ksysSemS **semToGive)
{
    uint32 ret;
//    uint32 numScatterBuffers;
    gtcoreExch *exch;
    PMDL mdl = NULL; // initialize value of mdl to avoid VS2015 error later in code

    UNREFERENCED_PARAMETER(irp);

    exch = gtcoreGetExchange(dev, direction);
    exch->bytesTransferred = 0;
    
    ScgtDbgPrint(SCGT_DBG_XFER,("SCGT: scgtXferChunk() begin\n"));
    
    exch->bytesToTransfer = chunkSize;
    exch->gtMemoryOffset = gtMemoryOffset;
    exch->flags = flags;
    
    if (lastTransfer)     /* setup intr for last transfer */
        exch->intr = intr;
    else
        exch->intr = NULL;

    if (!(flags & SCGT_RW_DMA_PHYS_ADDR))  /* not physical address */
    {
        /* map the buffer to the MDL */    
        if ((mdl = IoAllocateMdl(pBuf, chunkSize, FALSE, FALSE, NULL)) == NULL)
        {
            ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: UNABLE TO IoAllocateMdl()!!\n"));
            *bytesTransferred = 0;
            return SCGT_INSUFFICIENT_RESOURCES;
        }      

        try
        {
            MmProbeAndLockPages(mdl, UserMode, 
                                (direction == GTCORE_WRITE)? IoWriteAccess : IoReadAccess);
        }
        except (EXCEPTION_EXECUTE_HANDLER)
        {
            ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: UNABLE TO Probe and lock pages()!!\n"));
            return SCGT_SYSTEM_ERROR;
        }

        /* build the hardware chain list */
        ret = scgtBuildChainList(dev, mdl, exch, direction, chunkSize);
        if ( ret != SCGT_SUCCESS )
        {
            ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtBuildChainList call failed. ret=%d\n",ret) );
        }
    }
    else
    {
        /* mode is SCGT_DMA_PHYS (physical address supplied) */
        uint32 *chainEntry = (uint32 *) exch->sgList[0];
        
        chainEntry[GTCORE_CE_TNS_CSR] = (chunkSize >> 2) | GTCORE_CE_LST;
        chainEntry[GTCORE_CE_BUF_ADD32] = (uint32) pBuf;
        ksysCacheFlush(NULL, chainEntry, GTCORE_CE_SIZE);    
    }

    /* do transfer */
    gtcoreTransfer(dev, exch, direction);

    if (lastTransfer)  /* last transfer */
    {
        ksysSemSTake(&tools->entrySem_2);
        
        tools->pending = 1;

        /* let the next thread enter */
        ksysSemSGive(&tools->entrySem_1);
        *semToGive = &tools->entrySem_2;  /* swap the exit semaphore to sem 2 */
    }
    else if (tools->pending)
    {
        ksysSemSTake(&tools->entrySem_2);
        ksysSemSGive(&tools->entrySem_2);
    }

    /* wait until its done. */
    if (ksysSemBTakeWithTimeout(&exch->compSem, SCGT_TIMEOUT_TIME))
    {
        /* hardware did not complete transfer! */
        ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: scgtXferChunk timed out \n") );
        ret = SCGT_TIMEOUT;  
        gtcoreCancelTransfer(dev, exch, direction);
    }
    else
    {
        ret = exch->status;
    }
  
    *bytesTransferred = exch->bytesTransferred;

    if ((*bytesTransferred != chunkSize) && (ret == SCGT_SUCCESS))
        ret = SCGT_HARDWARE_ERROR;

    tools->pending = 0;

    if (!(flags & SCGT_RW_DMA_PHYS_ADDR))  /* not physical address */
    {
       if(dev->Is64BitOS)
       {
          int buf = exch->exchQIndex % SCGT_DMA_NUM_BUFFERS;
          if(direction == GTCORE_READ )
          {
             char * bufV;
             bufV = MmGetMdlVirtualAddress(mdl);
             memcpy(bufV,dev->DmaRead[buf].pData,exch->bytesTransferred);
#ifdef DBG_DMA
             ScgtDbgPrint(SCGT_DBG_XFER,("SCGT: scgtXferChunk() complete READ from Buffer=%d \n",buf));
             if( dev->DmaRead[buf].Status != SCGT_DMA_FULL)
             {
                ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT error dev->DmaWrite[%d].Status = EMPTY. Cnt:%d\n",buf,dev->DmaRead[buf].Cnt));
             }
             dev->DmaRead[buf].Status = SCGT_DMA_EMPTY;
             dev->DmaRead[buf].Cnt--;
#endif
          }
#ifdef DBG_DMA
          else
          {
             ScgtDbgPrint(SCGT_DBG_XFER,("SCGT: scgtXferChunk() Wrote from Buffer=%d \n",buf));
             if( dev->DmaWrite[buf].Status != SCGT_DMA_FULL)
                ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT error dev->DmaWrite[%d].Status = EMPTY\n",buf));
              dev->DmaWrite[buf].Status = SCGT_DMA_EMPTY;
              dev->DmaWrite[buf].Cnt--;
          }
#endif
       }
       /* unmap buffer */
       MmUnlockPages(mdl);
       IoFreeMdl(mdl);		
    }
      
    ScgtDbgPrint(SCGT_DBG_XFER,("SCGT: scgtXferChunk() end\n"));
    
    return ret;
}

/***************************************************************************//**
 * @fn  static int scgtBuildChainList(scgtDevice *dev, PMDL mdl, 
 *                                     gtcoreExch *exch, uint32 direction,
 *                                      uint32 chainLenBytes)
 *
 * @brief  build a board-readable scatter-gather list from MDL
 *
 *
 * @param [in,out]  dev   If non-null, the dev. 
 * @param  mdl            The mdl. 
 * @param [in,out]  exch  If non-null, the exch. 
 * @param  direction      The direction. 
 * @param  chainLenBytes  The chain length in bytes. 
 *
 * @return . 
 *****************************************************************************/
static int scgtBuildChainList(scgtDevice *dev, PMDL mdl, gtcoreExch *exch, 
                              uint32 direction, uint32 chainLenBytes)
{

//    ULONG mappedSize, curLenBytes;
    ULONG mappedSize;
    ULONG chainEntryNum;
 
    uint32 *chainEntry;
    PHYSICAL_ADDRESS dmaAddress;
    char *bufV;
    int bufIndex;

    ScgtDbgPrint(SCGT_DBG_DMA,("SCGT: scgtBuildChainList() start \n"));
    /* 
     * Flush the cache before Writes and invalidate the cache before Reads 
     * This is a null macro for x86 systems which are cache coherent with
     * respect to DMA operations.
     */
     /* KeFlushIoBuffers( Mdl, (flags == FXSL_RECV), TRUE );   /* our only target is x86 */
   
    chainEntry = (uint32 *) exch->sgList[0];
    chainEntryNum = 0;
    
    bufV = MmGetMdlVirtualAddress(mdl);
       
    do
    {
        /*
         * map what we can.. try all that's left.
         */
        mappedSize = chainLenBytes;
        if(dev->Is64BitOS)
        {
           bufIndex = exch->exchQIndex % SCGT_DMA_NUM_BUFFERS;
           if(bufIndex >= SCGT_DMA_NUM_BUFFERS)
           {
              ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT buffIndex:%d >= SCGT_DMA_NUM_BUFFERS:%d ",bufIndex,SCGT_DMA_NUM_BUFFERS));
              bufIndex=0;
           }
           if(exch->direction == GTCORE_WRITE)
           {
#ifdef DBG_DMA
              if( dev->DmaWrite[bufIndex].Status != SCGT_DMA_EMPTY)
                 ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT error dev->DmaWrite[%d].Status = FULL\n",bufIndex) );
              dev->DmaWrite[bufIndex].Status = SCGT_DMA_FULL;
#endif
              dmaAddress = dev->DmaWrite[bufIndex].physAddr;
              memcpy(dev->DmaWrite[bufIndex].pData,bufV,mappedSize);
              ScgtDbgPrint(SCGT_DBG_DATA,("SCGT: write %d bytes  Buff Addr:%08x%08x\n",
                           mappedSize,dmaAddress.HighPart,dmaAddress.LowPart));
           }
           else
           {
#ifdef DBG_DMA
              if( dev->DmaRead[bufIndex].Status != SCGT_DMA_EMPTY)
              {
                 ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT error dev->DmaRead[%d].Status = FULL\n",bufIndex));
              }
#endif
              dmaAddress = dev->DmaRead[bufIndex].physAddr;
              dev->DmaRead[bufIndex].Status = SCGT_DMA_FULL;
              dev->DmaRead[bufIndex].Cnt++;
              ScgtDbgPrint(SCGT_DBG_DATA,("SCGT: Read %d bytes.  Buff Addr:%08x%08x\n",
                 mappedSize,dmaAddress.HighPart,dmaAddress.LowPart));
           }
        }
        else
        {
          dmaAddress = dev->dmaAdapter->DmaOperations->MapTransfer(dev->dmaAdapter, mdl, NULL,
                                                                 bufV, &mappedSize, 
                                                                 (BOOLEAN) (direction == GTCORE_WRITE));
        }
        chainEntry[GTCORE_CE_TNS_CSR] = mappedSize >> 2;
        chainEntry[GTCORE_CE_BUF_ADD32] = dmaAddress.LowPart;
        chainEntry[GTCORE_CE_BUF_ADD64] = dmaAddress.HighPart;
        chainEntry += (GTCORE_CE_SIZE / 4);
        
        chainEntryNum++;
        bufV += mappedSize;
        chainLenBytes -= mappedSize;
    } while ((chainLenBytes > 0) && (chainEntryNum < SCGT_DMA_CHAIN_LEN));
    
    
    /*
     * set the last chain entry bit
     */
    chainEntry -= (GTCORE_CE_SIZE / 4);
    chainEntry[GTCORE_CE_TNS_CSR] |= GTCORE_CE_LST;
    
    if ((chainEntryNum == SCGT_DMA_CHAIN_LEN) && (chainLenBytes > 0))
    {
        ScgtDbgPrint(SCGT_DBG_ERROR,(" chainEntryNum:%d == SCGT_DMA_CHAIN_LEN %d chainLenBytes=%d \n", \
                   chainEntryNum, SCGT_DMA_CHAIN_LEN, chainLenBytes ));
        ScgtDbgPrint(SCGT_DBG_ERROR,("buildChainList: out of chain entries!\n"));
        return SCGT_INSUFFICIENT_RESOURCES;
    }
    ScgtDbgPrint(SCGT_DBG_DMA,("SCGT: scgtBuildChainList() end\n"));
    return SCGT_SUCCESS;
}



/*******************************************************************/
/************************ INTERRUPT SERVICE ************************/
/*******************************************************************/
 

/**************************************************************************//**
 * @fn  BOOLEAN scgtISR(IN PKINTERRUPT interrupt, IN OUT PVOID context)
 *
 * @brief  Interrupt service routine
 *
 * @param  interrupt   The interrupt. 
 * @param  context     The context. 
 *
 * @return true if it succeeds, false if it fails. 
 *****************************************************************************/
BOOLEAN scgtISR(IN PKINTERRUPT interrupt, IN OUT PVOID context)
{
    scgtDevice *dev;
    PDEVICE_OBJECT deviceObject = (PDEVICE_OBJECT) context;
    uint32 intRet;

    UNREFERENCED_PARAMETER(interrupt);

    dev = (scgtDevice *) deviceObject->DeviceExtension;
    if ((intRet = gtcoreHandleInterrupt(dev)) != 0)
    {    
        if (intRet > 1)
        {
           /* call DPC */   
            IoRequestDpc(deviceObject, NULL, (PVOID) intRet);
        }
        
        return TRUE;
    }

    return FALSE;  /* not our interrupt */
}

#if 0
/*
 * scgtDPC()
 *     delayed procedure call.. (aka: ISR bottom half)
 *     NOTE: more than 1 DPC can be running at once!  The call to gtcoreCompleteDMA
 *           has to be protected.
 */
 
void scgtDPC(IN PKDPC dpc, IN PDEVICE_OBJECT deviceObject, IN PIRP irp, IN PVOID context)
{
    scgtDevice *dev = (scgtDevice *) deviceObject->DeviceExtension;
    uint32 intRet;

    dev->stats[SCGT_STATS_DPC]++;

    intRet = (uint32) context;

    if (intRet & GTCORE_ISR_DMA)
    {
        dev->stats[SCGT_STATS_DPC_DMA]++;
 
        //KeAcquireSpinLockAtDpcLevel(&dev->dpcSpinLock);
        gtcoreCompleteDMA(dev);
        //KeReleaseSpinLockFromDpcLevel(&dev->dpcSpinLock);    
    }
    
    if (intRet & GTCORE_ISR_QUEUED_INTR)
    {
        scgtGiveIntrSemDPC(dev);
    }
}

#endif

/**************************************************************************//**
 * @fn  void scgtDPC(IN PKDPC dpc, IN PDEVICE_OBJECT deviceObject, IN PIRP irp, IN PVOID context)
 *
 * @brief  Scgt dpc. 
 * 
 * @param  dpc            The dpc. 
 * @param  deviceObject   The device object. 
 * @param  irp            The irp. 
 * @param  context        The context. 
 *****************************************************************************/
void scgtDPC(IN PKDPC dpc, IN PDEVICE_OBJECT deviceObject, IN PIRP irp, IN PVOID context)
{
    scgtDevice *dev = (scgtDevice *) deviceObject->DeviceExtension;
    uint32 intRet;

    UNREFERENCED_PARAMETER(dpc);
    UNREFERENCED_PARAMETER(irp);

    dev->stats[SCGT_STATS_DPC]++;

    intRet = (uint32) context;

    if (intRet & GTCORE_ISR_DMA)
    {
        ksysSemBGive(&dev->threadSem);
    }
    
    if (intRet & GTCORE_ISR_QUEUED_INTR)
    {
        scgtGiveIntrSemDPC(dev);
    }
}

/**************************************************************************//**
 * @fn  void scgtInterruptThread( PVOID StartContext)
 *
 * @brief  Scgt interrupt thread. 
 * 
 * @param  StartContext   Context for the start. 
 *****************************************************************************/
void scgtInterruptThread( PVOID StartContext)
{
    scgtDevice *dev;
    dev = (scgtDevice *) StartContext;

    while(!dev->threadTimeToExit)
    {
        ksysSemBTake(&dev->threadSem);

        gtcoreCompleteDMA(dev);
    }

    ksysSemBDestroy(&dev->threadSem);
    PsTerminateSystemThread(STATUS_SUCCESS);
}

/**************************************************************************//**
 * @fn  NTSTATUS scgtStartThread(scgtDevice *dev)
 *
 * @brief  Scgt start thread. 
 *
 * @param [in,out]  dev   If non-null, the dev. 
 *****************************************************************************/
NTSTATUS scgtStartThread(scgtDevice *dev)
{
    HANDLE hThread;
    PKTHREAD thread;
    NTSTATUS ret = STATUS_SUCCESS;
    
    ksysSemBCreate(&dev->threadSem);
    dev->threadTimeToExit = 0;

    ret = PsCreateSystemThread(&hThread, THREAD_ALL_ACCESS, NULL, (HANDLE) 0, NULL,
                         scgtInterruptThread, dev);
    if(!NT_SUCCESS(ret) )
    {
      ScgtDbgPrint(SCGT_DBG_ERROR,("SCGT: PsCreateSystemThread call failed\n"));
      return ret;
    }
    ObReferenceObjectByHandle(hThread, THREAD_ALL_ACCESS, NULL, KernelMode,
                              &thread, NULL);
    KeSetPriorityThread(thread, LOW_REALTIME_PRIORITY);
    return ret;
}

/**************************************************************************//**
 * @fn  void scgtStopThread(scgtDevice *dev)
 *
 * @brief  Scgt stop thread. 
 *
 * @param [in,out]  dev   If non-null, the dev. 
 *****************************************************************************/
void scgtStopThread(scgtDevice *dev)
{
    dev->threadTimeToExit = 1;
    ksysSemBGive(&dev->threadSem);
}


/**************************************************************************//**
 * @fn  uint32 scgtDrvExchChain(scgtDevice *dev, gtcoreExchMgrData *exchMgrData,
 *                           uint32 exchNum, uint8 direction, uint8 doAlloc)
 *     Allocate and initialize or Deallocate a chain for the exchange.
 *
 * @param [in,out]  dev         If non-null, the dev. 
 * @param [in,out]  exchMgrData If non-null, information describing the exch manager. 
 * @param  exchNum              The exch number. 
 * @param  direction            The direction. 
 * @param  doAlloc              The do allocate. 
 *
 * @return  Returns SCGT_SUCCESS if successful.
*****************************************************************************/
uint32 scgtDrvExchChain(scgtDevice *dev, gtcoreExchMgrData *exchMgrData, 
                       uint32 exchNum, uint8 direction, uint8 doAlloc)
{
   uint32 mySize;
   int i;
   volatile uint32 *chainEntry;
   gtcoreExch *exch;
   uint64 nextAddr;
   PHYSICAL_ADDRESS logicalAddress;
   
   ScgtDbgPrint(SCGT_DBG_EXCH,("SCGT: scgtDrvExchChain. %s\n", (doAlloc == 0) ? " Free exchange":"allocate exchange" ) );

   exch = &exchMgrData->exchQ[exchNum];

   /* sgSpace of mySize is/will be larger than needed to cover aligment
      and cache safety */

#ifdef SCGT_EXCH_CHAIN_ONE_MAP
   mySize = GTCORE_CHAIN_BYTES * GTCORE_EXCH_CNT + GTCORE_CACHE_LINE_SIZE * 2;
#else
   mySize = GTCORE_CHAIN_BYTES + GTCORE_CACHE_LINE_SIZE * 2;
#endif

   if (doAlloc == 0)
   {
#ifdef SCGT_EXCH_CHAIN_ONE_MAP
      if (exchNum != 0)
         return SCGT_SUCCESS;
#endif
      if (exch->sgSpace != NULL)
      {
         logicalAddress.QuadPart = ((uint64) exch->sgListPhysAddr[0]) + ( (PCHAR) exch->sgList[0] - (PCHAR)exch->sgSpace ); 
		 ScgtDbgPrint(SCGT_DBG_EXCH,("SCGT: scgtDrvExchChain call free buffer at address 0x%08lx%08lx\n",
			          logicalAddress.HighPart,logicalAddress.LowPart));
         dev->dmaAdapter->DmaOperations->FreeCommonBuffer(dev->dmaAdapter,
                        mySize,logicalAddress,(PVOID)exch->sgSpace,FALSE);
      }
      return SCGT_SUCCESS;
   }
#ifdef SCGT_EXCH_CHAIN_ONE_MAP
   /**** allocate and map chain for only exchange 0 
         use offsets into it for other exchanges ******/

   if (exchNum == 0)
   {
      /* allocate the space, align it, and map */
      exch->sgSpace = (uint32*) dev->dmaAdapter->DmaOperations->AllocateCommonBuffer(dev->dmaAdapter, mySize,&logicalAddress,FALSE);
      if (exch->sgSpace == NULL)
         return SCGT_DRIVER_ERROR;
	  ScgtDbgPrint(SCGT_DBG_EXCH,("SCGT: scgtDrvExchChain call allocated buffer at address 0x%08lx%08lx\n",
			          logicalAddress.HighPart,logicalAddress.LowPart));
      exch->sgList[0] = (uint32 *) gtcoreAlignAddr((void *) exch->sgSpace, GTCORE_CACHE_LINE_SIZE);

      exch->sgListPhysAddr[0] = logicalAddress.QuadPart - ( (PCHAR) exch->sgList[0] - (PCHAR)exch->sgSpace  ) 

      if (exch->sgListPhysAddr[0] == 0)
         return SCGT_DRIVER_ERROR;
   }
   else
   {
      /* here we use an offset into the already mapped address from exchange 0 */
      gtcoreExch *exch0 = &exchMgrData->exchQ[0];

      if (exch0->sgList[0] == NULL)
        return SCGT_DRIVER_ERROR;

      /* sgList[0] is type uint32 * so we add num of words to get new ptr */
      exch->sgList[0] = exch0->sgList[0] + ((exchNum * GTCORE_CHAIN_BYTES) / 4);
      exch->sgListPhysAddr[0] = exch0->sgListPhysAddr[0] + (exchNum * GTCORE_CHAIN_BYTES);
      exch->sgDmaHandle = exch0->sgDmaHandle;
   }
#else
   /**** allocate and map chain for every exchange separately ******/
   exch->sgSpace = (uint32*) dev->dmaAdapter->DmaOperations->AllocateCommonBuffer(
                                                 dev->dmaAdapter, mySize,&logicalAddress,FALSE);
   if (exch->sgSpace == NULL)
      return SCGT_DRIVER_ERROR;

   exch->sgList[0] = (uint32 *) gtcoreAlignAddr((void *) exch->sgSpace, GTCORE_CACHE_LINE_SIZE);

   exch->sgListPhysAddr[0] = logicalAddress.QuadPart - ( (PCHAR) exch->sgList[0] - (PCHAR)exch->sgSpace ); 

   if (exch->sgListPhysAddr[0] == 0)
      return SCGT_DRIVER_ERROR;
#endif

   /* initialize each chain entry */
   chainEntry = exch->sgList[0];
   for (i = 0; i < GTCORE_EXCH_CNT; i++)
   {
      chainEntry[GTCORE_CE_BUF_ADD32] = 0;
      chainEntry[GTCORE_CE_TNS_CSR] = 0;
      chainEntry[GTCORE_CE_BUF_ADD64] = 0;

      chainEntry[GTCORE_CE_RESERVED_0] = direction << 24 | exchNum << 16 | i;  /* debugging purposes */        
      chainEntry[GTCORE_CE_RESERVED_1] = 0;
      chainEntry[GTCORE_CE_RESERVED_2] = 0;

      /* assumes memory is physically contiguous */
      nextAddr = exch->sgListPhysAddr[0] + (i+1) * GTCORE_CE_SIZE;
      chainEntry[GTCORE_CE_NEXT_ADD32] = (uint32) nextAddr;
      chainEntry[GTCORE_CE_NEXT_ADD64] = (uint32) (nextAddr >> 32);

      chainEntry += (GTCORE_CE_SIZE / 4);  /* move to next chain queue entry */
   }

   return SCGT_SUCCESS;
}

/**************************************************************************//**
 * @fn  uint32 scgtDrvTrQueue(scgtDevice *dev, gtcoreExchMgrData *exchMgrData, 
 *                         uint8 direction,uint8 doAlloc)
 *
 * @brief  setup scgt transaction queue. 
 *
 * @param [in,out]  dev         If non-null, the dev. 
 * @param [in,out]  exchMgrData If non-null, information describing the exch manager. 
 * @param  direction            The direction. 
 * @param  doAlloc              The do allocate. 
 *
 * @return SCGT_SUCCESS or error code on failure
 *****************************************************************************/
uint32 scgtDrvTrQueue(scgtDevice *dev, gtcoreExchMgrData *exchMgrData,
                     uint8 direction, uint8 doAlloc)
{
    uint32 qSize;
    uint32 i;
    uint32 *tqe;
    PHYSICAL_ADDRESS logicalAddress;

    UNREFERENCED_PARAMETER(direction);

    qSize = (GTCORE_EXCH_CNT * GTCORE_TQE_SIZE) + (GTCORE_CACHE_LINE_SIZE * 2);

	ScgtDbgPrint(SCGT_DBG_TRQUEUE,("SCGT: scgtDrvTrQueue. %s tranfer queue.\n", (doAlloc == 0) ? " Free ":"allocate" ) );
    
    if (doAlloc == 0)
    {
        if (exchMgrData->trSpace != NULL)
        {
            /* free trSpace */
            if (exchMgrData->trSpace)
            {
                logicalAddress.QuadPart=exchMgrData->trPhysical +  ( (PCHAR) exchMgrData->trSpace -(PCHAR) exchMgrData->trQueue);
				ScgtDbgPrint(SCGT_DBG_TRQUEUE, ("SCGT: Free Transaction queue. At LogicalAddress :0x%08x%08x", logicalAddress.HighPart,logicalAddress.LowPart));
                dev->dmaAdapter->DmaOperations->FreeCommonBuffer(dev->dmaAdapter,
                        qSize,logicalAddress,(PVOID)exchMgrData->trSpace,FALSE);
            }
            exchMgrData->trSpace = NULL;
        }
        
        return SCGT_SUCCESS;
    }
    
    /* Allocate space for the Transaction Queues */
    /* Triple the size for alignment purposes */
    exchMgrData->trSpace = (uint32 *) dev->dmaAdapter->DmaOperations->AllocateCommonBuffer(
                                                 dev->dmaAdapter, qSize,&logicalAddress,FALSE);
    if (exchMgrData->trSpace == NULL)
        return SCGT_DRIVER_ERROR;

    memset(exchMgrData->trSpace,0,qSize);

    exchMgrData->trQueue = gtcoreAlignAddr((void *) exchMgrData->trSpace, GTCORE_CACHE_LINE_SIZE);

    exchMgrData->trPhysical = (uint64) logicalAddress.QuadPart -  ( (PCHAR) exchMgrData->trSpace -(PCHAR) exchMgrData->trQueue);

    ScgtDbgPrint(SCGT_DBG_TRQUEUE, ("SCGT: Map Transaction queue. At LogicalAddress :0x%08x%08x", logicalAddress.HighPart,logicalAddress.LowPart));
    ScgtDbgPrint(SCGT_DBG_TRQUEUE, ("SCGT: exchMgrData->trQueue:0x%p  exchMgrData->trSpace:%p ",exchMgrData->trQueue,exchMgrData->trSpace));
                                                        
    if (exchMgrData->trPhysical == 0)
    {
        dev->dmaAdapter->DmaOperations->FreeCommonBuffer(dev->dmaAdapter,
                        qSize,logicalAddress,(PVOID)exchMgrData->trSpace,FALSE);
        return SCGT_DRIVER_ERROR;
    }

    /* initialize some members of each transaction queue entry 
       that won't change on a transfer by transfer basis */
    tqe = exchMgrData->trQueue;

    for (i = 0; i < GTCORE_EXCH_CNT; i++)
    {
        tqe[GTCORE_TQE_NI_CTL] = 0;
        tqe[GTCORE_TQE_RESERVED_0] = 0;
        tqe[GTCORE_TQE_RESERVED_1] = 0;
        tqe += (GTCORE_TQE_SIZE / 4);
    }

    return SCGT_SUCCESS;
}
