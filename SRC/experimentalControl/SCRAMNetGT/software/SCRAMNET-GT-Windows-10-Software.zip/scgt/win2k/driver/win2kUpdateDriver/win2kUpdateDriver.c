/*
 * updateGTDriver.c
 *     Force update of GT driver on Windows 2000 and friends.
 */


#include <windows.h>
#include <setupapi.h>
#include <newdev.h>

#include <direct.h>
#include <stdlib.h>
#include <stdio.h>

#include <tchar.h>


#define DEVICE      "PCI\\VEN_1387&DEV_5310&SUBSYS_53101387"

#define UPDATED_MSG "SCRAMNet GT driver updated successfully.\n"     \
                    "Please reboot before attempting to use this software. \n" \
                    "Press OK to reboot, Cancel to reboot later."

void Reboot();

//int APIENTRY WinMain(HINSTANCE hInstance,
main(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
    char cwd[_MAX_PATH];
    BOOL what = TRUE;
    
    if (MessageBox(GetDesktopWindow(),
                   (LPTSTR)"Updating SCRAMNet GT driver\nPress OK to continue",
                   (LPTSTR)"SCRAMNet GT Driver Update.",
                   MB_OKCANCEL) == IDCANCEL)
    {
        return -1;
    }

    /* Get the current working directory: */
    if (_getcwd(cwd, _MAX_PATH) == NULL)
    {
        MessageBox(GetDesktopWindow(),
                   (LPTSTR)"Failed to get CWD!",
                   (LPTSTR)"ERROR",
                   MB_OK);

        return -2;
    }

    sprintf(cwd, "%s%s", cwd, "\\scgt.inf");

    if (UpdateDriverForPlugAndPlayDevices(GetDesktopWindow(),
                                          (LPTSTR)DEVICE,
                                          (LPTSTR)cwd,
                                          INSTALLFLAG_FORCE,
                                          &what))
    {
        if (MessageBox(GetDesktopWindow(),
                       (LPTSTR)UPDATED_MSG,
                       (LPTSTR)"SCGT Driver Update Status",
                       MB_OKCANCEL) == IDOK)
        {
            Reboot();
        }
    }
    else
    {
        DWORD dwErrCode;
        LPVOID lpMsgBuf;

        dwErrCode= GetLastError();

        if (!FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, 
	                   NULL,
	                   dwErrCode,
	                   MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
	                   (LPTSTR) &lpMsgBuf,
	                   0,
	                   NULL))
	{
            MessageBox(GetDesktopWindow(),
                       (LPTSTR)"ERROR installing driver..", 
                       (LPTSTR)"SCGT Driver Update Error", 
                       MB_OK | MB_ICONINFORMATION);
            return -3;
	}

        // Display the string.
        MessageBox(GetDesktopWindow(),
                   (LPCTSTR) lpMsgBuf, 
                   (LPTSTR)"SCGT Driver Update Error", 
                   MB_OK | MB_ICONINFORMATION);

        // Free the buffer.
        LocalFree( lpMsgBuf );
    }

    return 0;
}

void Reboot()
{
    HANDLE hToken;
    TOKEN_PRIVILEGES tkp;
    SECURITY_ATTRIBUTES sa;
    
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    if (!OpenProcessToken(GetCurrentProcess(),
                          (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY),
                          &hToken)) 
    {
        return;
    }
    
    LookupPrivilegeValue(NULL,
                         SE_SHUTDOWN_NAME,
                         &tkp.Privileges[0].Luid );

    tkp.PrivilegeCount = 1;
    tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    AdjustTokenPrivileges(hToken,
                          FALSE,
                          &tkp,
                          0,
                          (PTOKEN_PRIVILEGES) NULL,
                          0);

    if (GetLastError() != ERROR_SUCCESS)
    {
        return;
    }

    ExitWindowsEx(EWX_REBOOT | EWX_FORCE, 0);
}
