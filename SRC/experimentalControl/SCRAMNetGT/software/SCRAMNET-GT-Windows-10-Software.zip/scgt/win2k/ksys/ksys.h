/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2002-2005 Curtiss-Wright Controls.                           */
/*               support@systran.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

/*
 * ksys.h
 *     Win2k ksys
 */
 
#ifndef __K_SYS_H__
#define __K_SYS_H__

/*********************************/
/********* INCLUDE FILES *********/
/*********************************/

#include "systypes.h"
#include <Wdm.h>

#define FILE_REV_KSYS_H    "7"     /* 03/13/2009 */


/*****************************************/
/************** DEFINITIONS **************/
/******************************************/

#define MAX_SEM_CNT  128

#define ksysAlignTQueueAddr(ptr, tqsize)   ((void*)((uintpsize)ptr & ~((uintpsize)(tqsize - 1))))
#define ksysCacheFlush(dmaHandlePtr, ptr, size)
#define ksysCacheInvalidate(dmaHandlePtr, ptr, size)

/* default ksysDmaMallocs are used for Windows */

/****************************************/
/********** TYPES & STRUCTURES **********/
/****************************************/

/* For implementation of semaphores w/ timeouts */

typedef struct _ksysSemB
{
    volatile uint32 waiting;  /* used for stats only.. */
    KSEMAPHORE sem;
} ksysSemB;

#define ksysSemBCreate(pSemB)  KeInitializeSemaphore(&((pSemB)->sem), 0, MAX_SEM_CNT); (pSemB)->waiting = 0
#define ksysSemBDestroy(pSemB)

/*******************************************************/
/***** simple semaphore (no timeout functionality) *****/
/*******************************************************/

typedef KSEMAPHORE ksysSemS;

#define ksysSemSCreate(pSemS)     KeInitializeSemaphore((pSemS), 0, MAX_SEM_CNT)
#define ksysSemSDestroy(pSemS)
#define ksysSemSTake(pSemS)       KeWaitForSingleObject(((PVOID)(pSemS)), Executive, KernelMode, FALSE, NULL)
///#define ksysSemSTake(pSemS)       KeWaitForSingleObject(((PHANDLE)(pSemS)), Executive, KernelMode, FALSE, NULL)
#define ksysSemSGive(pSemS)       KeReleaseSemaphore((pSemS), 0, 1, FALSE);

/******************************/
/****** mutex type ************/
/******************************/

typedef FAST_MUTEX ksysMutex;

#define ksysMutexCreate(pMutex)   ExInitializeFastMutex(pMutex)
#define ksysMutexDestroy(pMutex)  
#define ksysMutexTake(pMutex)     ExAcquireFastMutex(pMutex)
#define ksysMutexGive(pMutex)     ExReleaseFastMutex(pMutex)
#define ksysMutexTry(pMutex)      ExTryToAcquireFastMutex(pMutex)

/******************************/
/****** spin lock type ********/
/******************************/

typedef KSPIN_LOCK ksysSpinLock;
typedef KIRQL      ksysSpinLockFlags;

#define ksysSpinLockCreate(pSpinLock)   KeInitializeSpinLock((pSpinLock))
#define ksysSpinLockDestroy(pSpinLock)  
#define ksysSpinLockLock(pSpinLock, pSpinLockFlags)     KeAcquireSpinLock((pSpinLock), (pSpinLockFlags))
#define ksysSpinLockUnlock(pSpinLock, pSpinLockFlags)   KeReleaseSpinLock((pSpinLock), *(pSpinLockFlags))

/****************** prototypes ********************/

void ksysCopyToUser(void *userPtrDest, void *src, uint32 numBytes);
void ksysCopyFromUser(void *dst, void *userPtrSrc, uint32 numBytes);


uint32 ksysMapVirtToBus(void *dmaHandle, void *ptr, uint32 numBytes);
void ksysUnmapVirtToBus(void *dmaHandle, void *ptr);

void ksysWriteReg(void *pRegs, uint32 offset, uint32 val);
uint32 ksysReadReg(void *pRegs, uint32 offset);

void *ksysMalloc(uint32 nbytes);
void ksysFree(void *p, uint32 len);

/* timeouting binary semaphore */

uint32 ksysSemBTakeWithTimeout(ksysSemB *p_sem, long to);
uint32 ksysSemBTake(ksysSemB *p_sem);
uint32 ksysSemBGive(ksysSemB *p_sem);

void ksysUSleep(unsigned long usec);


#endif /* __K_SYS_H__ */
