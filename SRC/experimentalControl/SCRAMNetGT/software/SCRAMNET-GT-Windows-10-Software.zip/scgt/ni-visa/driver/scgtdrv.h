/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2002-2005 Curtiss-Wright Controls.                           */
/*               support@systran.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/*                                                                            */
/*    Module      : scgtdrv.h                                                 */
/*    Description : SCRAMNet GT driver external interface definition          */
/*    Platform    : Windows 2000                                              */
/*                                                                            */
/******************************************************************************/

#ifndef __SCGT_DRV_H__
#define __SCGT_DRV_H__

#define FILE_REV_SCGTDRV_H   "1"   /* 12/10/03 */

/**************************************************************************/
/**************************  D E F I N E S ********************************/
/**************************************************************************/

#define SCGT_MAX_DEVICES  16

#define SCGT_DEV_FILE_STR  "\\\\.\\scgt"

#define SCGT_SGPTR_ARRAY_LEN 1
#define SCGT_MAX_CHUNK_SIZE  0x40000  /* 256K chunk size */
//#define SCGT_MAX_CHUNK_SIZE  0x10000  /* 256K Bytes 64K dwords chunk size */
//DLC #define SCGT_DMA_CHAIN_LEN  (SCGT_MAX_CHUNK_SIZE/PAGE_SIZE+2)
#define SCGT_DMA_CHAIN_LEN  (1+2) 

#ifdef MAP_REGS
/*
#define scgtWriteCReg(pdev, offset, val) \
        *((char*)pdev->cRegPtr + (offset)) = (val)
        
#define scgtReadCReg(pdev, offset) \
        *((char*)pdev->cRegPtr + (offset))

#define scgtWriteNMReg(pdev, offset, val) \
        *((char *)pdev->nmRegPtr+ (offset) ) = (val)
        
#define scgtReadNMReg(pdev, offset) \
        *((char*)pdev->nmRegPtr+(offset))
*/

#define scgtWriteCReg(pdev, offset, val) \
        ksysWriteReg(pdev->cRegInstr,pdev->cRegMappedAddr, offset, val)
        
#define scgtReadCReg(pdev, offset) \
        ksysReadReg(pdev->cRegInstr,pdev->cRegMappedAddr, offset)

#define scgtWriteNMReg(pdev, offset, val) \
        ksysWriteReg(pdev->nmRegInstr,pdev->nmRegMappedAddr, offset, val)
        
#define scgtReadNMReg(pdev, offset) \
        ksysReadReg(pdev->nmRegInstr,pdev->nmRegMappedAddr, offset)

#else

#define scgtWriteCReg(pdev, offset, val) \
        (pdev->viData->instr,VI_PXI_BAR0_SPACE, offset, val)
        
#define scgtReadCReg(pdev, offset) \
        ksysReadReg(pdev->viData->instr,VI_PXI_BAR0_SPACE, offset)

#define scgtWriteNMReg(pdev, offset, val) \
        ksysWriteReg(pdev->viData->instr,VI_PXI_BAR1_SPACE, offset, val)
        
#define scgtReadNMReg(pdev, offset) \
        ksysReadReg(pdev->viData->instr,VI_PXI_BAR1_SPACE, offset)
#endif

/******************************************************************/        
/************************* IOCTL Defs *****************************/
/******************************************************************/

#define SCGT_IOCTL_BASE       0xb00
//#define SCGT_IOCTL_CODE(num)  CTL_CODE(FILE_DEVICE_UNKNOWN, SCGT_IOCTL_BASE + num, METHOD_BUFFERED, FILE_READ_ACCESS)
#define SCGT_IOCTL_CODE(num)  SCGT_IOCTL_BASE+num

#define SCGT_IOCTL_MAP_MEM          SCGT_IOCTL_CODE(6)
#define SCGT_IOCTL_UNMAP_MEM        SCGT_IOCTL_CODE(7)
#define SCGT_IOCTL_WRITE            SCGT_IOCTL_CODE(8)
#define SCGT_IOCTL_READ             SCGT_IOCTL_CODE(9)
#define SCGT_IOCTL_READ_CR          SCGT_IOCTL_CODE(10)
#define SCGT_IOCTL_WRITE_CR         SCGT_IOCTL_CODE(11)

#define SCGT_IOCTL_MEM_MAP_INFO     SCGT_IOCTL_CODE(12)

#define SCGT_IOCTL_GET_DEVICE_INFO  SCGT_IOCTL_CODE(13)
#define SCGT_IOCTL_GET_STATE        SCGT_IOCTL_CODE(14)
#define SCGT_IOCTL_SET_STATE        SCGT_IOCTL_CODE(15)
#define SCGT_IOCTL_READ_NMR         SCGT_IOCTL_CODE(16)
#define SCGT_IOCTL_WRITE_NMR        SCGT_IOCTL_CODE(17)
#define SCGT_IOCTL_GET_STATS        SCGT_IOCTL_CODE(18)
#define SCGT_IOCTL_GET_INTR         SCGT_IOCTL_CODE(19)

/* debugging */
#define SCGT_IOCTL_PUT_INTR         SCGT_IOCTL_CODE(20)



DLLEXPORT scgtViData* scgtDriverOpen(uint32 unitNum);
DLLEXPORT uint32 scgtDriverClose(scgtViData *viData);
DLLEXPORT uint32 scgtVisaIoctHandler( scgtViData * viData, ViUInt32 ioctlCode,
	                                  void * bufPtr, int busSize);

#endif /* __SCGT_DRV_H__ */
