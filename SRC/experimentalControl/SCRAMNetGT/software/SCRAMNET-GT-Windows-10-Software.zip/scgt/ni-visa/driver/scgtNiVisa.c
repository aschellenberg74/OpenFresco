#include "scgtapi.h"
#include <ansi_c.h>
#include "systypes.h"
#include "gtcoreIoctl.h"
#include "scgtdrv.h"
//#include "scgt.h" //inlcuded in gtcore.h
#include "gtcore.h"

#include "utility.h" 

/************************************************************************/
/***************************  D E F I N E S  ****************************/
/************************************************************************/

#define SCGT_DRIVER_VERSION "1.0LvRt"
char *FILE_REV_SCGT_C = "2"; /* 9/13/2011 */

//DLC #define SCGT_TIMEOUT_TIME    100
#define SCGT_TIMEOUT_TIME    5000

/************************************************************************/
/****************  F U N C T I O N  P R O T O T Y P E S  ****************/
/************************************************************************/
void gtcoreInitDevice(scgtDevice *dev); /* from gtcore.c */

/* from  gtcorexfer.c */
void gtcoreEnqueueNetIntrs( scgtDevice *dev ); 
uint32 gtcoreHandleInterrupt2(scgtDevice *dev, uint32 intCSR); 

/* Local Prototypes */
ViSession scgtFindGtCard (uint32 unitNum, scgtViData* viData);
scgtDevice * scgtGetDevicePtrFromUnitNum(uint32 unitNum);
scgtDevice * scgtGetDevicePtrFromViSession(ViSession instr);
uint32 scgtLocalMapRegisters(scgtDevice *pDev);
uint32 scgtLocalMapMem( scgtDevice* dev, scgtMemMapInfo * mmi);
uint32 scgtLocalUnMapMem( scgtViData *viData, scgtMemMapInfo * mmi);
uint32 scgtIoctlGetDeviceInfo(scgtDevice *dev, scgtDeviceInfo *devInfo);
int scgtIoctlGetStats(scgtDevice *dev, scgtStats *stats);
int scgtIoctlGetIntr(scgtDevice *dev, scgtGetIntrBuf *gibuf);
int scgtInitDmaTools(scgtDevice *dev);
void scgtDestroyDmaTools(scgtDevice *dev);

void scgtInitGetIntrTimer(scgtDevice *dev);
void scgtDestroyGetIntrTimer(scgtDevice *dev);

ViStatus _VI_FUNCH  scgtViEventHandler( ViSession vi, ViEventType eventType, 
                                        ViEvent context, ViAddr userHandle );

void scgtInitDriverRev( void );

void gtVisaTransfer(scgtDevice *dev, gtcoreExch *exch, uint8 direction);

/************************************************************************/
/***************************  G L O B A L S  ****************************/
/************************************************************************/

scgtDevice devices[SCGT_MAX_DEVICES];
uint8 numDevices = 0;

char driverRevStr[128];


#include <cvirte.h>

int __stdcall DllMain (HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
   int i;
   switch (fdwReason)
   {
      case DLL_PROCESS_ATTACH:
         if (InitCVIRTE (hinstDLL, 0, 0) == 0)
            return 0;     /* out of memory */
      break;
      case DLL_PROCESS_DETACH:
         for(i=0;i<SCGT_MAX_DEVICES;i++)
         {
            if(devices[i].viData)
            {
               //printf("In DLL cleanup code \n");
               if(devices[i].memVirtAddr != VI_NULL )
               {
                  viUnmapAddress(devices[i].viData->instr);
               }
               scgtDriverClose(devices[i].viData);
            }
         }
         CloseCVIRTE ();
         break;
   }
   
   return 1;
}

int __stdcall DllEntryPoint (HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
   /* Included for compatibility with Borland */

   return DllMain (hinstDLL, fdwReason, lpvReserved);
}


/**************************************************************************/
/*  function:     scgtFindGtCard                                          */
/*  description:  Find GT card and open handle to device                  */
/**************************************************************************/
ViSession scgtFindGtCard (uint32 unitNum, scgtViData* viData)
{
   ViStatus status;
   ViSession defaultRM;
   ViSession instr;
   ViFindList findList;
   char desc[VI_FIND_BUFLEN];
   ViUInt32 numInstr;
   ViUInt32 brdNum;
   ViUInt16 manufacturerID;
   ViUInt16 modelCode;
   
   status = viOpenDefaultRM(&defaultRM);
   if(status < VI_SUCCESS)
   {
      viClose(defaultRM);
      return VI_NULL;
   }
   
   /* Find all Curtiss Wright (Systran) devices in the system */
   status = viFindRsrc(defaultRM,"?*PXI?*{VI_ATTR_MANF_ID==0x1387 && VI_ATTR_MODEL_CODE==0x5310}",&findList,&numInstr,desc);
   if(status < VI_SUCCESS)
   {
      /* No cards with vendor ID 0x1387 found in system */
         viClose(defaultRM);
      return VI_NULL;
   }

   brdNum = 0;

   /* open a session to each device found to see if it is a GT card */
   while( numInstr-- )
   { 
      status = viOpen(defaultRM,desc,VI_NULL,VI_NULL,&instr);
      if(status < VI_SUCCESS)
      {
         viFindNext(findList,desc);
         continue;
      }
      status = viGetAttribute(instr,VI_ATTR_MANF_ID,&manufacturerID);
      if ((status < VI_SUCCESS) || (manufacturerID != 0x1387) )
      {
         viClose(instr);
         viFindNext(findList,desc);
         continue;
      }
      status = viGetAttribute(instr,VI_ATTR_MODEL_CODE,&modelCode);
      if( (status < VI_SUCCESS) || (modelCode != 0x5310) )
      {
         viClose(instr);
         viFindNext(findList,desc);
         continue;
      }
       /* We Have a GT card  */
      if(unitNum == brdNum)
      {
         viData->instr = instr;
         viData->unitNum = unitNum;
         viData->defaultRM= defaultRM;
         strncpy(viData->instrDescriptor,desc,VI_FIND_BUFLEN);
         
         viClose(findList);
         /* Do not close defaultRm as this would close the gtSession */
         return instr;
      }
      brdNum++;
      viClose(instr);
      viFindNext(findList,desc);
   }
   /* No Match Found return an error */
   status = viClose(findList);
   status = viClose(defaultRM);
   return VI_NULL;
}


/**************************************************************************/
/*  function:     scgtGetDevicePtrFromUnitNum                             */
/*  description:  look for device entry with given unit number and if not */
/*                found create one                                        */
/**************************************************************************/
scgtDevice * scgtGetDevicePtrFromUnitNum(uint32 unitNum)
{
   uint32 devNum;
   scgtDevice* pDev;
   
   devNum = 0;
   while(devNum < numDevices)
   {
      if(devices[devNum].unitNum == unitNum) 
            break;
        devNum++;
    }
   if(devNum < numDevices)
   {
      pDev = &devices[devNum];
   }
   else if (numDevices < SCGT_MAX_DEVICES)
    {
      pDev = &devices[numDevices];
      memset(pDev, 0, sizeof(scgtDevice));
      pDev->viData = VI_NULL;
      numDevices++;
   }
   else
   {
       pDev = VI_NULL;
   }
   return pDev;
}


/**************************************************************************/
/*  function:     scgtGetDevicePtrFromViSession                           */
/*  description:  look for device entry with given ViSession Vlaues and   */
/*                if not found create one                                 */
/**************************************************************************/
scgtDevice * scgtGetDevicePtrFromViSession(ViSession instr)
{
   uint32 devNum;
   scgtDevice* pDev;
   
   devNum = 0;
   while(devNum < numDevices)
   {
      if(devices[devNum].viData->instr == instr) 
      {
         return &devices[devNum];
        }
        devNum++;
    }
   
   if (numDevices < SCGT_MAX_DEVICES)
    {
      pDev = &devices[numDevices];    
      memset(pDev, 0, sizeof(scgtDevice) );
      pDev->viData = VI_NULL;
      numDevices++;
   }
   else
   {
      pDev = VI_NULL;
   }
   return pDev;
}

/**************************************************************************/
/*  function:     scgtLocalMapRegisters                                   */
/*  description:  memory map the control status and network management    */
/*                register address spaces                                 */
/**************************************************************************/
#ifdef MAP_REGS
uint32 scgtLocalMapRegisters(scgtDevice *pDev)
{
   ViBusSize memBarSize;
   ViBusAddress offset;
   ViBusAddress busAddr;
   ViStatus status;
   //ViAddr cRegMemMappedAddress;
   //ViAddr nmRegMemMappedAddress;
   ViUInt16 access;

   status = 0;
   
   /* ---------------------------------------------------------------------*/
   /* Map the Control Status Registers in Bar 0                            */
   /* ---------------------------------------------------------------------*/
   
   /* open VI seesion for mapping control status registers */
   status = viOpen(pDev->viData->defaultRM,pDev->viData->instrDescriptor,
                  VI_NULL,VI_NULL,&pDev->cRegInstr);
   if(status < VI_SUCCESS)
      return SCGT_DRIVER_ERROR;
   
   /* Get size of memory aperature */
   status = viGetAttribute(pDev->cRegInstr,VI_ATTR_PXI_MEM_SIZE_BAR0,
                          &memBarSize);
   if((memBarSize < 0x100) || (status < VI_SUCCESS))
   {
       /* memory aperature should be 256 Bytes in size */
      return SCGT_DRIVER_ERROR;
   }

   /* Get address of memory Aperature */
   status = viGetAttribute(pDev->cRegInstr,VI_ATTR_PXI_MEM_BASE_BAR0,
                          &busAddr);
   if(status < VI_SUCCESS)
   {
      return SCGT_DRIVER_ERROR;
   }
   
   /* set read offset in PXI address space */
   offset = 0;
    
   /* Map the device memory */
   status = viMapAddressEx(pDev->cRegInstr,VI_PXI_BAR0_SPACE,offset,
                        memBarSize, VI_FALSE,VI_NULL,&pDev->cRegMappedAddr);
   if(status < VI_SUCCESS)
   {
       return SCGT_DRIVER_ERROR;
   }
   
   viGetAttribute(pDev->cRegInstr, VI_ATTR_WIN_ACCESS, &access);
    if (access == VI_DEREF_ADDR)
   {
      /* store pointer to control status registers in scgtDevice structure */
       pDev->cRegPtr = (void*) pDev->cRegMappedAddr;
   }
   else
   {
      return SCGT_DRIVER_ERROR;
   /* else need to use peek poke commands */
    /*  viPoke16(instr, address, 0x1234); */
   }

   
   /* store pointer to contreol status registers in scgtDevice structure */
   pDev->cRegPtr = pDev->cRegMappedAddr;
   
   
    /* ---------------------------------------------------------------------*/
    /* Map the Network Management registers in BAR 1                        */
   /* ---------------------------------------------------------------------*/
   
   status = viOpen(pDev->viData->defaultRM,pDev->viData->instrDescriptor,
                  VI_NULL,VI_NULL,&pDev->nmRegInstr);
   if(status < VI_SUCCESS)
      return SCGT_DRIVER_ERROR;
   
   /* Get size of memory aperature */
   status = viGetAttribute(pDev->nmRegInstr,VI_ATTR_PXI_MEM_SIZE_BAR1,
                          &memBarSize);
   if((memBarSize < 0x2000) || (status < VI_SUCCESS))
   {
       /* memory aperature should be 8KB in size */
      return SCGT_DRIVER_ERROR;
   }

   /* Get address of memory aperature */
   status = viGetAttribute(pDev->nmRegInstr,VI_ATTR_PXI_MEM_BASE_BAR1,&busAddr);
   if(status < VI_SUCCESS)
   {
      return SCGT_DRIVER_ERROR;
   }
   
   /* Set read/write offset in PXI address space */
   offset = 0;
    
   /* Map the device memory */
   status = viMapAddressEx(pDev->nmRegInstr,VI_PXI_BAR1_SPACE, offset,
                        memBarSize, VI_FALSE, VI_NULL, &pDev->nmRegMappedAddr);
   if(status < VI_SUCCESS)
   {
       return SCGT_DRIVER_ERROR;
   }
   pDev->nmRegPtr = pDev->nmRegMappedAddr;
   
   return SCGT_SUCCESS;

}
#endif


extern char * FILE_REV_KSYS_C;
extern char * FILE_REV_GTCORE_C;
extern char * FILE_REV_GTCOREXFER_C;
/**************************************************************************/
/* scgtInitDriverRev()                                                    */
/*     Initialize driver revision string.  This is returned to user via   */
/*     GetDeviceInfo ioctl.                                               */
/**************************************************************************/
void scgtInitDriverRev( void )
{
    char coreFiles[60] = {"                                        "};
    char driverFiles[20]={"                    "};
    char sysFiles[20]={"                    "};

    sprintf(driverFiles, "%s%s%s",
            FILE_REV_SCGT_C, FILE_REV_SCGT_H, FILE_REV_SCGTDRV_H);
            
    sprintf(sysFiles, "%s%s%s",
            FILE_REV_KSYS_C, FILE_REV_KSYS_H, FILE_REV_SYSTYPES_H);

    sprintf(coreFiles, "%s%s%s%s%s%s",
            FILE_REV_GTCORE_C, FILE_REV_GTCOREXFER_C,  FILE_REV_GTCORE_H,
            FILE_REV_GTCOREIOCTL_H, FILE_REV_GTCORETYPES_H, FILE_REV_GTUCORE_H);

    sprintf(driverRevStr, "%s-%s:%s:%s", SCGT_DRIVER_VERSION, driverFiles, 
            sysFiles, coreFiles);
}


/**************************************************************************/
/*  function:     scgtDriverOpen                                          */
/*  description:  Find GT card and open handle to device                  */
/**************************************************************************/
DLLEXPORT scgtViData* scgtDriverOpen(uint32 unitNum)
{
   ViStatus status;
   ViSession instr;
   scgtViData* viData;
   scgtDevice * pDev;
   uint32 ret;
   uint16 slot,busNum;
   char slotPath[256];
   
    /* has device been previously opened */
   pDev = scgtGetDevicePtrFromUnitNum(unitNum);
   if( pDev->viData == VI_NULL )
   {
      /* allocate buffer to store Vi data */
      viData = (scgtViData*) malloc(sizeof(scgtViData));
      if(viData == VI_NULL)
      {
         return VI_NULL;
      }
      /* find card. unitNum is used to specify which card in case multiple
      cards are installed.  The first card has unitNum set to 0,
      second card has unitNum set to 1, etc. */
      instr = scgtFindGtCard( unitNum, viData);
      if(instr == VI_NULL)
      {
         free(viData);
         return VI_NULL;
      }
      /* found GT card */
      pDev->viData = viData;
      

      status = viGetAttribute(pDev->viData->instr,VI_ATTR_PXI_BUS_NUM,&busNum);
      
      status = viGetAttribute(pDev->viData->instr,VI_ATTR_SLOT,&slot);

      status = viGetAttribute(pDev->viData->instr,VI_ATTR_PXI_SLOTPATH,slotPath);
      
      if(slot > 18)
      {
         sprintf(pDev->boardLocationStr, "bus %d slot Path:", busNum);
         strncat(pDev->boardLocationStr,slotPath,128-strlen(pDev->boardLocationStr));
      }
      else
          sprintf(pDev->boardLocationStr, "bus %d slot %d", busNum, slot);
      
#ifdef MAP_REGS
      /* create memory mapped pointers to GT registers. */
      scgtLocalMapRegisters(pDev);
#endif
      
       ret = scgtInitDmaTools(pDev);  /* setup dma processinbg tools */
      if(ret != SCGT_SUCCESS)
      {
         free(viData);
         return VI_NULL;
      }
      
      scgtInitGetIntrTimer(pDev); /* setup semaphore used by  scgtGetInterupt function */

      status = viInstallHandler(pDev->viData->instr,VI_EVENT_PXI_INTR,
                                scgtViEventHandler,pDev);
      if(status != VI_SUCCESS)
      {
         return VI_NULL;
      }
      status = viEnableEvent(pDev->viData->instr,VI_EVENT_PXI_INTR,VI_HNDLR,VI_NULL);
      //status = viEnableEvent(pDev->viData->instr,VI_EVENT_PXI_INTR,VI_QUEUE,VI_NULL);
      if(status < VI_SUCCESS)
      {
         status = viUninstallHandler(pDev->viData->instr,VI_EVENT_PXI_INTR,
                                  scgtViEventHandler,pDev);
         return VI_NULL;
      }

      /* gtCoreInitDevice writes to hardware register arming interrupts */
         
      //ev->wexch.exchQ.compSem
      /* initialize new Gt Device structure */
      gtcoreInit(pDev);
      
      scgtInitDriverRev();
      
   }
   else
      viData = pDev->viData;
   
   
   //DebugPrintf("Opened SCGT device %d\n",viData->unitNum);
   //printf("Opened SCGT device %d\n",viData->unitNum);
   
   /*
   printf("pDev->wexch.trPhysical=0x%x ",(uint32)pDev->wexch.trPhysical);
   printf("pDev->rexch.trPhysical=0x%x \n",(uint32)pDev->rexch.trPhysical);
    {
      ViUInt32 value;

      // verify PCI address assinged to transaction queues matches value 
      // in control register 
      viIn32(viData->instr,VI_PXI_BAR0_SPACE,0xc0,&value);
      if(value != (ViUInt32) pDev->wexch.trPhysical)
         printf(" pDev->wexch.trPhysical:%x != bar0[0xc0]:%x\n",
               (ViUInt32)pDev->wexch.trPhysical,value);
      
       viIn32(viData->instr,VI_PXI_BAR0_SPACE,0xd0,&value);
       if(value != (ViUInt32) pDev->rexch.trPhysical)
         printf(" pDev->rexch.trPhysical:%x != bar0[0xd0]:%x\n",
               (ViUInt32)pDev->rexch.trPhysical,value);
   }
    */
   
   return viData;
}

/**************************************************************************/
/*  function:     scgtDriverClose                                         */
/*  description:  close handle to GT device                               */
/**************************************************************************/
DLLEXPORT uint32 scgtDriverClose(scgtViData *viData)
{
   ViStatus status;
   scgtDevice* pDev;
   
   
   //DebugPrintf("scgtDriverClose\n");
    //printf("scgtDriverClose\n");
   
   pDev = scgtGetDevicePtrFromViSession(viData->instr);
   if(pDev == VI_NULL)
   {
      return SCGT_DRIVER_ERROR;
   }
   
   status = viUninstallHandler(pDev->viData->instr,VI_EVENT_PXI_INTR,
                                  scgtViEventHandler,pDev);
   
   status = viDisableEvent(pDev->viData->instr,VI_EVENT_PXI_INTR,VI_HNDLR);
   
   scgtDestroyGetIntrTimer(pDev);
   
   scgtDestroyDmaTools(pDev);
   
   gtcoreDestroy(pDev);
#ifdef MAP_REGS
   viClose(pDev->nmRegInstr);
   viClose(pDev->cRegInstr);
#endif
   viClose(viData->instr);
   free(viData);
   pDev->viData = VI_NULL;
   return SCGT_SUCCESS;
}

/**************************************************************************/
/*  function:     scgtLocalMapMem                                         */
/*  description:  Map Gt device memory for PIO accesses                   */
/**************************************************************************/
uint32 scgtLocalMapMem( scgtDevice* dev, scgtMemMapInfo * mmi)
{
   ViBusSize memBarSize;
   ViBusAddress offset;
   ViBusAddress busAddr;
   ViStatus status;
   static ViAddr mem_mapped_address;
   scgtViData *viData;
   ViUInt16 access;

   viData = dev->viData;
   status = 0;

   status = viGetAttribute(viData->instr,VI_ATTR_PXI_MEM_SIZE_BAR2,&memBarSize);
   if((memBarSize < 128*1024*1024) || (status < VI_SUCCESS))
   {
       /* memory aperature should be 128MB in size */
      return SCGT_DRIVER_ERROR;
   }

   status = viGetAttribute(viData->instr,VI_ATTR_PXI_MEM_BASE_BAR2,&busAddr);
   if(status < VI_SUCCESS)
   {
      return SCGT_DRIVER_ERROR;
   }
   
   /* Read offset in PXI bar2 address space */
   offset = 0;
    
   /* Map the device memory */
   status = viMapAddressEx(viData->instr,VI_PXI_BAR2_SPACE,offset,memBarSize, 
                        VI_FALSE,VI_NULL,&mem_mapped_address);
   if(status < VI_SUCCESS)
   {
      mmi->memVirtAddr=0;
       return SCGT_DRIVER_ERROR;
   }
   
   status = viGetAttribute(viData->instr, VI_ATTR_WIN_ACCESS, &access);
    if (access != VI_DEREF_ADDR)
   {
      dev->winAccessMode = access;
      mmi->memVirtAddr=0;
       return SCGT_DRIVER_ERROR;
   }

   mmi->memSize = memBarSize;
   mmi->memVirtAddr = (uint64) mem_mapped_address;
   mmi->memPhysAddr = busAddr;
   dev->memPhysAddr = busAddr;
   dev->memVirtAddr = (uint64) mem_mapped_address;
   
   return SCGT_SUCCESS;
}

/**************************************************************************/
/*  function:     scgtLocalUnMapMem                                       */
/*  description:  Unmap Gt device memory for PIO accesses                 */
/**************************************************************************/
uint32 scgtLocalUnMapMem( scgtViData *viData, scgtMemMapInfo * mmi)
{
   ViStatus status;
   scgtDevice * pDev;
   
   status = viUnmapAddress(viData->instr);
   if(status < VI_SUCCESS)
      return SCGT_DRIVER_ERROR;
   mmi->memSize = 0;
   mmi->memVirtAddr = (uint64) VI_NULL;
   mmi->memPhysAddr = 0;
   
   pDev = scgtGetDevicePtrFromViSession(viData->instr);
   pDev->memVirtAddr = VI_NULL;
   pDev->memPhysAddr = 0;
   
   return SCGT_SUCCESS;
}

/**************************************************************************/
/*  function:     scgtIoctlGetDeviceInfo                                  */
/*  description:  Fill out devInfo stuctiure with information about the   */
/*                Gt card configuration and software revision history     */
/**************************************************************************/
uint32 scgtIoctlGetDeviceInfo(scgtDevice *dev, scgtDeviceInfo *devInfo)
{    
    devInfo->reserved = gtcoreGetDeviceInfo(dev, devInfo);
    
    strncpy(devInfo->driverRevisionStr, driverRevStr, 128);
    strncpy(devInfo->boardLocationStr, dev->boardLocationStr, 128);

    return SCGT_SUCCESS;
}


/**************************************************************************/
/*  function:     scgtIoctlGetStats                                       */
/*  description:  Fill out stats stuctiure with information gathered by   */
/*                software concerning it performance                      */
/**************************************************************************/
int scgtIoctlGetStats(scgtDevice *dev, scgtStats *stats)
{
    /* update any stats that need to be updated */
    dev->stats[SCGT_STATS_GET_INTR_WAIT_CNT] = dev->getIntrWaitCount;
    /* do the copy */
    return gtcoreGetStats(dev, stats);
}

/**************************************************************************/
/*  function:     scgtIoctlGetIntr                                        */
/*  description:  Fill out gibuffer stucture with interrupt information   */
/*                that has been stored in the interrupt queue             */
/**************************************************************************/
int scgtIoctlGetIntr(scgtDevice *dev, scgtGetIntrBuf *gibuf)
{   
   uint32 ret;
   
   dev->getIntrWaitCount++;
    ret = gtcoreGetIntr(dev, gibuf);
    if (ret != SCGT_TIMEOUT)
   {
      if(dev->getIntrWaitCount>0)
         dev->getIntrWaitCount--;
      return ret;
   }
   
   ret = ksysSemBTakeWithTimeout(&dev->getIntrSem,gibuf->timeout);
   if( ret == SCGT_TIMEOUT)
   {
      if(dev->getIntrWaitCount>0)
         dev->getIntrWaitCount--;
      return SCGT_TIMEOUT;
   }
   
   ret = gtcoreGetIntr(dev, gibuf);
   if(dev->getIntrWaitCount>0)
      dev->getIntrWaitCount--;
   return ret;
   
   
}

/**************************************************************************/
/* function : scgtInitDmaTools                                            */
/* description: alocate semaphores and allcoate memory for use in DMA     */
/**************************************************************************/
int scgtInitDmaTools(scgtDevice *dev)
{
   ViStatus status;
   /* create semaphores */
   ksysSemSCreate(&dev->writeTools.entrySem_1);
   ksysSemSCreate(&dev->writeTools.entrySem_2);
   
   ksysSemSCreate(&dev->readTools.entrySem_1);
   ksysSemSCreate(&dev->readTools.entrySem_2);

#ifdef USE_WIN_CALLS
   /* release all seampores if needed take semaphores */
   ksysSemSGive(&dev->writeTools.entrySem_1);
   ksysSemSGive(&dev->writeTools.entrySem_2);
   ksysSemSGive(&dev->readTools.entrySem_1);
   ksysSemSGive(&dev->readTools.entrySem_2);
   
#endif
    
   /* allocate two blocks of memory to use in DMA transfers */
   
   /* Write ----------------------------------------------------------------*/
   
   status = viOpenDefaultRM(&dev->writeTools.dmaDefaultRM);
   if(status < VI_SUCCESS) return SCGT_INSUFFICIENT_RESOURCES;
   
   status = viOpen(dev->writeTools.dmaDefaultRM,"PXI0::MEMACC",VI_NULL,VI_NULL,
                   &dev->writeTools.dmaInstr);
   if(status != VI_SUCCESS) return SCGT_DRIVER_ERROR;
   
   status = viMemAllocEx(dev->writeTools.dmaInstr,SCGT_MAX_CHUNK_SIZE+16,        
                         &dev->writeTools.dmaBufBusAddr);                       
   if(status != VI_SUCCESS) return SCGT_INSUFFICIENT_RESOURCES;                  
                                                                                 
   status = viMapAddressEx(dev->writeTools.dmaInstr,VI_PXI_ALLOC_SPACE,          
                          dev->writeTools.dmaBufBusAddr,SCGT_MAX_CHUNK_SIZE+16, 
                     VI_FALSE,VI_NULL,&dev->writeTools.dmaMappedAddr);     
   if(status != VI_SUCCESS) return SCGT_INSUFFICIENT_RESOURCES;                  
   
   dev->writeTools.pending =0;
   
   /* Read ----------------------------------------------------------------*/
   
   status = viOpenDefaultRM(&dev->readTools.dmaDefaultRM);    
   if(status < VI_SUCCESS) return SCGT_INSUFFICIENT_RESOURCES;
   
   status = viOpen(dev->readTools.dmaDefaultRM,"PXI0::MEMACC",VI_NULL,VI_NULL,
                      &dev->readTools.dmaInstr);
   if(status != VI_SUCCESS) return SCGT_DRIVER_ERROR;
    
   status = viMemAllocEx(dev->readTools.dmaInstr,SCGT_MAX_CHUNK_SIZE+16,
                         &dev->readTools.dmaBufBusAddr);
   if(status != VI_SUCCESS) return SCGT_INSUFFICIENT_RESOURCES;
   
   status = viMapAddressEx(dev->readTools.dmaInstr,VI_PXI_ALLOC_SPACE,
                          dev->readTools.dmaBufBusAddr,SCGT_MAX_CHUNK_SIZE+16,
                     VI_FALSE,VI_NULL,&dev->readTools.dmaMappedAddr);
   if(status != VI_SUCCESS) return SCGT_INSUFFICIENT_RESOURCES;
   
   dev->readTools.pending =0;
   
   /*
   printf("DMA buffers at PCI addr w:0x%x and r:0x%x\n",
         (ViUInt32)dev->writeTools.dmaBufBusAddr,
         (ViUInt32)dev->readTools.dmaBufBusAddr);
    */
   
   return SCGT_SUCCESS;
}

/************************************************************************/
/* scgtDestroyDmaTools                                                  */
/* Free resource allocated by the scgtInitDmaTools function             */
/************************************************************************/
void scgtDestroyDmaTools(scgtDevice *dev)
{
   ksysSemSDestroy(&dev->writeTools.entrySem_1);
   ksysSemSDestroy(&dev->writeTools.entrySem_2);
   ksysSemSDestroy(&dev->readTools.entrySem_1);
   ksysSemSDestroy(&dev->readTools.entrySem_2);
   
   
   viUnmapAddress(dev->writeTools.dmaInstr);
   viUnmapAddress(dev->readTools.dmaInstr);
   
   viMemFreeEx(dev->writeTools.dmaInstr,dev->writeTools.dmaBufBusAddr);
   viMemFreeEx(dev->readTools.dmaInstr,dev->readTools.dmaBufBusAddr);
   
   viClose(dev->writeTools.dmaInstr);
   viClose(dev->readTools.dmaInstr);
   
   viClose(dev->writeTools.dmaDefaultRM);
   viClose(dev->readTools.dmaDefaultRM);
}

/**************************************************************************/
/* scgtXferChunk()                                                        */
/*     Reads or writes chunkSize bytes of the specified buffer.           */
/*     bytesTransferred is filled with the number of bytes                */
/*     transferred.  bytesTransferred should always be == to chunkSize    */
/*     unless an error is returned.                                       */
/**************************************************************************/
uint32 scgtXferChunk(scgtDevice *dev,  uint32 gtMemoryOffset, uint32  *pBuf, 
                     uint32 chunkSize, uint8 lastTransfer,    uint32 flags,
                     scgtInterrupt *intr, uint8  direction,
                scgtDMATools *tools, uint32 * bytesTransferred,
                ksysSemS ** semToGive)
{
    uint32 ret;
    gtcoreExch *exch;
   uint64 physAddr;
   ViStatus status;
   uint32 *chainEntry;
   uint32 retVal;

   volatile unsigned long numberOfBytesTransfered;
   
   numberOfBytesTransfered = 0x12345678;
   
    physAddr = 0;
    
   // get head of read or write exchage queue and
   // set state to GTCORE_EXCH_NOT_DONE
    exch = gtcoreGetExchange(dev, direction); 
    
    exch->bytesToTransfer = chunkSize;
    exch->gtMemoryOffset = gtMemoryOffset;
    exch->flags = flags;
    
    if (lastTransfer)     // setup intr for last transfer 
        exch->intr = intr;
    else
        exch->intr = NULL;


    if (!(flags & SCGT_RW_DMA_PHYS_ADDR))  // not physical address 
    {
      // ** getPointer to DMA address space **
      if( direction == GTCORE_WRITE)
      {
          // ** copy from user buffer to dma buffer at know PCI address **
          viMoveOut32Ex(tools->dmaInstr,VI_PXI_ALLOC_SPACE,
                      tools->dmaBufBusAddr,(chunkSize>>2),pBuf);
      }
      physAddr = (uint64) ((uintpsize) tools->dmaBufBusAddr);
    }
    else
    {
        // physical address supplied 
        physAddr = (uint64) ((uintpsize) pBuf);
    }

    chainEntry = (uint32 *) exch->sgList[0];
    // build chain 
    chainEntry[GTCORE_CE_TNS_CSR] = (chunkSize >> 2) | GTCORE_CE_LST;
    chainEntry[GTCORE_CE_BUF_ADD32] = (uint32) (physAddr);
    chainEntry[GTCORE_CE_BUF_ADD64] = (uint32) (physAddr >> 32);

    ksysCacheFlush(NULL, chainEntry, GTCORE_CE_SIZE);     
   
#ifdef DMA_DEBUG
   // ******* DLC debug Statements ******************************************
   {
     ViUInt32 TransQueueAddr32; 
     ViUInt32 TransQueueAddr64; 
     ViUInt32 TransQueueControl;
     ViUInt32 TransactionLenght;
   
     if (direction == GTCORE_WRITE)                                                                   
     {                                                                                                
       viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xc0,&TransQueueAddr32);                          
       viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xc4,&TransQueueAddr64);                          
       viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xc8,&TransQueueControl);                         
       viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xcc,&TransactionLenght);                         
       printf("DMA Write %x TCE@%x, ",exch->bytesToTransfer,TransQueueAddr32);
     }                                                                                                
     else                                                                                             
     {                                                                                                
       viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xd0,&TransQueueAddr32);                          
       viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xd4,&TransQueueAddr64);                          
       viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xd8,&TransQueueControl);                         
       viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xdc,&TransactionLenght);                         
       printf("DMA Read %x TCE@%x, ",exch->bytesToTransfer,TransQueueAddr32);                        
     }                                                                                                
     printf("CE@%x ",exch->sgListPhysAddr);
   }
#endif
   // ***********************************************************************
   
   
    // do transfer 
    gtcoreTransfer(dev, exch, direction);  /* fill out exchangeManager->tqe 
                                    entry and write to  
                                   GTCORE_R_TQ_CTL_TC0 or
                                   GTCORE_R_TQ_CTL_TC1 register   */
   // gtVisaTransfer(dev, exch, direction);
    
    if (lastTransfer)
    {
        ksysSemSTake(&tools->entrySem_2);
        
        tools->pending = 1;
        
        /// swap the tool resources so the next thread can begin 
        
        // * let the next thread enter 
        ksysSemSGive(&tools->entrySem_1);
        *semToGive = (&tools->entrySem_2);  // ** swap the exit semaphore to sem 2 **
    }
    else if (tools->pending)
    {
        ksysSemSTake(&tools->entrySem_2);
        ksysSemSGive(&tools->entrySem_2);
    }

    // ** wait until its done. ** 
   retVal = ksysSemBTakeWithTimeout(&exch->compSem, SCGT_TIMEOUT_TIME);
    if (retVal != SCGT_SUCCESS)
    {
        // ** hardware did not complete transfer! **
        ret = SCGT_TIMEOUT;  
        gtcoreCancelTransfer(dev, exch, direction);
    }
    else
    {
        ret = exch->status;
    }
            
   
    *bytesTransferred = exch->bytesTransferred;
   
   if ((*bytesTransferred != chunkSize) && (ret == SCGT_SUCCESS))
   {                                                                     
      DebugPrintf("*bytesTransferred:%d != chunkSize:%d\n",*bytesTransferred,chunkSize);
       ret = SCGT_HARDWARE_ERROR;                                        
   }                                                                     
   
    tools->pending = 0;
    
    if (!(flags & SCGT_RW_DMA_PHYS_ADDR))  // * not physical address 
    {    
      if( direction == GTCORE_READ)
       {
           // **** copy from DMA buffer to user buffer at known PCI address ****
           status = viMoveIn32Ex(tools->dmaInstr,VI_PXI_ALLOC_SPACE,tools->dmaBufBusAddr,chunkSize>>2,pBuf);
          if(status != VI_SUCCESS)
          {
             return SCGT_DRIVER_ERROR;
          }
       }
        // nothing needed to unmap 
    }

#ifdef DMA_DEBUG
   // DLC Debuging statement ------------------------------------------------
   {
      uint32 TransactionLenght;
       if (direction == GTCORE_WRITE)                                                                   
         viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xcc,&TransactionLenght);
       else
         viIn32(dev->viData->instr,VI_PXI_BAR0_SPACE,0xdc,&TransactionLenght);
       printf("DMA over. TranLen=0x%x\n",TransactionLenght);
   }
#endif
   
   return ret;
}


/**************************************************************************/
/* scgtIoctlXfer()                                                        */
/*     process write or read transfer                                     */
/**************************************************************************/
uint32 scgtIoctlXfer(scgtDevice *dev, 
                            scgtXfer *xfer,
                            scgtInterrupt *intr,
                            uint8 direction)
{
    uint32 gtMemoryOffset;
    uint32 bytesToTransfer;
    uint32 bytesTransferred;
    uint32 chunkSize;
    uint32 flags;
    uint8  lastTransfer;
    uint32 ret = SCGT_SUCCESS;
    uint8  *pBuf;
    scgtDMATools *dmaTools;
    ksysSemS *semToGive;
    
    
    pBuf = UINT64_TO_PTR(uint8, xfer->pDataBuffer);
    bytesToTransfer = xfer->bytesToTransfer;
    gtMemoryOffset = xfer->gtMemoryOffset;
    
    if (bytesToTransfer == 0 || pBuf == NULL)
        return gtcoreSendIntr(dev, intr);
    
    flags = xfer->flags;

    dmaTools = (direction == GTCORE_WRITE)? &dev->writeTools : &dev->readTools;

    ksysSemSTake(&dmaTools->entrySem_1);
    semToGive = &dmaTools->entrySem_1;
    
    while (bytesToTransfer > 0 && ret == SCGT_SUCCESS)
    {
        /* calculate chunk size */
        chunkSize = (bytesToTransfer >= SCGT_MAX_CHUNK_SIZE)? SCGT_MAX_CHUNK_SIZE : bytesToTransfer;
        lastTransfer = (chunkSize == bytesToTransfer)? 1 : 0;
    
        ret = scgtXferChunk(dev, gtMemoryOffset, (uint32*)pBuf, chunkSize, lastTransfer,
                            flags, intr, direction, dmaTools, &bytesTransferred, 
                            &semToGive);
        bytesToTransfer -= bytesTransferred;
        pBuf += bytesTransferred;
        gtMemoryOffset += bytesTransferred;
    }
    
    ksysSemSGive(semToGive);
    
    xfer->bytesTransferred = xfer->bytesToTransfer - bytesToTransfer;
    
    return ret;
}



/************************************************************************/
/* scgtInitGetIntrTimer()                                               */
/*     initialize GetInterrupt timer and semaphore                      */
/*     this must be called before scgtIoctlGetIntr() is called          */
/************************************************************************/
 
void scgtInitGetIntrTimer(scgtDevice *dev)
{
#ifdef USE_VI_LOCK 
    ksysSemBCreate(&dev->getIntrSem);
#elif defined USE_CMT_CALLS
   sprintf(dev->getIntrSem.lockName,"GtIntrLock");
   //dev->getIntrSem.options = OPT_TL_PROCESS_EVENTS_WHILE_WAITING;
   dev->getIntrSem.options = 0;
   ksysSemBCreate(&dev->getIntrSem);
#elif defined USE_WIN_CALLS
    ksysSemBCreate(&dev->getIntrSem);
#endif
    dev->getIntrWaitCount = 0;
}


/************************************************************************/
/* scgtDestroyGetIntrTimer(scgtDevice *dev)                            */ 
/************************************************************************/
void scgtDestroyGetIntrTimer(scgtDevice *dev)
{
    ksysSemBDestroy(&dev->getIntrSem);
}


/************************************************************************/
/* gtVisaHandleInterrupt()                                              */
/*     returns 1 if handled                                             */
/*             2 if handled and you should call gtcoreCompleteDMA()     */
/*             3 if interrupt has been added to the queue.              */
/*             0 if not our board                                       */
/************************************************************************/
 
uint32 gtVisaHandleInterrupt(scgtDevice *dev,uint32 intCSR)
{
    uint32 interruptType;
    uint32 hwConsumer;
    uint32 i;
    uint32 compHeadIndex;
    uint32 exchState;

    interruptType = 0;
    //intCSR = scgtReadCReg(dev, GTCORE_R_INT_CSR);

    while (intCSR & 0xFF)
    {   
        // ** clear interrupt  **
        scgtWriteCReg(dev, GTCORE_R_INT_CSR, intCSR);
        
        // * write interrupt **
        if (intCSR & GTCORE_R_TC0_INT)
        {
            hwConsumer = (scgtReadCReg(dev, GTCORE_R_TQ_CTL_TC0) & 0x1F00) >> 8;
            
            // ** transactions completed are from SW's tail index  
            // **   up to HW's consumer index 
               
            for (i = dev->wexch.tailIndex; i != hwConsumer; 
                 i = (i + 1) % GTCORE_EXCH_CNT)
            {
                // * Do ONLY exchanges that aren't marked as DONE 
                // * An exchange could already be set to EXCH_DONE
                // *  due to timeout of semaphore. 
            
                exchState = dev->wexch.exchQ[i].state;
                compHeadIndex = dev->completedHeadIndex;
            
                if (exchState != GTCORE_EXCH_DONE)
                {
                    // * add the ith exchange to the completion queue 
                    // * for gtcoreCompleteDMA 
                    dev->completedExchQ[compHeadIndex] = &dev->wexch.exchQ[i];
                    dev->completedHeadIndex = (compHeadIndex + 1) % (2 * GTCORE_EXCH_CNT); 
                }
                dev->wexch.tailIndex = (i + 1) % GTCORE_EXCH_CNT;
            }
            
            interruptType |= GTCORE_ISR_DMA;
            dev->stats[SCGT_STATS_TC0_INTRS]++;
        }
        
        // * read interrupt (same was write but for TC1) 
        if (intCSR & GTCORE_R_TC1_INT)
        {
            hwConsumer = (scgtReadCReg(dev, GTCORE_R_TQ_CTL_TC1) & 0x1F00) >> 8;
               
            for (i = dev->rexch.tailIndex; i != hwConsumer; 
                 i = (i + 1) % GTCORE_EXCH_CNT)
            {            
                exchState = dev->rexch.exchQ[i].state;
                compHeadIndex = dev->completedHeadIndex;
            
                if (exchState != GTCORE_EXCH_DONE)
                {
                    // * add the ith exchange to the completion queue 
                    // * for gtcoreCompleteDMA 
                    dev->completedExchQ[compHeadIndex] = &dev->rexch.exchQ[i];
                    dev->completedHeadIndex = (compHeadIndex + 1) % (2 * GTCORE_EXCH_CNT); 
                }
                dev->rexch.tailIndex = (i + 1) % GTCORE_EXCH_CNT;
            }
            
            interruptType |= GTCORE_ISR_DMA;
            dev->stats[SCGT_STATS_TC1_INTRS]++;
        }

        // ** received network interrupt **
        if (intCSR & GTCORE_R_RX_NET_INT)
        {
            gtcoreEnqueueNetIntrs(dev);
            interruptType |= GTCORE_ISR_QUEUED_INTR;
        }
        
        // ** handle other less likely interrupts **
        if (intCSR & 0xFF & ~(GTCORE_R_TC0_INT | GTCORE_R_TC1_INT | GTCORE_R_RX_NET_INT))
        {
            interruptType |= gtcoreHandleInterrupt2(dev, intCSR);
        }
        
        dev->stats[SCGT_STATS_INTRS]++;
        
        intCSR = scgtReadCReg(dev, GTCORE_R_INT_CSR);  // * next interrupt *
    }
    
    if (interruptType)
        dev->stats[SCGT_STATS_ISR]++;
    
    return interruptType;
}


/**************************************************************************/
/* function:     scgtViEventHandler                                       */
/* description:  Interrupt event callback function.                       */
/**************************************************************************/
ViStatus _VI_FUNCH  scgtViEventHandler( ViSession vi, ViEventType eventType, 
                                        ViEvent context, ViAddr userHandle )
{
   scgtDevice* dev;
   uint32 intRet;
   ViStatus status;
   uint32 intCSR;

   /* get intCsr value Read by the NI-VISA driver*/
   status = viGetAttribute(context,VI_ATTR_PXI_RECV_INTR_DATA,&intCSR);
   if(status < VI_SUCCESS)
      return 0;
   
   dev = (scgtDevice*) userHandle;
   intRet = gtVisaHandleInterrupt(dev, intCSR);
   if(intRet == 0)
   {
      return 0; /* not our interrupt */
   }
   if(intRet & GTCORE_ISR_DMA)
   {
      dev->stats[SCGT_STATS_DPC_DMA]++;
      gtcoreCompleteDMA(dev);
   }
   if( intRet & GTCORE_ISR_QUEUED_INTR)
   {
      int count;
       count = dev->getIntrWaitCount;
       dev->getIntrWaitCount = 0;
       if (count > 0) /* somebody waiting */
       {
           for (; count > 0; count--)
               ksysSemBGive(&dev->getIntrSem);
      }
   }
   return 1;
}


/**************************************************************************/
/*  function:     scgtVisaIoctHandler                                     */
/*  description:  Process scgt IOCTL requests                             */
/**************************************************************************/
DLLEXPORT uint32 scgtVisaIoctHandler( scgtViData * viData, ViUInt32 ioctlCode,
                                     void * bufPtr, int busSize)
{
   uint32 ret;
   scgtDevice *dev;

   /* we only use one of the following per ioctl call.. The union
       will save some stack. */
    union
    {
        scgtRegister * reg;
        scgtMemMapInfo * mmi;
        scgtDeviceInfo * deviceInfo;
        scgtState * state;
        scgtStats * stats;
        scgtInterrupt * intr;   /* debugging */
      scgtXfer *xfer;
    } u;
    
   ret = SCGT_SUCCESS;

   dev = scgtGetDevicePtrFromViSession(viData->instr);
   if(dev == VI_NULL)
   {
      return SCGT_DRIVER_ERROR;
   }
   
   u.reg = (scgtRegister *) bufPtr;
   
   switch( ioctlCode)
   {
      case SCGT_IOCTL_MAP_MEM:
         /* Memory map the GT device memory and provide pointer
            for PIO operations*/
            ret =scgtLocalMapMem( dev, u.mmi);
         break;

      case SCGT_IOCTL_UNMAP_MEM:
         /* release the GT memory mapped*/
         ret = scgtLocalUnMapMem(viData, u.mmi);
         break;

      case SCGT_IOCTL_WRITE:     
         /* perform a DMA operation */
         {
            scgtInterrupt * pInterrupt;
            pInterrupt = UINT64_TO_PTR(scgtInterrupt,u.xfer->pInterrupt);
                ret = scgtIoctlXfer(dev, u.xfer, pInterrupt, GTCORE_WRITE);
         }
            break;
            
        case SCGT_IOCTL_READ:
         /* perform a DMA read operation */
         ret = scgtIoctlXfer(dev, u.xfer, NULL, GTCORE_READ);
            break;
      
      case SCGT_IOCTL_READ_CR:
         /* Read from the ccontrol/status register address space */
         if (u.reg->offset < GTCORE_REGISTER_SIZE)
            {
                u.reg->val = scgtReadCReg(dev, u.reg->offset);
                ret = SCGT_SUCCESS;
            }
            else
            {
                ret = SCGT_BAD_PARAMETER;
            }
            break;
         

      case SCGT_IOCTL_WRITE_CR:
         /* Read to the ccontrol/status register address space */
         if (u.reg->offset < GTCORE_REGISTER_SIZE)
            {
                scgtWriteCReg(dev, u.reg->offset, u.reg->val);
                ret = SCGT_SUCCESS;
            }
            else
            {
                ret = SCGT_BAD_PARAMETER;
            }
            break;

         
      case SCGT_IOCTL_MEM_MAP_INFO:
         /* return information about the GT memorys configuration */
         u.mmi->memPhysAddr = dev->memPhysAddr;
            u.mmi->memVirtAddr = dev->memVirtAddr;
            u.mmi->memSize = dev->memSize;
          break;

      case SCGT_IOCTL_GET_DEVICE_INFO:
         /* get information on the GT cards status and software configuration */
         ret = scgtIoctlGetDeviceInfo(dev, u.deviceInfo);
         break;

      case SCGT_IOCTL_GET_STATE:
         /* get the state information about the Gt card */
         ret = gtcoreGetState(dev, u.state->stateID, &(u.state->val));
         break;

      case SCGT_IOCTL_SET_STATE:
         /* change the state configuration of the Gt card */
         ret = gtcoreSetState(dev, u.state->stateID, u.state->val);
         break;

      case SCGT_IOCTL_READ_NMR:
         /* Read from the Network management register address space */

         if (u.reg->offset < GTCORE_NM_REGISTER_SIZE)
            {
                u.reg->val = scgtReadNMReg(dev, u.reg->offset);
                ret = SCGT_SUCCESS;
            }
            else
            {
                ret = SCGT_BAD_PARAMETER;
            }
            break;

      case SCGT_IOCTL_WRITE_NMR:
         /* Write to the Network management register address space */
         if (u.reg->offset < GTCORE_NM_REGISTER_SIZE)
            {
                scgtWriteNMReg(dev, u.reg->offset, u.reg->val);
                ret = SCGT_SUCCESS;
            }
            else
            {
                ret = SCGT_BAD_PARAMETER;
            }
         break;

      case SCGT_IOCTL_GET_STATS:
         /* get basic statistical information about the software */
         ret = scgtIoctlGetStats(dev, u.stats);
         break;

      case SCGT_IOCTL_GET_INTR:
         /* get any network interrupts fromteh network interrupt queue */
         ret = scgtIoctlGetIntr(dev, (scgtGetIntrBuf*) bufPtr);
         break;

      case SCGT_IOCTL_PUT_INTR:
         /* place an entry in the interrupt queue for debugging purposes */
         gtcorePutIntr(dev, u.intr);
         break;
         
      default:
         ret = SCGT_CALL_UNSUPPORTED;
         break;
   }
   return ret;
}



































