#if !defined NIVISA_PXI
#define NIVISA_PXI
#endif

#include <visa.h>
#include <ansi_c.h>

#include <cvirte.h>

#include "scgtapi.h"

//#include "utility.h"

#include <windows.h>

const int MAX_BUF_SIZE = 1024*1024*4;

const int MyNodeId = 50;


void CVIFUNC_C RTmain ( void )
{
	scgtHandle gtHandle;
	uint32 unitNum;
	uint32* memPtr;
	uint32 ret;
	uint32 gtMemoryOffset;
	uint32 bytesToTransfer;
	uint32 flags;
	uint32 bytesTransfered;
	uint32 *dataBuffer;
	scgtDeviceInfo gtDeviceInfo;
	
	uint32 stateId,value;
	int i;
	
	
	scgtInterrupt gtInterrupt;
	scgtIntrHandle interruptHandle;
	scgtInterrupt interruptBuffer[30];
	uint32 numInterrupts,timeout,numInterruptRet;
	
	
	ViStatus status;
	ViSession defaultRM, instr;
	ViAddr mappedAddr;
	ViUInt32 transferSize;
	ViBusAddress64 bufBusAddr;
	
	
	if (InitCVIRTE (0, 0, 0) == 0)
		return; /* out of memory */
	
	dataBuffer = (uint32* ) malloc (MAX_BUF_SIZE );
	if(dataBuffer == NULL)
		return;
	
	unitNum = 0;
	ret = scgtOpen(unitNum,&gtHandle);
	if(ret != SCGT_SUCCESS)
	{
		printf("scgtOpen returned error code %d. %s\n",ret,scgtGetErrStr(ret));
		free(dataBuffer);
		CloseCVIRTE ();
		return;
	}
	
	memPtr = (uint32*) scgtMapMem(&gtHandle);
	if(memPtr == NULL)
	{
		printf("scgtMamMemory returned null\n");
		goto ShutDown;
	}
	
	ret = scgtGetDeviceInfo(&gtHandle,&gtDeviceInfo);                                   
	if(ret != SCGT_SUCCESS)                                                             
	{                                                                                   
		printf("scgtgetDeviceInfo returned error code %d. %s\n",ret,scgtGetErrStr(ret));
	}                                                                                   
	else                                                                                
	{                                                                                   
		printf("DrvRevStr:%s ",gtDeviceInfo.driverRevisionStr);                         
		printf("BrdLoctStr:%s \n",gtDeviceInfo.boardLocationStr);                       
		printf("UnitNum:%d ",gtDeviceInfo.unitNum);                                     
		printf("popMemSize:%d ",gtDeviceInfo.popMemSize);                               
		printf("mappedMemSize:%d ",gtDeviceInfo.mappedMemSize);                         
		printf("numLinks:%d ",gtDeviceInfo.numLinks);                                   
		printf("revisionId:%d ",gtDeviceInfo.revisionID);                               
	}                                                                                   
	
	stateId = SCGT_NODE_ID;                     
	value = MyNodeId;                                 
	ret = scgtSetState(&gtHandle,stateId,value);
	
	stateId = SCGT_UNICAST_INT_MASK;            
	value   = 1;                       
	ret = scgtSetState(&gtHandle,stateId,value);
	
	stateId = SCGT_BROADCAST_INT_MASK;            
	value   = 0xffffffff;                       
	ret = scgtSetState(&gtHandle,stateId,value);
		
	stateId = SCGT_INT_SELF_ENABLE;             
	value   = 1;                                
	ret = scgtSetState(&gtHandle,stateId,value);
	
	stateId = SCGT_LINK_UP;
	value = scgtGetState(&gtHandle,stateId);
	printf("Link is %s\n",(value == 1) ? "up":"down");
	
	gtMemoryOffset = 8;
	//bytesToTransfer=1024*384;  // transfer 1.5 chunks
    bytesToTransfer=1024*512;
	//bytesToTransfer=1024;
	//flags = SCGT_RW_PIO;
	flags = 0;
	bytesTransfered = 1;
	
	ret = scgtRead(&gtHandle,gtMemoryOffset,dataBuffer,bytesToTransfer,flags,&bytesTransfered);
	if( ret != SCGT_SUCCESS)
	{
		printf("scgtRead returned error code 0x%x. %s\n",ret,scgtGetErrStr(ret));
	}
	else
	{
		printf("scgtRead completed sucessfully.\n");
	}
	printf("BytesToTranfer = %d. BytesTransfered = %d.\n",bytesToTransfer,bytesTransfered);
	
	
	printf("memory[x]=");
	
	for(i=0;i<8;i++)
	{
		printf("%d:%08lx ",i,dataBuffer[i]);
	}
	
	printf("\n");
	
	
	for(i=0;i<bytesToTransfer;i++)
		dataBuffer[i]++;
	
	ret = scgtWrite(&gtHandle,gtMemoryOffset,dataBuffer,bytesToTransfer,flags,&bytesTransfered,NULL);
	if( ret != SCGT_SUCCESS)                                                                       
	{                                                                                              
		printf("scgtWrite returned error code 0x%x. %s\n",ret,scgtGetErrStr(ret));                  
	}                                                                                              
	else                                                                                           
	{                                                                                              
		printf("scgtWrite completed sucessfully.\n");                                              
	}   
	printf("BytesToTranfer = %d. BytesTransfered = %d.\n",bytesToTransfer,bytesTransfered);        
	
	
	interruptHandle = -1;                                                                                     
	numInterrupts = 4;                                                                                        
	timeout = 5000;                                                                                          
	ret = scgtGetInterrupt(&gtHandle,&interruptHandle,interruptBuffer,
	                       numInterrupts,timeout,&numInterruptRet);
	if(ret == SCGT_SUCCESS)                                                                                   
	{                                                                                                         
		printf("found Interrupt\n");                                                                         
		for(i=0;i< numInterruptRet;i++)                               
		{                                                             
			printf("Int: type %d",interruptBuffer[i].type);           
			printf("SourceNodeId:%d, id:%d val:0x%x SeqNum:%d\n",     
				interruptBuffer[i].sourceNodeID,interruptBuffer[i].id,
				interruptBuffer[i].val, interruptBuffer[i].seqNum);   
		}                                                             
	}                                                                                                         
	else if(ret == SCGT_TIMEOUT)                                                                              
	{                                                                                                         
		printf("Timed out looking for interrupts\n");
	}                                                                                                         
	else
		printf("scgtGetInterrupt returned 0x%x %s\n",ret,scgtGetErrStr(ret));
	
	// **********1 send out a network Interrut *******************************
	
	printf("Send out a broadcast interrupt \n");
	
	bytesToTransfer = 0;
	flags = SCGT_RW_PIO;
	
	gtInterrupt.type = SCGT_BROADCAST_INTR;
	gtInterrupt.id   = 26;
	gtInterrupt.val  = 0x12345678;
	
	ret = scgtWrite(&gtHandle,gtMemoryOffset,dataBuffer,bytesToTransfer,flags,
	                &bytesTransfered,&gtInterrupt);
	if( ret != SCGT_SUCCESS)                                                                          
	{                                                                                                 
		printf("scgtWrite returned error code 0x%x. %s\n",
		       ret,scgtGetErrStr(ret));                    
	}                                                                                                 
	
	Sleep(100);
	
	numInterrupts = 4;
	timeout = 5000;
	ret = scgtGetInterrupt(&gtHandle,&interruptHandle,interruptBuffer,
	                       numInterrupts,timeout,&numInterruptRet);
	if(ret == SCGT_SUCCESS)
	{
	  for(i=0;i< numInterruptRet;i++)
	  {
	    printf("Got Int: type %d %s ",interruptBuffer[i].type,
			(interruptBuffer[i].type==SCGT_UNICAST_INTR) ? "Unicast": 
			(interruptBuffer[i].type==SCGT_BROADCAST_INTR) ? "Broadcast": "error");
		printf("SourceNodeId:%d, id:%d val:0x%x SeqNum:%d\n",
			interruptBuffer[i].sourceNodeID,interruptBuffer[i].id,
			interruptBuffer[i].val, interruptBuffer[i].seqNum);
	  }
	}
	else if(ret == SCGT_TIMEOUT)
	{
	  printf("Timed out looking for interrupts\n");
	}
	else
	  printf("scgtGetInterrupt returned 0x%x %s\n",ret,scgtGetErrStr(ret));
	
    // ****** send out a network Interrut ************************************
                                                                                                          	
    printf("Send out a unicast interrupt \n");                                                              	
    bytesToTransfer = 0;                                                                                      	
    flags = SCGT_RW_PIO;                                                                                      	
                                                                                                          	
    gtInterrupt.type = SCGT_UNICAST_INTR;                                                                   	
    gtInterrupt.id   = MyNodeId;                                                                                    	
    gtInterrupt.val  = 0xdeadbeef;                                                                            	
                                                                                                          	
    ret = scgtWrite(&gtHandle,gtMemoryOffset,dataBuffer,bytesToTransfer,
		            flags,&bytesTransfered,&gtInterrupt);	
    if( ret != SCGT_SUCCESS)                                                                                  	
    {                                                                                                         	
	   printf("scgtWrite returned error code 0x%x. %s\n",
		      ret,scgtGetErrStr(ret));                            	
    }                                                                                                         	
    else                                                                                                      	
    {                                                                                                         	
	    printf("scgtWrite completed sucessfully.\n");                                                         	
    }                                                                                                         	
                                                                                                          	
    Sleep(100);                                                                                               	
	
    numInterrupts = 4;                                                                                        	
    timeout = 5000;                                                                                           	
    ret = scgtGetInterrupt(&gtHandle,&interruptHandle,
		                   interruptBuffer,numInterrupts,
						   timeout,&numInterruptRet);	
    if(ret == SCGT_SUCCESS)                                                                                   	
    {                                                                                                         	
	  for(i=0;i< numInterruptRet;i++)                                                                       	
	  {                                                                                                     	
	    printf("Got Int: type %d %s ",interruptBuffer[i].type,                                                	
		  (interruptBuffer[i].type==SCGT_UNICAST_INTR) ? "Unicast":                                     	
		  (interruptBuffer[i].type==SCGT_BROADCAST_INTR) ? "Broadcast": "error");
	    printf("SourceNodeId:%d, id:%d val:0x%x SeqNum:%d\n",                                             	
		  interruptBuffer[i].sourceNodeID,interruptBuffer[i].id,                                        	
		  interruptBuffer[i].val, interruptBuffer[i].seqNum);                                           	
	  }                                                                                                     	
    }                                                                                                         	
    else if(ret == SCGT_TIMEOUT)                                                                              	
    {                                                                                                         	
	  printf("Timed out looking for interrupts\n");                                                         	
    }                                                                                                        
    else 
	  printf("scgtGetInterrupt returned 0x%x %s\n",ret,scgtGetErrStr(ret));                                
		
		
	// *** allocate block of memory to use in DMA transfers ******************
		
	transferSize = 1024*256+256;
	
	status = viOpenDefaultRM(&defaultRM);                     
	if(status < VI_SUCCESS) 
		goto ShutDown;                  
		                                                                             
	status = viOpen(defaultRM,"PXI0::MEMACC",VI_NULL,VI_NULL,&instr);
	if(status != VI_SUCCESS) 
		goto ShutDown;
		                                                                             
	status = viMemAllocEx(instr,transferSize,&bufBusAddr);                      
	if(status != VI_SUCCESS)
		goto ShutDown;
		                                                                             
	status = viMapAddressEx(instr,VI_PXI_ALLOC_SPACE,bufBusAddr,
		                    transferSize, VI_FALSE,VI_NULL,&mappedAddr);     
	if(status != VI_SUCCESS)
		goto ShutDown;

    printf("DMA directly to buffer at PCI address 0x%x MappedAddr=%x\n",(ViUInt32)bufBusAddr,(ViUInt32)mappedAddr);
	gtMemoryOffset = 0;
	flags = SCGT_RW_DMA_PHYS_ADDR;
	ret = scgtWrite(&gtHandle,gtMemoryOffset,(void*)bufBusAddr,transferSize,
		     flags,&bytesTransfered,NULL);
	if( ret != SCGT_SUCCESS)                                                                                
	{                                                                                                       
	   printf("scgtWrite returned error code 0x%x. %s\n",ret,scgtGetErrStr(ret));                           
	}                                                                                                       
	else                                                                                                    
	{                                                                                                       
	    printf("scgtWrite completed sucessfully.\n");                                                       
	}                                                                                                       
	
	viUnmapAddress(instr);
	viMemFreeEx(instr,bufBusAddr);
	viClose(instr);
	viClose(defaultRM);
	
	
ShutDown:                
	free(dataBuffer);
  	scgtUnmapMem(&gtHandle);
    scgtClose(&gtHandle);
	CloseCVIRTE ();
	
	printf("Program Complete\n");
}



