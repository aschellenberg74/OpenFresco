The SCRAMNet GT realtime dll file scgtapi.dll make uses of CVI realtime calls. 
When deploying this file to realtime targets you need to have a copy of the 
cvi_lvrt.dll file present on the target system. The cvi_lvrt.dll file provides
hooks into the Realtime engine that are needed by the scgtapi.dll file.  

When you create the read time applciaiton you need to include the cvi_lvrt file
in this dirctory or the one from your windows32/system directory in the suport
directory ( which is the ni-rt\startup\data directory). You can do this by 
adding the cvi_lvrt.dll file to always include section in the source files
category in your build spec.