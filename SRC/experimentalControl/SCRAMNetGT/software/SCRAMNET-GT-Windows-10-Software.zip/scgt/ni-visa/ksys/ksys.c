//#include <utility.h>
//#include <ansi_c.h>
/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2002-2005 Curtiss-Wright Controls.                           */
/*               support@systran.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

#include "ksys.h"
#include "systypes.h"

#include "gtcore.h"

char *FILE_REV_KSYS_C = "1";    /* 9/17/07 */


#define GTCORE_CHAIN_BYTES   (SCGT_DMA_CHAIN_LEN * GTCORE_CE_SIZE)   /* chain length in bytes */

#ifndef KSYS_CACHE_LINE_SIZE
#define GTCORE_CACHE_LINE_SIZE  256
#else
#define GTCORE_CACHE_LINE_SIZE  KSYS_CACHE_LINE_SIZE    /* cache line size must be >= 16 */
#endif
void * gtcoreAlignAddr(void *ptr, uint32 alignSize); /* from gtcore.c */



/************************************************************/
/*********** timeouting semaphore implementation ************/
/************************************************************/
void ksysSemBCreate(ksysSemB * sem)
{
#ifdef USE_VI_LOCKS	
	ViStatus status;
	
	if( sem == VI_NULL)
		return;
	
	sem->waiting =0;
	
	status = viOpenDefaultRM(&sem->semBdefaultRM);
	if(status != VI_SUCCESS)
	{
		sem->created = 0;
        return;	
	}
	
	status = viOpen(sem->semBdefaultRM,"PXI0::MEMACC",VI_NULL,
		            VI_NULL,&sem->semBInstr);
	if(status != VI_SUCCESS)
	{
		sem->created = 0;
		return;
	}
	sem->lockType = VI_EXCLUSIVE_LOCK;
	sem->created = 1;
#elif defined USE_CMT_CALLS   
	int ret;
	if(strlen(sem->lockName) == 0)
		ret = CmtNewLock(NULL,sem->options,&sem->lockHandle);
	else
		ret = CmtNewLock(sem->lockName,sem->options,&sem->lockHandle);
	
	if (ret != 0) // error
	{
		printf("Unable to create threadLock");
		return;
	}
	sem->waiting =0;
#elif defined USE_WIN_CALLS
	// semaphore is signaled when count is greater than zero
	// and nonsignal when count is equal zero
	sem->hSem  = CreateSemaphore(NULL,0,MAX_COUNT,NULL);
	//*sem  = CreateSemaphore(NULL,1,MAX_COUNT,NULL);
	if(sem->hSem == NULL)
		printf("error crating binary semaphore: %d \n",GetLastError());
	sem->created = TRUE;
	sem->waiting = 0;
#endif	
}

/****************************************************************************/
void ksysSemBDestroy(ksysSemB * sem)
{
#ifdef USE_VI_LOCKS	
   ViStatus status;
   sem->created = 0;
   status = viClose(sem->semBInstr);
   status = viClose(sem->semBdefaultRM);
#elif defined USE_CMT_CALLS   
   CmtDiscardLock(sem->lockHandle);
#elif defined USE_WIN_CALLS   
   CloseHandle(sem->hSem);
   sem->created = FALSE;
   sem->waiting = 0;
#endif   
}

/****************************************************************************/
uint32 ksysSemBTakeWithTimeout(ksysSemB *p_sem, long to)
{
#ifdef USE_VI_LOCKS		
	ViStatus status;
	
	p_sem->waiting++;
	status = viLock(p_sem->semBInstr,p_sem->lockType,to,VI_NULL,VI_NULL);
	if(status == VI_SUCCESS)
	{
		p_sem->waiting--;
		return SCGT_SUCCESS;
	}
	else if (status ==VI_ERROR_TMO)
		return SCGT_TIMEOUT;
	else
		return SCGT_DRIVER_ERROR;
#elif defined USE_CMT_CALLS   
	int ret;
	int attribVal;
	char ErrMsg[255];
	ret = CmtGetLockAttribute(p_sem->lockHandle,ATTR_LOCK_OWNER_THREAD, &attribVal);
	if (ret < 0)
		CmtGetErrorMessage(ret,ErrMsg);
	if(attribVal != 0)
	   printf("attribVal=%x\n",attribVal);

	ret = CmtGetLock(p_sem->lockHandle);
	if( ret == 0)
	   return SCGT_SUCCESS;	
	return SCGT_DRIVER_ERROR;
#elif defined USE_WIN_CALLS   
    int ret; 
	DWORD miliseconds = to;
	ret = WaitForSingleObject(p_sem->hSem, miliseconds );
	if(ret == WAIT_OBJECT_0)
	{
		// Semaphore count was greater than zero so
		//  we decrement the count by one
		p_sem->waiting--;
		return SCGT_SUCCESS;
	}
	else if(ret == WAIT_TIMEOUT)
	{
		// Semaphore Count stayed zero untill timeout period expired 
		return SCGT_TIMEOUT;
	}
    else
		return SCGT_DRIVER_ERROR;	
#else 
	
    return SCGT_SUCCESS;
	
#endif	
}

/****************************************************************************/
uint32 ksysSemBTake(ksysSemB *p_sem)
{
#ifdef USE_VI_LOCKS	
	ViStatus status;
	
	status = viLock(p_sem->semBInstr,p_sem->lockType,
		            VI_TMO_INFINITE ,VI_NULL,VI_NULL);
	if(status == VI_SUCCESS)
		return SCGT_SUCCESS;
	else
		return SCGT_DRIVER_ERROR;
	
#elif defined USE_CMT_CALLS   
	
	int ret;
	ret = CmtGetLock(p_sem->lockHandle);
	if( ret == 0)
	   return SCGT_SUCCESS;	
	return SCGT_DRIVER_ERROR;

#elif defined USE_WIN_CALLS   
	// decrement the semaphore Count by one.
	// if semaphore count is zero wait untill it is set to nonzero
	WaitForSingleObject(p_sem->hSem, INFINITE );
	p_sem->waiting--;
    return SCGT_SUCCESS;	
#else 
	
    return SCGT_SUCCESS;
	
#endif	
}

/****************************************************************************/
uint32 ksysSemBGive(ksysSemB *p_sem)
{
#ifdef USE_VI_LOCKS		
	ViStatus status;
	status = viUnlock(p_sem->semBInstr);
	if(status == VI_SUCCESS)
		return SCGT_SUCCESS;
	
	return SCGT_DRIVER_ERROR;
	
#elif defined USE_CMT_CALLS   
	int ret;
	ret = CmtDiscardLock(p_sem->lockHandle);
	if( ret == 0)
	   return SCGT_SUCCESS;	
	return SCGT_DRIVER_ERROR;
#elif defined USE_WIN_CALLS  
	// increase the semaphore count by the amount specifed.
    ReleaseSemaphore(p_sem->hSem,1,NULL);	
	p_sem->waiting++;
	return SCGT_SUCCESS;
#else 
    return SCGT_SUCCESS;
#endif	
}

/****************************************************************************/
void ksysSemSCreate(ksysSemS * pSemS)  
{
#ifdef USE_VI_LOCKS			
	ViStatus status;
	
	if( pSemS == VI_NULL)
		return;
	
	status = viOpenDefaultRM(&pSemS->semDefaultRM);
	if(status != VI_SUCCESS)
	{
		pSemS->created = 0;
        return;	
	}
	
	status = viOpen(pSemS->semDefaultRM,"PXI0::MEMACC",VI_NULL,
		            VI_NULL,&pSemS->semInstr);
	if(status != VI_SUCCESS)
	{
		pSemS->created = 0;
		return;
	}
	pSemS->created = 1;
	
#elif defined USE_CMT_CALLS   
	
	int ret;
	ret = CmtNewLock(VI_NULL,0,&pSemS->lockHandle);
	if (ret != 0) // error
		return;
#elif defined USE_WIN_CALLS
	   pSemS->hSem = CreateSemaphore(NULL,0,MAX_COUNT,NULL);
	   //pSemS->hSem = CreateSemaphore(NULL,1,MAX_COUNT,NULL);
	   if(pSemS->hSem == NULL)
	   {
		   printf("Error creating semaphore: %d\n",GetLastError());
	   }
	   pSemS->waiting = 0;
	   pSemS->created = TRUE;
#endif	
}

/****************************************************************************/
void ksysSemSDestroy(ksysSemS * pSemS)
{
#ifdef USE_VI_LOCKS			
   ViStatus status;
   pSemS->created = 0;
   status = viClose(pSemS->semInstr);
   status = viClose(pSemS->semDefaultRM);

#elif defined USE_CMT_CALLS   
   
   int ret;
   ret = CmtDiscardLock(pSemS->lockHandle);
   if (ret != 0) // error
		return;
#elif defined USE_WIN_CALLS
    CloseHandle(pSemS->hSem);
#endif   
}

/****************************************************************************/
uint32  ksysSemSTake(ksysSemS * pSemS)
{
#ifdef USE_VI_LOCKS
   ViStatus status;
   status = viLock(pSemS->semInstr,VI_EXCLUSIVE_LOCK,
                   VI_TMO_INFINITE ,VI_NULL,VI_NULL);
   if(status == VI_SUCCESS)
      return SCGT_SUCCESS;
   else
      return SCGT_DRIVER_ERROR;

#elif defined USE_CMT_CALLS   

   int ret;
   ret = CmtGetLock(pSemS->lockHandle);
   if( ret == 0)
      return SCGT_SUCCESS;	
   return SCGT_DRIVER_ERROR;
#elif defined USE_WIN_CALLS
   WaitForSingleObject(pSemS->hSem, INFINITE );
   pSemS->waiting--;
   return SCGT_SUCCESS;
#else 
   return SCGT_SUCCESS;
#endif
}

/****************************************************************************/
uint32 ksysSemSGive(ksysSemS * pSemS)
{
#ifdef USE_VI_LOCKS		
	ViStatus status;
	status = viUnlock(pSemS->semInstr);
	if(status == VI_SUCCESS)
		return SCGT_SUCCESS;
	
	return SCGT_DRIVER_ERROR;

#elif defined USE_CMT_CALLS   
	
	int ret;
	ret = CmtReleaseLock(pSemS->lockHandle);
	if( ret == 0)
	   return SCGT_SUCCESS;	
	return SCGT_DRIVER_ERROR;
#elif defined USE_WIN_CALLS
	 ReleaseSemaphore(pSemS->hSem,1,NULL);
	 pSemS->waiting++;
	 return SCGT_SUCCESS;
#else 
	
    return SCGT_SUCCESS;
#endif	
}



/***********************************************************/
/*********** Mem copies to and from user space *************/
/***********************************************************/

/*
void ksysCopyToUser(void *userPtrDest, void *src, uint32 numBytes)
{
    memcpy(userPtrDest, src, numBytes);
}

void ksysCopyFromUser(void *dst, void *userPtrSrc, uint32 numBytes)
{
    memcpy(dst, userPtrSrc, numBytes);
}
*/


/*************************************************************/
/****************** register write/read **********************/
/*************************************************************/

/*
void ksysWriteReg(void *pRegs, uint32 offset, uint32 val)
{
    // Bus swapping done by our cards.. otherwise you need to do this: 
    // WRITE_REGISTER_ULONG((ULONG *)(((char *)pRegs) + offset), BUS_SWAP(val)); 
    //WRITE_REGISTER_ULONG((ULONG *)(((char *)pRegs) + offset), val);
	pReg[offset] = val;
}


uint32 ksysReadReg(void *pRegs, uint32 offset)
{
    // Bus swapping done by our cards.. otherwise you need to do this: 
    // return BUS_SWAP(READ_REGISTER_ULONG((ULONG *)(((char *)pRegs) + offset))); 
    //return READ_REGISTER_ULONG((ULONG *)(((char *)pRegs) + offset));
	return pRegs[offset];
}
*/

#ifdef MAP_REGS

void ksysWriteReg(ViSession instr, ViAddr mappedAddr, uint32 offset, uint32 val)
{
	viPoke32(instr, (ViAddr)((uint32)mappedAddr + (offset)), val);
}

uint32 ksysReadReg(ViSession instr, ViAddr mappedAddr, uint32 offset)
{
    uint32 val;
	viPeek32(instr,(ViAddr)((uint32)mappedAddr + (offset)),&val);
	return val;
}

#else
void ksysWriteReg(ViSession instr, ViUInt16 space,  uint32 offset, uint32 val)
{
	viOut32(instr,space,offset,val);
}

uint32 ksysReadReg(ViSession instr, ViUInt16 space, uint32 offset)
{
    uint32 val;
	viIn32(instr,space,offset,&val);
	return val;
}
#endif



/*****************************************************************/
/************************** sleep ********************************/
/*****************************************************************/

/*
void ksysUSleep(unsigned long usec)
{

#if 0
    LARGE_INTEGER to;
    KSEMAPHORE sem;

    KeInitializeSemaphore(&sem, 0, 3);
    to.QuadPart = -labs(usec * 10);

    // Take & timeout on the semaphore 
    KeWaitForSingleObject((PHANDLE)&sem, Executive, KernelMode, FALSE, &to);
#endif
    KeStallExecutionProcessor(usec);

}
*/

/*************************************************************/

/********************************************************/
/****************** memory allocation *******************/
/********************************************************/

/*
void *ksysMalloc(uint32 nbytes)
{
    return malloc(nbytes);
}
*/

/*
 * Free kernel memory
 */
/* 
void ksysFree(void *p, uint32 len)
{
    free(p);
}
*/


/****************************************************************************/
/* scgtGetDmaBuff														    */
/* Allocate a block of PCI memory and records its virtual and bus addresss  */
/****************************************************************************/
uint32 scgtGetDmaBuff(scgtDmaMem** dmaMemPtr, uint32 numBytes)
{
	ViStatus status;
	ViUInt16 access;
	scgtDmaMem* dmaMem;
	
	dmaMem = (scgtDmaMem*) malloc(sizeof(scgtDmaMem));
	memset(dmaMem,0,sizeof(scgtDmaMem));
	if(dmaMem == NULL)
		return SCGT_INSUFFICIENT_RESOURCES;
	
	status = viOpenDefaultRM(&dmaMem->defaultRM);
	if(status < VI_SUCCESS)
	{
		return SCGT_INSUFFICIENT_RESOURCES;
	}
									   
	status = viOpen(dmaMem->defaultRM,"PXI0::MEMACC",VI_NULL,VI_NULL,
		            &dmaMem->dmaInstr);                                
					
	if(status != VI_SUCCESS)
	{
		free(dmaMem);
		return SCGT_INSUFFICIENT_RESOURCES;
	}
	status = viMemAllocEx(dmaMem->dmaInstr,numBytes,&dmaMem->busAddr);
	if(status != VI_SUCCESS)
	{
		free(dmaMem);
		return SCGT_INSUFFICIENT_RESOURCES;
	}
	status = viMapAddressEx(dmaMem->dmaInstr,VI_PXI_ALLOC_SPACE,dmaMem->busAddr,
		                  numBytes,VI_FALSE,VI_NULL,&dmaMem->mappedAddr);
	if(status != VI_SUCCESS)
	{
		free(dmaMem);
		return SCGT_INSUFFICIENT_RESOURCES;
	}
	status = viGetAttribute(dmaMem->dmaInstr, VI_ATTR_WIN_ACCESS, &access);
    /*
	if (access != VI_DEREF_ADDR)
	{
		free(dmaMem);
		return SCGT_INSUFFICIENT_RESOURCES;
		
	}*/
	dmaMem->accessMode = access;
	dmaMem->memMapped = numBytes;
	*dmaMemPtr = dmaMem;
	return SCGT_SUCCESS;
}	


/****************************************************************************/
/* scgtFreeDmaBuff                                                          */
/****************************************************************************/
uint32 scgtFreeDmaBuff(scgtDmaMem* dmaMemPtr)
{
	ViStatus status;
	//scgtDmaMem * dmaMemPtr;
	uint32 ret = SCGT_SUCCESS;
	
	//dmaMemPtr= dmaMemPtrPtr;
	
	status = viUnmapAddress(dmaMemPtr->dmaInstr);
	if(status != VI_SUCCESS)
	{
	   ret = SCGT_DRIVER_ERROR;
	}
	status = viMemFree(dmaMemPtr->dmaInstr,dmaMemPtr->busAddr);
	if(status != VI_SUCCESS)
	{
	   ret = SCGT_DRIVER_ERROR;
	}
	status = viClose(dmaMemPtr->dmaInstr);
	if(status != VI_SUCCESS)
	{
	   
	   ret = SCGT_DRIVER_ERROR;
	}
	viClose(dmaMemPtr->defaultRM);
	free (dmaMemPtr);
	//*dmaMemPtr = VI_NULL;
	return ret;
}	

/****************************************************************************/
/** ksysDmaMalloc                                                          **/
/****************************************************************************/
void * ksysDmaMalloc(void * mapDataVoidPtr, void **dmaHandleVoidPtrPtr,
	                 uint32 size)
{
    uint32 ret;
	scgtDmaMem * dmaMemPtr;
	dmaMemPtr = *dmaHandleVoidPtrPtr;
    ret = scgtGetDmaBuff(&dmaMemPtr,size);
	if(ret != SCGT_SUCCESS)
		return VI_NULL;
    *dmaHandleVoidPtrPtr = dmaMemPtr;
	return dmaMemPtr->mappedAddr;
}

/****************************************************************************/
/****************************************************************************/
void ksysDmaFree(void* dmaHandleVoidPtr, void * pBuf, uint32 size)
{
	scgtDmaMem * dmaMemPtr;
	dmaMemPtr = dmaHandleVoidPtr;
    scgtFreeDmaBuff(dmaMemPtr);
}



/***********************************************************/
/************ Vitual to bus addr translation ***************/
/***********************************************************/


/****************************************************************************/
/*
 * ksysUnmapVirtToBus()
 */
/****************************************************************************/
void ksysUnmapVirtToBus(void *dmaHandle, void *ptr)
{
	
}

/****************************************************************************/
/*
 * ksysMapVirtToBus()
 *     mapData must point to a DMA_ADAPTER
 */
/****************************************************************************/

uint64 ksysMapVirtToBus(void *dmaHandle, void *ptr, uint32 numBytes)
{
	scgtDmaMem* dmaMemPtr;
	uint64 basePtr;
	uint64 adjustedPtr;
	uint64 busAddr;
	
	dmaMemPtr = dmaHandle;
    
	basePtr     = (uint64)dmaMemPtr->mappedAddr;
	adjustedPtr = (uint64)ptr;
	
    busAddr = dmaMemPtr->busAddr;
	if( (basePtr < adjustedPtr) && (adjustedPtr < (basePtr + dmaMemPtr->memMapped)) )
	{
        busAddr = busAddr + (adjustedPtr - basePtr);
		if(busAddr < (uint64)dmaMemPtr->busAddr)
			return 0;
			
		return busAddr;
	}
	return 0;
}


	

/****************************************************************************/
/* gtcoreExchChain()												        */
/*   Allocate and initialize or Deallocate a chain for the exchange.        */
/*   Returns SCGT_SUCCESS if successful.									*/
/****************************************************************************/
uint32 gtVisaExchChain(scgtDevice *dev, gtcoreExchMgrData *exchMgrData, 
                       uint32 exchNum, uint8 direction, uint8 doAlloc)

{                                                                                                                    
    uint32 mySize;                                                                                                   
    int i;                                                                                                           
#ifndef USEPOKE	
    volatile uint32 *chainEntry;
#else	
	ViSession vi;
	uint32 chainEntryAddr;                                                                                     
	scgtDmaMem * dmaMemPtr;
#endif	
    gtcoreExch *exch;                                                                                                
    uint64 nextAddr;                                                                                                 
	
                                                                                                                     
#ifndef KSYS_CACHE_LINE_SIZE                                                                                         	
#define GTCORE_CACHE_LINE_SIZE  256                                                                                  
#else                                                                                                                
#define GTCORE_CACHE_LINE_SIZE  KSYS_CACHE_LINE_SIZE    /* cache line size must be >= 16 */                          
#endif                                                                                                               
                                                                                                                     
    exch = &exchMgrData->exchQ[exchNum];                                                                             
                                                                                                                     
    /* sgSpace of mySize is/will be larger than needed to cover aligment                                             
       and cache safety */                                                                                           
                                                                                                                     
#ifdef SCGT_EXCH_CHAIN_ONE_MAP                                                                                       
    mySize = GTCORE_CHAIN_BYTES * GTCORE_EXCH_CNT + GTCORE_CACHE_LINE_SIZE * 2;                                      
#else                                                                                                                
    mySize = GTCORE_CHAIN_BYTES + GTCORE_CACHE_LINE_SIZE * 2;                                                        
#endif                                                                                                               
                                                                                                                     
    if (doAlloc == 0)                                                                                                
    {                                                                                                                
#ifdef SCGT_EXCH_CHAIN_ONE_MAP                                                                                       
        if (exchNum != 0)                                                                                            
            return SCGT_SUCCESS;                                                                                     
#endif                                                                                                               
        if (exch->sgSpace != NULL)                                                                                   
        {                                                                                                            
            /* unmap sgList[0] */                                                                                    
            if (exch->sgListPhysAddr[0])                                                                             
                ksysUnmapVirtToBus(exch->sgDmaHandle, (void *) exch->sgList[0]);                                     
                                                                                                                     
            /* free sgSpace */                                                                                       
            if (exch->sgSpace)                                                                                       
                ksysDma2Free(exch->sgDmaHandle, (void *)exch->sgSpace, mySize);                                      
            exch->sgSpace = NULL;                                                                                    
        }                                                                                                            
                                                                                                                     
        return SCGT_SUCCESS;                                                                                         
    }                                                                                                                
                                                                                                                     
#ifdef SCGT_EXCH_CHAIN_ONE_MAP                                                                                       
    /**** allocate and map chain for only exchange 0                                                                 
          use offsets into it for other exchanges ******/                                                            
                                                                                                                     
    if (exchNum == 0)                                                                                                
    {                                                                                                                
        /* allocate the space, align it, and map */                                                                  
        exch->sgSpace = (uint32 *) ksysDma2Malloc(dev->mapData, &exch->sgDmaHandle, mySize);                         
        if (exch->sgSpace == NULL)                                                                                   
            return SCGT_DRIVER_ERROR;                                                                                
                                                                                                                     
        exch->sgList[0] = (uint32 *) gtcoreAlignAddr((void *) exch->sgSpace, GTCORE_CACHE_LINE_SIZE);                
                                                                                                                     
        exch->sgListPhysAddr[0] = (uint64) ((uintpsize) ksysMapVirtToBus(exch->sgDmaHandle,                          
                                                                         ((void *)exch->sgList[0]),                  
                                                                         GTCORE_CHAIN_BYTES * GTCORE_EXCH_CNT));     
                                                                                                                     
        if (exch->sgListPhysAddr[0] == 0)                                                                            
            return SCGT_DRIVER_ERROR;                                                                                
    }                                                                                                                
    else                                                                                                             
    {                                                                                                                
        /* here we use an offset into the already mapped address from exchange 0 */                                  
        gtcoreExch *exch0 = &exchMgrData->exchQ[0];                                                                  
                                                                                                                     
        if (exch0->sgList[0] == NULL)                                                                                
            return SCGT_DRIVER_ERROR;                                                                                
                                                                                                                     
        /* sgList[0] is type uint32 * so we add num of words to get new ptr */                                       
        exch->sgList[0] = exch0->sgList[0] + ((exchNum * GTCORE_CHAIN_BYTES) / 4);                                   
        exch->sgListPhysAddr[0] = exch0->sgListPhysAddr[0] + (exchNum * GTCORE_CHAIN_BYTES);                         
        exch->sgDmaHandle = exch0->sgDmaHandle;                                                                      
    }                                                                                                                
#else                                                                                                                
    /**** allocate and map chain for every exchange separately ******/                                               
                                                                                                                     
    exch->sgSpace = (uint32 *) ksysDma2Malloc(dev->mapData, &exch->sgDmaHandle, mySize);                             
    if (exch->sgSpace == NULL)                                                                                       
        return SCGT_DRIVER_ERROR;                                                                                    
                                                                                                                     
    exch->sgList[0] = (uint32 *) gtcoreAlignAddr((void *)exch->sgSpace, GTCORE_CACHE_LINE_SIZE);                     
                                                                                                                     
    exch->sgListPhysAddr[0] = (uint64) ksysMapVirtToBus(exch->sgDmaHandle,                                           
                                                        ((void *)exch->sgList[0]),                                   
                                                        GTCORE_CHAIN_BYTES);                                         
    if (exch->sgListPhysAddr[0] == 0)                                                                                
        return SCGT_DRIVER_ERROR;                                                                                    
#endif                                                                                                               

#ifndef USEPOKE
    /* initialize each chain entry */                                                                                
    chainEntry = exch->sgList[0];                                                                                    
    for (i = 0; i < SCGT_DMA_CHAIN_LEN; i++)                                                                         
    {                                                                                                                
        chainEntry[GTCORE_CE_BUF_ADD32] = 0;                                                                         
        chainEntry[GTCORE_CE_TNS_CSR] = 0;                                                                           
        chainEntry[GTCORE_CE_BUF_ADD64] = 0;                                                                         
                                                                                                                     
        chainEntry[GTCORE_CE_RESERVED_0] = direction << 24 | exchNum << 16 | i;  // * debugging purposes             
        chainEntry[GTCORE_CE_RESERVED_1] = 0;                                                                        
        chainEntry[GTCORE_CE_RESERVED_2] = 0;                                                                        
                                                                                                                     
        // * assumes memory is physically contiguous 
        nextAddr = exch->sgListPhysAddr[0] + (i+1) * GTCORE_CE_SIZE;                                                 
        chainEntry[GTCORE_CE_NEXT_ADD32] = (uint32) nextAddr;                                                        
        chainEntry[GTCORE_CE_NEXT_ADD64] = (uint32) (nextAddr >> 32);                                                
                                                                                                                     
        chainEntry += (GTCORE_CE_SIZE / 4);  // * move to next chain queue entry
    }
#else	
	dmaMemPtr = (scgtDmaMem*)(exch->sgDmaHandle);
	vi = dmaMemPtr->dmaInstr;
	//chainEntryAddr =  dmaMemPtr->mappedAddr;
	chainEntryAddr = (uint32) exch->sgList[0];
	for (i = 0; i < SCGT_DMA_CHAIN_LEN; i++)                                                                         
	{                                                                                                                
	    viPoke32(vi,(ViAddr)(chainEntryAddr+GTCORE_CE_BUF_ADD32 * 4),0);
	    viPoke32(vi,(ViAddr)(chainEntryAddr+GTCORE_CE_TNS_CSR * 4),0);                                                                           
	    viPoke32(vi,(ViAddr)(chainEntryAddr+GTCORE_CE_BUF_ADD64 * 4),0);                                                                         
	                                                                                                                 
	    viPoke32(vi,(ViAddr)(chainEntryAddr+GTCORE_CE_RESERVED_0 * 4), direction << 24 | exchNum << 16 | i);  /* debugging purposes */            
	    viPoke32(vi,(ViAddr)(chainEntryAddr+GTCORE_CE_RESERVED_1 * 4), 0);
	    viPoke32(vi,(ViAddr)(chainEntryAddr+GTCORE_CE_RESERVED_2 * 4), 0);
	                                                                                                                 
	    /* assumes memory is physically contiguous */                                                                
	    nextAddr = exch->sgListPhysAddr[0] + (i+1) * GTCORE_CE_SIZE;                                                 
	    viPoke32(vi,(ViAddr)(chainEntryAddr+GTCORE_CE_NEXT_ADD32*4) , (uint32) nextAddr); 
	    viPoke32(vi,(ViAddr)(chainEntryAddr+GTCORE_CE_NEXT_ADD64*4),(uint32) (nextAddr >> 32) );
	                                                                                                                 
        chainEntryAddr += GTCORE_CE_SIZE ;  /* move to next chain queue entry */
    }                                                                                                                
#endif	
	return SCGT_SUCCESS;                                                                                             
}                                                                                                                    


/*
 * gtcoreInitTrQueue()
 *     Allocate and align or free transaction queue
 */

uint32 gtVisaTrQueue(scgtDevice *dev, gtcoreExchMgrData *exchMgrData,
                     uint8 direction, uint8 doAlloc)
{
	scgtDmaMem* dmaMem = VI_NULL;
	uint32 qSize;
	uint32 ret;
#ifndef USEPOKE
	uint32 *tqe;
#else
	uint32 tqeAddr;
#endif
	uint32 i;
	
	
	
	//dmaMem = (scgtDmaMem*) exchMgrData->trDmaHandle;
	
	qSize = (GTCORE_EXCH_CNT * GTCORE_TQE_SIZE) + (GTCORE_CACHE_LINE_SIZE * 2);
    if (doAlloc == 0)
    {
        if (exchMgrData->trSpace != NULL)
        {
            /* free trSpace */
            if (exchMgrData->trSpace)
			{
				dmaMem = exchMgrData->trDmaHandle;
				scgtFreeDmaBuff(dmaMem);
			}
            exchMgrData->trSpace = NULL;
        }
        return SCGT_SUCCESS;
    }
	
    /* Allocate space for the Transaction Queues */
    /* Triple the size for alignment purposes */
	ret = scgtGetDmaBuff(&dmaMem,qSize);
	if(ret != SCGT_SUCCESS)
		return ret;
	
    exchMgrData->trSpace = (uint32*) dmaMem->mappedAddr;
    if (exchMgrData->trSpace == NULL)
        return SCGT_DRIVER_ERROR;
        
    exchMgrData->trQueue = (uint32*) gtcoreAlignAddr((void *) exchMgrData->trSpace, GTCORE_CACHE_LINE_SIZE);
	


    exchMgrData->trPhysical = (uint64) ((uintpsize) ksysMapVirtToBus(dmaMem,           
                                                                  exchMgrData->trQueue,               
                                                                  GTCORE_EXCH_CNT * GTCORE_TQE_SIZE));
    if (exchMgrData->trPhysical == 0)
    {
        scgtFreeDmaBuff(dmaMem);
        return SCGT_DRIVER_ERROR;
    }
    
    /* initialize some members of each transaction queue entry 
       that won't change on a transfer by transfer basis */
#ifndef USEPOKE	
    tqe = exchMgrData->trQueue;
    for (i = 0; i < GTCORE_EXCH_CNT; i++)
    {
        tqe[GTCORE_TQE_NI_CTL] = 0;
        tqe[GTCORE_TQE_RESERVED_0] = 0;
        tqe[GTCORE_TQE_RESERVED_1] = 0;
        tqe += (GTCORE_TQE_SIZE / 4);
    }
#else
	tqeAddr = (uint32) exchMgrData->trSpace;
	for (i = 0; i < GTCORE_EXCH_CNT; i++)
	{
        viPoke32(dmaMem->dmaInstr,(ViAddr)(tqeAddr+GTCORE_TQE_NI_CTL*4), 0);		
		viPoke32(dmaMem->dmaInstr,(ViAddr)(tqeAddr+GTCORE_TQE_RESERVED_0*4), 0);
		viPoke32(dmaMem->dmaInstr,(ViAddr)(tqeAddr+GTCORE_TQE_RESERVED_1*4), 0);
		tqeAddr += GTCORE_TQE_SIZE;
	}
#endif	
	
	exchMgrData->trDmaHandle = (void*) dmaMem;
    return SCGT_SUCCESS;
}






