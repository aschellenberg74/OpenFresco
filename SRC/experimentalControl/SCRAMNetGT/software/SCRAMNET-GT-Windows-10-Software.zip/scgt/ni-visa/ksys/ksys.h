/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2002-2005 Curtiss-Wright Controls.                           */
/*               support@systran.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

/*
 * ksys.h
 *     NI-VISA ksys
 */
 
#ifndef __K_SYS_H__
#define __K_SYS_H__

/*********************************/
/********* INCLUDE FILES *********/
/*********************************/

#include "systypes.h"

#define FILE_REV_KSYS_H    "5"     /* 11/10/03 */

/*****************************************/
/************** DEFINITIONS **************/
/******************************************/

#define MAX_SEM_CNT  1

#define ksysAlignTQueueAddr(ptr, tqsize)   ((void*)((uintpsize)ptr & ~((uintpsize)(tqsize - 1))))
#define ksysCacheFlush(dmaHandlePtr, ptr, size)
#define ksysCacheInvalidate(dmaHandlePtr, ptr, size)


/* default ksysDmaMallocs are used for Windows */

/****************************************/
/********** TYPES & STRUCTURES **********/
/****************************************/



/****************** prototypes ********************/

/* memory allocation */
#define ksysMalloc(numBytes)       malloc((numBytes))
#define ksysFree(ptr, numBytes)    free(ptr)

#define ksysCopyToUser(usrPtrDest, srcPtr, numBytes) memcpy(usrPtrDest, srcPtr, numBytes)
#define ksysCopyFromUser(kernPtrDest, srcPtr, numBytes) memcpy(kernPtrDest, srcPtr, numBytes)

/*
void ksysWriteReg(void *pRegs, uint32 offset, uint32 val);
uint32 ksysReadReg(void *pRegs, uint32 offset);

void *ksysMalloc(uint32 nbytes);
void ksysFree(void *p, uint32 len);
*/



/*******************************************************/
/**  For implementation of semaphores with timeouts    */
/*******************************************************/
#ifdef USE_VI_LOCKS	
typedef struct _ksysSemB
{
    volatile uint32 waiting;
	ViSession    semBdefaultRM;
	ViSession    semBInstr;
	ViAccessMode lockType;
	int created;
} ksysSemB;
#elif defined USE_CMT_CALLS
typedef struct _ksysSemB
{
    volatile uint32 waiting;
	char            lockName[15];
	unsigned int    options;
	int             lockHandle;
} ksysSemB;
#elif defined USE_WIN_CALLS

#include "windows.h"
#include "winbase.h"

typedef struct _ksysSemB
{
    volatile uint32 waiting;
    HANDLE hSem;
	int created;
} ksysSemB;

#define MAX_COUNT 10
#else
typedef int ksysSemB;

#endif


void ksysSemBCreate(ksysSemB * sem);
void ksysSemBDestroy(ksysSemB * sem);

/* timeouting binary semaphore */
uint32 ksysSemBTakeWithTimeout(ksysSemB *p_sem, long to);
uint32 ksysSemBTake(ksysSemB *p_sem);
uint32 ksysSemBGive(ksysSemB *p_sem);


/*******************************************************/
/***** simple semaphore (no timeout functionality) *****/
/*******************************************************/
#ifdef USE_VI_LOCKS
typedef struct _ksysSem
{
	ViSession    semDefaultRM;
	ViSession    semInstr;
	int created;
} ksysSemS;
#elif defined USE_CMT_CALLS
typedef struct _ksysSem
{
	int lockHandle;
	int created;
} ksysSemS;
#elif defined USE_WIN_CALLS
typedef struct _ksysSemS
{
    volatile uint32 waiting;
    HANDLE hSem;
	int created;
} ksysSemS;
#else
typedef int ksysSemS;
#endif

void   ksysSemSCreate(ksysSemS * pSemS);
void   ksysSemSDestroy(ksysSemS * pSemS);
uint32 ksysSemSTake(ksysSemS * pSemS);    
uint32 ksysSemSGive(ksysSemS * pSemS);


/******************************/
/****** mutex type ************/
/******************************/
/*
typedef FAST_MUTEX ksysMutex;

#define ksysMutexCreate(pMutex)   ExInitializeFastMutex(pMutex)
#define ksysMutexDestroy(pMutex)  
#define ksysMutexTake(pMutex)     //ExAcquireFastMutex(pMutex)
#define ksysMutexGive(pMutex)     //ExReleaseFastMutex(pMutex)
*/
/******************************/
/****** spin lock type ********/
/******************************/
/*
typedef KSPIN_LOCK ksysSpinLock;
typedef KIRQL      ksysSpinLockFlags;

#define ksysSpinLockCreate(pSpinLock)   KeInitializeSpinLock((pSpinLock))
#define ksysSpinLockDestroy(pSpinLock)  
#define ksysSpinLockLock(pSpinLock, pSpinLockFlags)     KeAcquireSpinLock((pSpinLock), (pSpinLockFlags))
#define ksysSpinLockUnlock(pSpinLock, pSpinLockFlags)   KeReleaseSpinLock((pSpinLock), *(pSpinLockFlags))
*/
/****************** prototypes ********************/

uint64 ksysMapVirtToBus(void *dmaHandle, void *ptr, uint32 numBytes);
void ksysUnmapVirtToBus(void *dmaHandle, void *ptr);

#ifdef MAP_REGS
void ksysWriteReg(ViSession Instr,  ViAddr mappedAddr, uint32 offset, uint32 val);
uint32 ksysReadReg(ViSession instr, ViAddr mappedAddr, uint32 offset);
#else
void ksysWriteReg(ViSession Instr, uint16 space,  uint32 offset, uint32 val);
uint32 ksysReadReg(ViSession instr, uint16 space, uint32 offset);
#endif

/*--------------------------------------------------------------------------*/
typedef struct scgtDmaMemType
{
	ViSession      defaultRM;
	ViSession      dmaInstr;
	ViBusAddress64 busAddr;
	ViAddr         mappedAddr;
	uint16         accessMode;
	uint32         memMapped; 
} scgtDmaMem;

void * ksysDmaMalloc(void * mapDataVoidPtr, void **dmaHandleVoidPtrPtr, uint32 size);


void ksysDmaFree(void* dmaHandleVoidPtr, void * pBuf, uint32 size);


/* default action for DMA Mallocs is to copy mapDataVoidPtr to the location
   pointed to by dmaHandleVoidPtrPtr and then call ksysMalloc().  
   The is all that's needed for some OSs and won't hurt others that don't 
   use the mapDataVoidPtr at all */

#define ksysDma1Malloc(mapDataVoidPtr, dmaHandleVoidPtrPtr, size)  \
        ksysDmaMalloc(mapDataVoidPtr,dmaHandleVoidPtrPtr,size)

#define ksysDma1Free(dmaHandleVoidPtr, pBuf, size)    ksysDmaFree(dmaHandleVoidPtr, pBuf, size)

#define ksysDma2Malloc(mapDataVoidPtr, dmaHandleVoidPtrPtr, size)  \
        ksysDmaMalloc(mapDataVoidPtr,dmaHandleVoidPtrPtr,size)

#define ksysDma2Free(dmaHandleVoidPtr, pBuf, size)   ksysDmaFree(dmaHandleVoidPtr, pBuf, size)


/*--------------------------------------------------------------------------*/
/*
void ksysUSleep(unsigned long usec);
*/

#endif /* __K_SYS_H__ */
