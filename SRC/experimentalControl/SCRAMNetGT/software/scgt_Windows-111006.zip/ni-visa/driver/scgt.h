/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2002-2005 Curtiss-Wright Controls.                           */
/*               support@systran.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/*                                                                            */
/*    Module      : scgt.h                                                    */
/*    Description : supporting structures and defines for scgt.c              */
/*    Platform    : Win2K                                                     */
/*                                                                            */
/******************************************************************************/

#ifndef __SCGT_H__
#define __SCGT_H__

#include "systypes.h"
#include "gtcoreTypes.h"


#define FILE_REV_SCGT_H    "3"   /* 01/28/04 */


typedef struct _scgtDMATools
{
    ksysSemS        entrySem_1;
    ksysSemS        entrySem_2;
    uint32          pending;    
    ViSession       dmaInstr;
    ViSession       dmaDefaultRM;
    ViBusAddress64  dmaBufBusAddr;
    void*           dmaMappedAddr;
} scgtDMATools;


/* Device structure */

typedef struct _scgtDevice
{
   SCGT_DEVICE_CORE

   uint32 *cRegPtr;
   ViSession cRegInstr;
   ViAddr cRegMappedAddr;
   uint32 *nmRegPtr;
   ViSession nmRegInstr;
   ViAddr nmRegMappedAddr;
   void *memPtr;
   uint16 winAccessMode;
   ViAddr gtMemPhysAddr;   
   uint64 memVirtAddr;
   uint64 memPhysAddr;
   scgtViData * viData;
   volatile uint32 getIntrWaitCount;
   ksysSemB getIntrSem;
   
   scgtDMATools writeTools;
   scgtDMATools readTools;

} scgtDevice;


/*
uint32 gtVisaTrQueue(scgtDevice *dev, gtcoreExchMgrData *exchMgrData,
                     uint8 direction, uint8 doAlloc);

uint32 gtVisaExchChain(scgtDevice *dev, gtcoreExchMgrData *exchMgrData, 
                       uint32 exchNum, uint8 direction, uint8 doAlloc);

//DLC - uses custome functions.
#define scgtExchChain(a,b,c,d,e) gtVisaExchChain(a,b,c,d,e)
#define scgtTrQueue(a,b,c,d)     gtVisaTrQueue(a,b,c,d)
*/



#endif /* __SCGT_H__ */
