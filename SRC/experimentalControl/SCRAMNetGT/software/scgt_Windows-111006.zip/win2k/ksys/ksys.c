/******************************************************************************/
/*                              SCRAMNet GT                                   */
/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2002-2005 Curtiss-Wright Controls.                           */
/*               support@systran.com 800-252-5601 (U.S. only) 937-252-5601    */
/*                                                                            */
/* This program is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU General Public License                */
/* as published by the Free Software Foundation; either version 2             */
/* of the License, or (at your option) any later version.                     */
/*                                                                            */
/* See the GNU General Public License for more details.                       */
/*                                                                            */
/******************************************************************************/

#include "ksys.h"
#include "systypes.h"

char *FILE_REV_KSYS_C = "4";    /* 7/22/11 */


/********************* prototypes ***********************/

PMDL ksysCreateMDL(void *virtPtr, ULONG len, KPROCESSOR_MODE procMode);
void ksysDestroyMDL(PMDL mdl);

/***********************************************************/
/*********** Mem copies to and from user space *************/
/***********************************************************/


/**************************************************************************//**
 * @fn  void ksysCopyToUser(void *userPtrDest, void *src, uint32 numBytes)
 * 
*  @brief  copy to user. 
 *
 * @param [in,out]  userPtrDest If non-null, the user pointer destination. 
 * @param [in,out]  src         If non-null, source for the. 
 * @param  numBytes             Number of bytes. 
 *****************************************************************************/
void ksysCopyToUser(void *userPtrDest, void *src, uint32 numBytes)
{
    MDL *mdl;
    uint8 *dest;
   
    if ((mdl = IoAllocateMdl(userPtrDest, numBytes, FALSE, FALSE, NULL)) == NULL)
    {
        KdPrint(("ksysCopyToUser(): mdl allocation failed\n"));
        return;
    }
    
    try
    {
        MmProbeAndLockPages(mdl, UserMode, IoModifyAccess);
    }
    except (EXCEPTION_EXECUTE_HANDLER)
    {
        KdPrint(("ksysCopyToUser(): probe and lock failed \n"));
        IoFreeMdl(mdl);
        return;
    }
    
    if ((dest = MmGetSystemAddressForMdlSafe(mdl, NormalPagePriority)) != NULL)
    {
        /* do the copy */
        memcpy(dest, src, numBytes);
    }

    MmUnlockPages(mdl);
    IoFreeMdl(mdl);
}

/**************************************************************************//**
 * @fn  void ksysCopyFromUser(void *dst, void *userPtrSrc, uint32 numBytes)
 *
 * @brief  Ksys copy from user. 
 *
 * @param [in,out]  dst         If non-null, destination for the. 
 * @param [in,out]  userPtrSrc  If non-null, the user pointer source. 
 * @param  numBytes             Number of bytes. 
 *****************************************************************************/
void ksysCopyFromUser(void *dst, void *userPtrSrc, uint32 numBytes)
{
    MDL *mdl;
    uint8 *src;
    
    if ((mdl = IoAllocateMdl(userPtrSrc, numBytes, FALSE, FALSE, NULL)) == NULL)
    {
        KdPrint(("ksysCopyToUser(): mdl allocation failed\n"));
        return;
    }
    
    try
    {
        MmProbeAndLockPages(mdl, UserMode, IoReadAccess);
    }
    except (EXCEPTION_EXECUTE_HANDLER)
    {
        KdPrint(("ksysCopyToUser(): probe and lock failed \n"));
        IoFreeMdl(mdl);
        return;
    }
    
    if ((src = MmGetSystemAddressForMdlSafe(mdl, NormalPagePriority)) != NULL)
    {
        /* do the copy */
        memcpy(dst, src, numBytes);
    }

    MmUnlockPages(mdl);
    IoFreeMdl(mdl);
}


/***********************************************************/
/************ Vitual to bus addr translation ***************/
/***********************************************************/

/**************************************************************************//**
 * @fn  uint32 ksysMapVirtToBus(void *dmaHandle, void *ptr, uint32 numBytes)
 *
 * @brief  Ksys map virt to bus.  mapData must point to a DMA_ADAPTER
 *
 * @param [in,out]  dmaHandle   If non-null, handle of the dma. 
 * @param [in,out]  ptr         If non-null, the pointer. 
 * @param  numBytes             Number of bytes. 
 *
 * @return . 
 *****************************************************************************/
uint32 ksysMapVirtToBus(void *dmaHandle, void *ptr, uint32 numBytes)
{
    MDL *trMdl;
    DMA_ADAPTER *dmaAdapter;
    PHYSICAL_ADDRESS physAddr;
    uint32 buffLength;

    if (dmaHandle == NULL)
    {
        KdPrint(("ksysMapVirtToBus(): mapData == NULL!!\n"));
        return 0;
    }

    buffLength = 1;
    trMdl = ksysCreateMDL(ptr, buffLength, KernelMode);

    dmaAdapter = (DMA_ADAPTER *) dmaHandle;
    physAddr = dmaAdapter->DmaOperations->MapTransfer(dmaHandle,
                                                      trMdl,
                                                      NULL,
                                                      MmGetMdlVirtualAddress(trMdl),
                                                      &buffLength,
                                                      FALSE);

    dmaAdapter->DmaOperations->FlushAdapterBuffers(dmaHandle,
                                                      trMdl,
                                                      NULL,
                                                      MmGetMdlVirtualAddress(trMdl),
                                                      buffLength,
                                                      FALSE);
    ksysDestroyMDL(trMdl);

    return physAddr.LowPart;
}

/**************************************************************************//**
 * @fn  PMDL ksysCreateMDL(void *virtPtr, ULONG len, KPROCESSOR_MODE procMode)
 * 
 * @brief  Ksys create mdl. 
 *
 * @param [in,out]  virtPtr  buffer to lock
 * @param  len               The buffer length. 
 * @param  procMode          The proc mode. KernelMode or UserMode
 *
 * @return mdl pointer
 *****************************************************************************/
PMDL ksysCreateMDL(void *virtPtr, ULONG len, KPROCESSOR_MODE procMode)
{
    PMDL mdl = NULL;
    
    mdl = IoAllocateMdl(virtPtr, len, FALSE, FALSE, NULL);
    MmProbeAndLockPages(mdl, procMode, IoModifyAccess);
    
    return mdl;
}

/**************************************************************************//**
 * @fn  void ksysDestroyMDL(PMDL mdl)
 *
 * @brief  destroy mdl. 
 *
 * @param  mdl   The mdl. 
 *****************************************************************************/
void ksysDestroyMDL(PMDL mdl)
{
    MmUnlockPages(mdl);
    ExFreePool(mdl);
}

/**************************************************************************//**
 * @fn  void ksysUnmapVirtToBus(void *dmaHandle, void *ptr)
 *
 * @brief  Ksys unmap virt to bus. 
 *
 * @param [in,out]  dmaHandle   If non-null, handle of the dma. 
 * @param [in,out]  ptr         If non-null, the pointer. 
 *****************************************************************************/
void ksysUnmapVirtToBus(void *dmaHandle, void *ptr)
{
}

/*************************************************************/
/****************** register write/read **********************/
/*************************************************************/

/**************************************************************************//**
 * @fn  void ksysWriteReg(void *pRegs, uint32 offset, uint32 val)
 *
 * @brief  Ksys write reg. 
 *
 * @param [in,out]  pRegs If non-null, the regs. 
 * @param  offset         The offset. 
 * @param  val            The value. 
 *****************************************************************************/
void ksysWriteReg(void *pRegs, uint32 offset, uint32 val)
{
    /* Bus swapping done by our cards.. otherwise you need to do this: */
    /* WRITE_REGISTER_ULONG((ULONG *)(((char *)pRegs) + offset), BUS_SWAP(val)); */
    WRITE_REGISTER_ULONG((ULONG *)(((char *)pRegs) + offset), val);
}

/**************************************************************************//**
 * @fn  uint32 ksysReadReg(void *pRegs, uint32 offset)
 *
 * @brief  Ksys read reg. 
 *
 * @param [in,out]  pRegs If non-null, the regs. 
 * @param  offset         The offset. 
 *
 * @return . 
 ***************************************************************************/
uint32 ksysReadReg(void *pRegs, uint32 offset)
{
    /* Bus swapping done by our cards.. otherwise you need to do this: */
    /* return BUS_SWAP(READ_REGISTER_ULONG((ULONG *)(((char *)pRegs) + offset))); */
    return READ_REGISTER_ULONG((ULONG *)(((char *)pRegs) + offset));
}

/********************************************************/
/****************** memory allocation *******************/
/********************************************************/

/**************************************************************************//**
 * @fn  void *ksysMalloc(uint32 nbytes)
 * 
 * @brief   malloc kernal memory. 
 *
 * @param  nbytes   The nbytes. 
 *
 * @return null if it fails, else. 
 *****************************************************************************/
void *ksysMalloc(uint32 nbytes)
{
    return ExAllocatePoolWithTag(NonPagedPool, nbytes, 'ksys');
}

/**************************************************************************//**
 * @fn  void ksysFree(void *p, uint32 len)
*
 * @brief  Ksys free. 
 *
 * @param [in,out]  p  If non-null, the. 
 * @param  len         The length. 
 *****************************************************************************/
/*
 * Free kernel memory
 */
 
void ksysFree(void *p, uint32 len)
{
    ExFreePool(p);
}

/************************************************************/
/*********** timeouting semaphore implementation ************/
/************************************************************/

/**************************************************************************//**
 * @fn  uint32 ksysSemBTakeWithTimeout(ksysSemB *p_sem, long timeOut)
 *
 * @brief  Perform a timed wait on a semaphore 
 *
 * @param [in,out]  p_sem If non-null, the sem. 
 * @param  timeOut        The time out. 
 *
 * @return returns 0 on success, 1 on timeout.
 *****************************************************************************/
uint32 ksysSemBTakeWithTimeout(ksysSemB *p_sem, long timeOut)
{
    LARGE_INTEGER to;

    /* convert timeout from 100ns to 1/1000 second ticks */
    to.QuadPart = -(labs(timeOut));
    to.QuadPart *= 100000;
    
    p_sem->waiting++;   /* used for stats only */
    
    //if ((KeWaitForSingleObject((PHANDLE) &p_sem->sem, Executive, KernelMode, FALSE, &to)) == STATUS_TIMEOUT)
    if ((KeWaitForSingleObject((PVOID) &p_sem->sem, Executive, KernelMode, FALSE, &to)) == STATUS_TIMEOUT)
        return 1;

    p_sem->waiting--;
    return 0;
}

/**************************************************************************//**
 * @fn  uint32 ksysSemBTake(ksysSemB *p_sem)
 *
 * @brief  take semaphore B
 *
 * @param [in,out]  p_sem If non-null, the sem. 
 *
 * @return . 
 *****************************************************************************/
uint32 ksysSemBTake(ksysSemB *p_sem)
{
   ///return KeWaitForSingleObject((PHANDLE) &p_sem->sem, Executive, KernelMode, FALSE, NULL);
   return KeWaitForSingleObject((PVOID) &p_sem->sem, Executive, KernelMode, FALSE, NULL);
}
 
/**************************************************************************//**
 * @fn  uint32 ksysSemBGive(ksysSemB *p_sem)
 *
 * @brief  Give semapohre b 
 *
 * @param [in,out]  p_sem If non-null, the sem. 
 *
 * @return  returns 0 on success, 1 if already given
 *****************************************************************************/
uint32 ksysSemBGive(ksysSemB *p_sem)
{   
    if ((KeReadStateSemaphore(&p_sem->sem)) == 0) 
    {
        KeReleaseSemaphore(&p_sem->sem, 0, 1, FALSE);
        return 0;
    }
    
    return 1;
}


/*****************************************************************/
/************************** sleep ********************************/
/*****************************************************************/

/**************************************************************************//**
 * @fn  void ksysUSleep(unsigned long usec)
 *
 * @brief  sleep for number of mirocseconds specified. 
 *
 * @param  usec  The usec. 
 *****************************************************************************/
void ksysUSleep(unsigned long usec)
{
#if 0
    LARGE_INTEGER to;
    KSEMAPHORE sem;

    KeInitializeSemaphore(&sem, 0, 3);
    to.QuadPart = -labs(usec * 10);

    /* Take & timeout on the semaphore */
    KeWaitForSingleObject((PHANDLE)&sem, Executive, KernelMode, FALSE, &to);
#endif
    KeStallExecutionProcessor(usec);
}
