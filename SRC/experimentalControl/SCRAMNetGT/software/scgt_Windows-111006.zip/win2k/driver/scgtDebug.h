#define SCGT_DBG_ERROR        0x00000001
#define SCGT_DBG_WARNING      0x00000002
#define SCGT_DBG_INFO         0x00000004
#define SCGT_DBG_VERSION      0x00000008
#define SCGT_DBG_DMA          0x00000010
#define SCGT_DBG_IOCTL        0x00000020
#define SCGT_DBG_IOCTL2       0x00000040
#define SCGT_DBG_MAP          0x00000080
#define SCGT_DBG_IS64         0x00000100
#define SCGT_DBG_WRITE        0x00000200
#define SCGT_DBG_READ         0x00000400
#define SCGT_DBG_INTR         0x00000800
#define SCGT_DBG_HALT         0x00001000
#define SCGT_DBG_PNP          0x00002000
#define SCGT_DBG_INIT         0x00004000
#define SCGT_DBG_STATE        0x00008000
#define SCGT_DBG_REG          0x00010000
#define SCGT_DBG_XFER         0x00020000
#define SCGT_DBG_DATA         0x00040000
#define SCGT_DBG_EXCH         0x00080000
#define SCGT_DBG_TRQUEUE      0x00100000

ULONG32 ScgtDrvDebugLevel;

#ifndef NO_DEBUG_MSG
  #define ScgtDbgPrint1( flag, _x_)  DbgPrint _x_ ;

  #define ScgtDbgPrint( _flag_ , _x_ ) \
  if( (_flag_ ) & ScgtDrvDebugLevel ) { \
     DbgPrint _x_ ; \
  }
#else
  #define SgtDbgPrint( flag , args ) 
  #define ScgtDbgPrint1( flag, args )
#endif
      