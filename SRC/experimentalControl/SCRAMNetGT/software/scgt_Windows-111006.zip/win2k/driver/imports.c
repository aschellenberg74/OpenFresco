

/*
   This file is a workaround for Windows' deficient build environment.
   You cannot specify source files across multiple directories in the 'sources'
   file.
*/

#include "../ksys/ksys.c"

#include "../../gtcore/gtcore.c"
#include "../../gtcore/gtcorexfer.c"

