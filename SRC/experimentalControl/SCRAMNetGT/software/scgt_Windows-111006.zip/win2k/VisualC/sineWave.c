#include "stdio.h"
#include <conio.h>
#include <math.h>
#include "scgtapi.h"

void Delay( int32 microseconds)
{
	static LARGE_INTEGER numCountsPerMilliSecond;
	static int firstPass = TRUE;
	LARGE_INTEGER lpFreqency;
	LARGE_INTEGER stopTime;
	LARGE_INTEGER currentTime;
   MSG msg;
	
	if( (numCountsPerMilliSecond.QuadPart == 0) || firstPass )
	{
		firstPass = FALSE;
		/* get number of counts per second for high freqency counter */
		if( QueryPerformanceFrequency(&lpFreqency) == 0)
		{
			   return;
		}
		/* lpFrequency holds number of counts of high freqency counter 
		    per second. 1 sec = 1000miliseconds = 1000000 microseconds*/
		numCountsPerMilliSecond.QuadPart = lpFreqency.QuadPart / 1000000;		
	}
  
	/* get current counter value */
	QueryPerformanceCounter(&currentTime);
	/* calulate stop timer value */
	stopTime.QuadPart = microseconds*numCountsPerMilliSecond.QuadPart + currentTime.QuadPart;

	while (currentTime.QuadPart < stopTime.QuadPart)
    {	
       while (PeekMessage(&msg, 0, 0, 0, PM_REMOVE))
       {
         TranslateMessage(&msg);
         DispatchMessage(&msg);
       }
	   QueryPerformanceCounter(&currentTime);	
    }
    return;

}



int main ( int argc, char* argv[])
{

   scgtHandle gtHandle;
   scgtInterrupt interrupt;
   uint32 unit;
   uint32 offset;
   double data[8];
   uint32 bytesToSend;
   uint32 flags;
   uint32 bytesTransfered;
   uint32 ret;    
   char ch;
   int32 i;
   int count;
   uint32* memPtr;
   double x;
   double sine[361];
   double pi = 3.141592653;
   uint32 upStreamNodeId;
   unit = 0;

   ret = scgtOpen(unit, &gtHandle);
   if(ret != SCGT_SUCCESS)
   {
      printf("error opening Gt device %d\n",unit);
      return ret;
   }

   memPtr = scgtMapMem(&gtHandle);
   if(memPtr == NULL)
   {
      printf ("scgtMapMem returned NULL\n");
   }

   ret = scgtSetState(&gtHandle, SCGT_NODE_ID, 40);
   if(ret != SCGT_SUCCESS)
   {
      printf("error changing Node Id. Error code:0x%x \n",ret);
      return ret;
   }

   ret = scgtSetState(&gtHandle, SCGT_BROADCAST_INT_MASK, 0xffffffff);
   if(ret != SCGT_SUCCESS)
   {
      printf("Error changing Broadcast mask. Error code:0x%x \n",ret);
      return ret;
   }

   ret = scgtSetState(&gtHandle, SCGT_UNICAST_INT_MASK, 1);
   if(ret != SCGT_SUCCESS)
   {
      printf("Error changing unicast interrupt mask. Error code:0x%x \n",ret);
      return ret;
   }

   ret = scgtSetState(&gtHandle, SCGT_INT_SELF_ENABLE, 1);
   if(ret != SCGT_SUCCESS)
   {
      printf("Error errabling self interrupts. Error code:0x%x \n",ret);
      return ret;
   }

   upStreamNodeId = scgtGetState(&gtHandle, SCGT_UPSTREAM_NODE_ID);
   
   bytesToSend = 16;
   flags      = SCGT_RW_PIO;
   offset     = 0x1000;
   bytesTransfered = 0;

   interrupt.type  = SCGT_BROADCAST_INTR;
   interrupt.id    = 3;
//   interrupt.type  = SCGT_UNICAST_INTR;
   //interrupt.id    = upStreamNodeId;
   interrupt.val   = 0x12345678;

   for( i=0;i<=90;i++)
   {
      sine[i] = sin(pi/180 * i );
   }
   for( i=90;i<=180;i++)
      sine[i] = sine[180-i];
   for( i=180;i<=270;i++)
      sine[i] = -sine[i-180];
   for( i=270;i<=360;i++)
      sine[i] = -sine[360-i];


   printf("Sending %s interrupts to Id %d\n",
	     (interrupt.type==SCGT_UNICAST_INTR) ? "Unicast": "broadcast",
	     interrupt.id );
		 
   ch = 0;
   printf("Starting loop press q to quit\n");

   while (ch != 'q')
   {
      if(_kbhit())
      {
         ch = getchar();
      }
      for(i=0;i<360;i++)
      {
         x = 10 * sine[i];
         data[0] = x;
         data[1] = -x;
         
         ret = scgtWrite(&gtHandle, offset, data, bytesToSend, flags, &bytesTransfered, NULL);
         if(ret != SCGT_SUCCESS)
         {
            printf("scgtWrite Error. %s. ret=0x%x\n",scgtGetErrStr(ret),ret);

            ch = _getch();
            scgtClose(&gtHandle);
            return ret;
         }

		 interrupt.val   = i;
		 ret = scgtWrite(&gtHandle, offset, NULL, 0, 0, &bytesTransfered, &interrupt);
         if(ret != SCGT_SUCCESS)
         {
            printf("scgtWrite Error. %s. ret=0x%x\n",scgtGetErrStr(ret),ret);

            ch = _getch();
            scgtClose(&gtHandle);
            return ret;
         }
         //Delay(5000); /* 5000us 5ms */
		 
		 count = 0;
		 while ((ch != 'q') && (count < 100))
         {
            if(_kbhit())
            {
              ch = getchar();
            }
			else
			   Delay(50);
			count++;
         }
		
	  }
   }
   ret = scgtClose(&gtHandle);

   printf("Program conplete\n");
   return SCGT_SUCCESS;
}