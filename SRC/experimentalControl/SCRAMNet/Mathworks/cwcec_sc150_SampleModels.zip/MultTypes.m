% Sample designed to show how to read and write data of different types.
clear all

% Create a SCRAMNet+ partition using a variety of different data types
Partition(1).Address='0x5000';
Partition(1).Type='int32';
Partition(1).Size='2';
Partition(2).Type='uint16';
Partition(2).Size='4';
Partition(3).Type='double';
Partition(3).Size='2';
Partition(4).Type='uint8';
Partition(4).Size='[2,3]';
Partition(5).Type='single';
Partition(5).Size='1';
Partition = completepartitionstruct(Partition);

% Create a second partition that maps part of data from the first
% partition
Partition2(1).Address='0x5000';
Partition2(1).Type='int32';
Partition2(1).Size='2';
Partition2(2).Type='uint16';
Partition2(2).Size='4';
Partition2 = completepartitionstruct(Partition2);

% Create a third partition that maps the rest of tha data from 
% the first partition
Partition3(1).Address='0x5010';
Partition3(1).Type='double';
Partition3(1).Size='2';
Partition3(2).Type='uint8';
Partition3(2).Size='[2,3]';
Partition3(3).Type='single';
Partition3(3).Size='1';
Partition3 = completepartitionstruct(Partition3);

% Create a GT node Structure
Node=scgtnodestruct([]);
Node.Interface.NodeID='8';
Node.Partitions=Partition;
Node=completenodestruct(Node);

% create variables to use in selecting the simulation's Sample Time
% and duration
test1SampleTime=0.01;
test1StopTime=20;

% is connection with target working?
if ~strcmp(slrtpingtarget, 'success')
  error('Connection with target cannot be established');
end

% open the model
open_system('MultTypesModel');

% build xPC application and download it onto the target
rtwbuild('MultTypesModel');

% get reference to the target
tg1=slrt;

% set the target SampleTime and StopTime
tg1.SampleTime=test1SampleTime;
tg1.StopTime=test1StopTime;
