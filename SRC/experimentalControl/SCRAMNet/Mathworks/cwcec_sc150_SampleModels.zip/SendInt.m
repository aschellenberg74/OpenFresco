% Sample program illustrating how to send interrupts and data to other nodes
clear all

% Create partition holding two double precision floating point values to be
% mapped into SCRAMNet GT memory at offset 0x1000.
GtPartition(1).Address='0x1000';
GtPartition(1).Type='double';
GtPartition(1).Size='2';
GtPartition = scgtpartitionstruct(GtPartition);


GtNode=scgtnodestruct([]);
% set Node Id. This value is initially zero at power up and should 
% be set to a unique value for each node in the ring.
GtNode.Interface.NodeID='10';
GtNode.Partitions=GtPartition;

%enable self and broadcast interrupts
%GtNode.Interface.Interrupts.SelfInterrupts='on'
%GtNode.Interface.Interrupts.ChangeBroadcastInterruptMask='yes'
%GtNode.Interface.Interrupts.BroadcastInterruptMask='0xffffffff'

% disable self and broadcast interrupts
GtNode.Interface.Interrupts.SelfInterrupts='off'
GtNode.Interface.Interrupts.ChangeBroadcastInterruptMask='yes'
GtNode.Interface.Interrupts.BroadcastInterruptMask='0'

GtNode=scgtnodestruct(GtNode);

%configure the SampleTime and StopTimes to be used in the simulation
SampleTime=0.1;
StopTime=inf;

% is connection with target working?
if ~strcmp(slrtpingtarget, 'success')
  error('Connection with target cannot be established');
end

% open the model
open_system('GtSendIntModel');

% build xPC application and download it onto the target
rtwbuild('GtSendIntModel');

% Configure the models Stop Time and Sample Time
tg1=xpc;
tg1.SampleTime=SampleTime;
tg1.StopTime=StopTime;

